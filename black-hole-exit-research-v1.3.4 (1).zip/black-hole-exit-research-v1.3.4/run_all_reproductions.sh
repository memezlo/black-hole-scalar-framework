#!/usr/bin/env bash
# Re-run the canonical examples and put fresh outputs in validation_runs/.
# This is separate from unit tests because the full plots/integrations take longer.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/validation_runs"
mkdir -p "$OUT"
export MPLCONFIGDIR="$OUT/.matplotlib-config"
(cd "$ROOT/projects/scalar-gauss-bonnet-instability" && \
 python black_hole_scalar_model.py --ell-gb 100 --delta-log 10 --qmax 0.85 \
   --outdir "$OUT/scalar-gauss-bonnet" --static-convergence --plot)
(cd "$ROOT/projects/black-white-transition-metric-study" && \
 python model.py --outdir "$OUT/phenomenological" --r-max 60 --n-grid 6001 --plot)
(cd "$ROOT/projects/black-white-transition-metric-study" && \
 python near_extremal_horizon_benchmark.py --out "$ROOT/projects/black-white-transition-metric-study/results/near_extremal_horizon_benchmark.csv")
(cd "$ROOT/projects/black-white-transition-metric-study" && \
 python trace_null_ray.py --outdir "$OUT/phenomenological" --t-start -5 --t-end 200 \
   --r-start 7 --max-step 0.05 --sample-count 1026)
(cd "$ROOT/projects/black-white-transition-metric-study" && \
 python trace_null_ray.py --outdir "$OUT/phenomenological_long" --t-start -5 --t-end 10000 \
   --r-start 7 --max-step 5.0 --sample-count 101 --no-plot)
(cd "$ROOT/projects/lqg-effective-transition-benchmark" && \
 python model.py --outdir "$OUT/effective-lqg" --mass-min 0.1 --mass-max 1e5 --n 400 && \
 python regular_bounce_chart.py --outdir "$OUT/effective-lqg-local" --delta 1 --mass-min 0.1 --mass-max 1e3 --n 40 && \
 python horizon_extension.py --outdir "$OUT/effective-lqg-horizon" --delta 1 --mass-min 0.1 --mass-max 1e3 --n 40 && \
 python trace_null_ray_ks.py --outdir "$OUT/effective-lqg-null-ray" --mass 10 --delta 1 --tau-max 0.5 --samples 401 --max-step 0.005)
echo "Canonical examples finished. Fresh outputs are under: $OUT"
