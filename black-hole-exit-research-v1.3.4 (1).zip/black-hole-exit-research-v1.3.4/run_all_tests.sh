#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python - <<'PY'
import importlib.util, sys
missing = [name for name in ("numpy", "scipy", "matplotlib", "mpmath") if importlib.util.find_spec(name) is None]
if missing:
    print("Missing dependencies: " + ", ".join(missing), file=sys.stderr)
    print("Install them with: python -m pip install -r requirements.txt", file=sys.stderr)
    raise SystemExit(2)
PY
run_project() {
  local name="$1"
  echo "== $name =="
  (cd "$ROOT/projects/$name" && python -m unittest discover -s tests -v)
}
run_project scalar-gauss-bonnet-instability
run_project black-white-transition-metric-study
run_project lqg-effective-transition-benchmark
echo "All regression test suites passed. Tests verify code/math in the stated models, not the existence of white holes."
