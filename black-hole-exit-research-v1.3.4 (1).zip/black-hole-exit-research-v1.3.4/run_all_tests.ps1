$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
python -c "import importlib.util,sys; missing=[m for m in ('numpy','scipy','matplotlib','mpmath') if importlib.util.find_spec(m) is None]; print('Missing dependencies: '+', '.join(missing), file=sys.stderr) if missing else None; sys.exit(2 if missing else 0)"
if ($LASTEXITCODE -ne 0) { Write-Host "Install dependencies: python -m pip install -r requirements.txt"; exit 2 }
$Projects = @("scalar-gauss-bonnet-instability", "black-white-transition-metric-study", "lqg-effective-transition-benchmark")
foreach ($Project in $Projects) {
  Write-Host "== $Project =="
  Push-Location (Join-Path (Join-Path $Root "projects") $Project)
  try { python -m unittest discover -s tests -v; if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE } } finally { Pop-Location }
}
Write-Host "All regression test suites passed. This does not prove a physical hypothesis."
