# Changelog

## v1.3.4 — 2026-10-19

- Fixed Project B near-extremal horizon classification: the float64 scan no longer turns every extremum with a small residual into a tangent root, and the fixed `1e-6` root-deduplication tolerance no longer merges nearby roots in the fast path.
- Added an automatic `mpmath` 80-decimal-digit fallback for extrema near a horizon target. It recomputes the target family in arbitrary precision, refines the extremum, distinguishes no-root/tangent/two-root cases, and preserves close roots as `mp.mpf` values.
- Added an explicit `horizon_radii_high_precision` API and precision-matched `horizon_residual`; `horizon_convergence.py` now writes MP residuals and preserves high-precision root coordinates when the fallback activates.
- Added four regressions: high-precision pair birth, a root pair shifted by `1e-20` across criticality, removal of a false tangent root that the old `1e-10` residual threshold could report, and agreement between automatic and explicit MP APIs.
- Corrected the spoken explanation: this implementation does not use Newton's method. Ordinary sign-changing roots use SciPy `brentq`; extrema are located from sampled slopes/`minimize_scalar`; the near-critical fallback uses `mpmath` derivative evaluation and bisection.
- Added `mpmath>=1.3` to shared and Project B dependencies. The final suite contains 45 tests (10 + 15 + 20); local checks do not replace remote CI or independent review.
- Explicit scope: 80 dps is finite, the candidate extrema are still seeded by a finite grid, and a Python float input cannot preserve parameter/time differences already rounded away. Use an `mp.mpf` time inside `mp.workdps(...)` for sub-float64 critical offsets. This improves numerical robustness but is not a proof for all parameter space or of any physical black-to-white transition.

## v1.3.3 — 2026-10-19

- Reproducibly fixed the Project A static-convergence runner: `--static-convergence` now writes the same documented five-column CSV schema as the checked-in benchmark and compares the new asymptotic Robin estimate with the legacy finite-boundary estimate. An unbracketed legacy root is recorded as blank rather than fabricated.
- Added a retained legacy estimator solely for quantifying its finite-domain bias and a regression test showing the old estimator's error decreases with increasing outer boundary while the corrected threshold stays stable.
- Removed a redundant `max(..., 1e-12)` floor from the large-tortoise-coordinate Newton initial guess; the branch condition already guarantees its logarithm argument is positive.
- Made the Project C local Kantowski–Sachs null-ray solver's maximum proper-time step configurable, added validation for invalid steps/tolerances, and added max-step convergence tests.
- Synchronized stale documentation: the artifact sweep uses 13 representative epochs, the unit-test spot check uses 11; the release currently contains 42 tests (10 + 12 + 20).
- Refreshed canonical outputs, symbolic-check logs, test logs and all checksum manifests.
- Re-ran 42 local regression tests, the full canonical demonstration runs, and both optional SymPy curvature checks. The GitHub Actions workflow is defined, but remote CI and independent external replication remain unverified until the repository is pushed and reviewed.
- Kept the critical physical limits explicit: Project B is phenomenological; Project C's KS transit is local and stops before the outer horizon; global atlas matching, self-consistent collapse/backreaction, stability and observational confirmation remain open.

## v1.3.2 — 2026-10-19

- Audited both user-reported numerical concerns and documented which parts are present in the source versus inferred incorrectly from another metric/chart.
- Removed Project B's silent `r=max(r, 1e-10)` state clipping; integration now raises an explicit error if `r <= 0`.
- Replaced Project A's finite-boundary zero-mode residual `phi(X)+X*phi'(X)` with an eighth-order asymptotic Robin condition derived from the actual linear scalar ODE.
- Regenerated the static threshold table across `x=r/r_H=50...2000`, including the old estimator as an audit comparison.
- Added tests for asymptotic-series order convergence and stability against integration max-step changes.
- Changed the default static integration max step from 0.08 to 1.0 after a direct comparison showed `q_crit` stable to much better than the declared tolerance; this reduces canonical-run time without claiming improved physics.
- Recomputed the growth-rate spectrum, conditional growth integral, sensitivity table and plots under the corrected threshold.
- Added a local Kantowski–Sachs-chart radial null-ray integrator for Project C; it crosses the assumed reflection point and explicitly stops before the outer horizon. No global escape claim is made.
- Regenerated the Project B horizon convergence audit for 13 representative times and three `(r_max, n_grid)` configurations.
- Re-ran the full demonstration script, two symbolic curvature checks and the 39-test suite locally.
- Remote GitHub Actions and independent external replication remain unverified; full global causal structure, nonlinear backreaction and observations remain open.

## v1.3.1 — 2026-10-19

- Added a reproducible Project B horizon-root convergence audit over three `(r_max, n_grid)` configurations and representative epochs.
- Added a regression test requiring matching root counts, root locations, and residuals across the tested configurations.
- Cleaned generated Python bytecode from the source archive and refreshed checksums.

## v1.3.0 — 2026-10-19

- Added the full master research roadmap with nine work packages, exit criteria and explicit stop conditions.
- Added the math/code/model/empirical-physics boundary guide, cross-project audit, and CSV issue register.
- Added root-level dependencies and GitHub Actions CI for Python 3.10–3.12.
- Added dependency checks to Unix/PowerShell test runners.
- Added a reproducible canonical-runs script, separate from quick unit tests.
- Improved phenomenological horizon root detection to refine local extrema and detect tangent/double roots at horizon pair birth/death.
- Added regression tests for tangent roots and non-finite model parameters.
- Added `regular_bounce_chart.py` for a local proper-time reflected chart at the effective-LQG transition surface `h=0`.
- Derived and tested local Ricci scalar, Ricci-tensor square, and Kretschmann scalar values at the transition surface under the reflection-symmetry assumption.
- Added outer-horizon Kruskal-limit analysis and symbolic formulas for the curvature invariants at `x=2M`.
- Added optional SymPy-based independent tensor contraction checks and GitHub Actions configuration.
- No claim about physical black-to-white transitions is made; global geodesics, outer-horizon atlas, self-consistent collapse/backreaction, stability, and observations remain open.
