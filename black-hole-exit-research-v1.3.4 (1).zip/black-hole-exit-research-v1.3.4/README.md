# Research package: can a causal signal leave a black hole?

**Version:** 1.3.4 · **Build date:** 19 October 2026

This reproducible research package contains three independent computational tracks. It does **not** claim that escape from a genuine global event horizon has been proved or that astrophysical white holes have been detected.

## Corrections retained from v1.3.2

- Replaced Project A's finite-boundary residual `phi(X) + X phi'(X)` with an eighth-order, ODE-derived asymptotic Robin condition for the decaying zero-mode tail.
- Regenerated the critical threshold, growth-rate spectrum, conditional integral and sensitivity tables under the updated boundary condition.
- Added tests for convergence in outer radius, asymptotic-series order, and integration max step.
- Removed Project B's silent lower-radius clipping; the integrator now fails explicitly if the state reaches `r <= 0`.
- Added a local proper-time Kantowski–Sachs-chart null-ray integration for Project C across the assumed reflection surface. It stops before the outer horizon and does not claim a global escape proof.
- Regenerated the Project B horizon convergence audit across 13 representative times and three domain/grid configurations.

## Review fixes in v1.3.4

- Added an automatic 80-decimal-digit `mpmath` fallback for Project B horizon roots near extremality.
- Removed fixed `1e-6` root deduplication and added three regressions covering tangent roots, close pairs and false tangent classifications.
- The code does not use Newton's method; ordinary roots use `brentq`, and the near-critical fallback uses high-precision derivative refinement and bisection. See `docs/NEAR_EXTREMAL_HORIZON_AUDIT_RU.md`.

- Project B's ray equation is integrated in its stated Painlevé–Gullstrand-like chart, without a `g_tt + epsilon` denominator. The local h=0 transit belongs to the separate Project C Kantowski–Sachs chart.
- Project A's tail boundary condition is an ODE-derived asymptotic Robin condition; the old `phi + X phi'` estimator is retained only for a reproducible bias comparison.
- Project C supports max-step refinement for its local null-ray integration. This remains a local chart calculation and is not a global escape proof.
- `bash run_all_tests.sh` runs 45 regression tests; canonical runs and optional symbolic checks are described in `docs/TEST_REPORT_RU.md`.

## Projects

1. `projects/scalar-gauss-bonnet-instability/` — linear scalar instability on a fixed Schwarzschild background.
2. `projects/black-white-transition-metric-study/` — a phenomenological black-to-white transition metric and an outgoing-null-ray diagnostic.
3. `projects/lqg-effective-transition-benchmark/` — root checks for `h(x_delta)=0` in a published covariant effective-LQG metric, plus local geometry and null-ray checks.

## Research notes

- `docs/CRITICAL_REVIEW_OF_NUMERICAL_CLAIMS_RU.md`, `docs/USER_REVIEW_RESPONSE_RU.md`, and `docs/NEAR_EXTREMAL_HORIZON_AUDIT_RU.md` — numerical review, including near-extremal horizon roots.
- `docs/PROPOSED_MECHANISM_RU.md` — working mechanism and criteria.
- `docs/MATHEMATICAL_FRAMEWORK_RU.md` — causal definitions and equations.
- `docs/MASTER_RESEARCH_PLAN_RU.md` — staged plan with acceptance and stop criteria.
- `docs/BOUNDARY_MATH_VS_PHYSICS_RU.md` — what code verifies versus what physical assumptions remain.
- `docs/PROJECT_AUDIT_RU.md`, `docs/EXECUTION_CHECKLIST_RU.md`, `docs/CLAIM_LEDGER.csv`, and `docs/ISSUE_REGISTER.csv` — audit, checklist, claim ledger and open-item register.
- `projects/scalar-gauss-bonnet-instability/results/static_threshold_convergence.csv` — comparison of the old finite-boundary estimator with the ODE-derived asymptotic Robin boundary condition.
- `projects/lqg-effective-transition-benchmark/trace_null_ray_ks.py` — local null-ray propagation in the assumed reflected KS chart.
- `tools/verify_local_curvature_symbolic.py` — independent symbolic tensor check.
- `REFERENCES.md` — cited literature, including effective-LQG and scalar–Gauss–Bonnet studies.
- `projects/black-white-transition-metric-study/results/horizon_convergence.csv` — finite root-count/location audit for 13 representative times. `results/near_extremal_horizon_benchmark.csv` audits tangent and close-pair cases with mpmath.
- `docs/TEST_REPORT_RU.md` and `docs/CANONICAL_REPRODUCTION_REPORT_RU.md` — local tests and regenerated demonstration runs for v1.3.4.

## Run tests

Requires Python 3.10+. Dependencies are project-specific; the unified script runs each suite in its own project directory.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
bash run_all_tests.sh
python -m pip install -r requirements-symbolic.txt
python tools/verify_local_curvature_symbolic.py
python tools/verify_static_horizon_invariants_symbolic.py
```

To regenerate the numerical examples and graphics:

```bash
bash run_all_reproductions.sh
```

Generated outputs from that script are written to `validation_runs/`. Project-specific checked examples are also kept in the corresponding `projects/*/results/` directories.

## Scope and limitations

The null ray in Project B escapes a temporary trapped region of a prescribed ansatz; the shift reversal is built into the model. Project C's new null-ray routine crosses `tau=0` only in a local, assumed reflection-symmetric Kantowski–Sachs chart. It stops before the outer horizon; matching to the exterior and tracing to the same future null infinity remain open. By definition, no future-directed causal path from the global black-hole region reaches the same future null infinity.

The scalar–Gauss–Bonnet threshold is a linear zero-mode result on a fixed Schwarzschild background. It is not a self-consistent nonlinear evolution and does not predict a bounce. The updated numerical threshold is `q_crit ≈ 0.725612849259` for the action/coupling convention documented in Project A. This reproduces a known class of scalar-instability results; it is not claimed as a new physical discovery.

The latest local suite contains **45 tests** (10 + 15 + 20), and the full demonstration script completed locally for this build. Project B has an 80-decimal-digit `mpmath` fallback and regressions for zero, one (tangent), and two roots near pair birth. Project B is a phenomenological metric, not the scalar–Gauss–Bonnet model in Project A. The remote GitHub Actions workflow has not been verified because this package has not yet been pushed to a GitHub repository. Tests check the stated equations and numerical implementation, not the existence of white holes.
