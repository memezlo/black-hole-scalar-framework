#!/usr/bin/env python3
"""Reproducible benchmark of a covariant effective-LQG black-hole metric.

Based on the effective line element discussed by Belfaqih, Bojowald, Brahma,
and Duque, Phys. Rev. Lett. 135, 161501 (2025), DOI 10.1103/t6q4-4l77.

Important: this script reproduces the algebraic transition-surface condition
h(x_Delta)=0. It does NOT solve the full quantum theory, perform a complete
four-dimensional curvature audit, or prove a global black-to-white causal
transition. The transition surface lies inside the classical horizon in this
coordinate chart, and extending geodesics through it requires careful global
and coordinate analysis.

Units: G=c=hbar=1. M has length units; Delta has length squared.
"""
from __future__ import annotations
import argparse, csv, json, math
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
from scipy.optimize import brentq

@dataclass(frozen=True)
class Parameters:
    M: float = 10.0
    Delta: float = 1.0
    def validate(self) -> None:
        if not math.isfinite(self.M) or self.M <= 0:
            raise ValueError('M must be a finite positive number')
        if not math.isfinite(self.Delta) or self.Delta <= 0:
            raise ValueError('Delta must be a finite positive number')

def f_metric(x: float | np.ndarray, p: Parameters):
    """Schwarzschild-like lapse function f(x)=1-2M/x; defined for x>0."""
    p.validate()
    a = np.asarray(x, dtype=float)
    if np.any(a <= 0): raise ValueError('areal radius x must be positive')
    out = 1.0 - 2.0*p.M/a
    return float(out) if out.ndim == 0 else out

def holonomy_factor(x: float | np.ndarray, p: Parameters):
    """h(x)=1+(Delta/x^2) f(x), for lambda(x)=sqrt(Delta)/x."""
    p.validate()
    a = np.asarray(x, dtype=float)
    if np.any(a <= 0): raise ValueError('areal radius x must be positive')
    out = 1.0 + p.Delta/(a*a) * (1.0 - 2.0*p.M/a)
    return float(out) if out.ndim == 0 else out

def transition_radius_analytic(p: Parameters) -> float:
    """Positive solution of h=0, equivalently z^3+z=2M/sqrt(Delta).

    z=x_Delta/sqrt(Delta) = 2/sqrt(3) sinh(asinh(3 sqrt(3) m)/3).
    The cubic has exactly one positive root because derivative 3z^2+1>0.
    """
    p.validate()
    m = p.M / math.sqrt(p.Delta)
    z = 2.0/math.sqrt(3.0) * math.sinh(math.asinh(3.0*math.sqrt(3.0)*m)/3.0)
    return math.sqrt(p.Delta)*z

def transition_radius_numeric(p: Parameters) -> float:
    """Independent bracketed numerical root of h(x)=0 in (0,2M)."""
    p.validate()
    lo = max(np.finfo(float).tiny**0.5, 1e-14*min(p.M, math.sqrt(p.Delta)))
    hi = 2.0*p.M
    # h(lo)<0 is expected for finite positive Delta and sufficiently small lo.
    if not float(holonomy_factor(lo, p)) < 0:
        # Scale a safe lower endpoint down for extreme parameter ratios.
        lo = hi*1e-10
        for _ in range(12):
            if float(holonomy_factor(lo, p)) < 0: break
            lo *= 0.1
        else: raise RuntimeError('Could not bracket the positive transition root')
    return float(brentq(lambda x: float(holonomy_factor(x, p)), lo, hi, xtol=1e-13, rtol=1e-13))

def metric_diagonal_components(x: float, p: Parameters) -> tuple[float, float, float, float]:
    """Return (g_tt,g_xx,g_theta_theta,g_phi_phi) where chart is regular.

    For ds²=-f dt² + dx²/(h f) + x²dOmega². This intentionally raises at
    f=0 or h=0; a coordinate singularity must not be hidden by clipping.
    """
    f = float(f_metric(x, p)); h = float(holonomy_factor(x, p))
    if abs(f) < 1e-14: raise ValueError('Schwarzschild-like chart is singular at f=0')
    if abs(h) < 1e-14: raise ValueError('This chart is singular at h=0 transition surface')
    return (-f, 1.0/(h*f), x*x, x*x)

def generate_table(outdir: Path, masses: list[float], Delta: float) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    target = outdir/'transition_surface_table.csv'
    with target.open('w', newline='', encoding='utf-8') as handle:
        w=csv.writer(handle)
        w.writerow(['M_over_sqrtDelta','M','Delta','x_delta_over_sqrtDelta','x_horizon_over_sqrtDelta','h_at_x_delta','root_abs_difference','asymptotic_xdelta_over_sqrtDelta'])
        for m in masses:
            pars=Parameters(M=m*math.sqrt(Delta), Delta=Delta)
            xa=transition_radius_analytic(pars); xn=transition_radius_numeric(pars)
            w.writerow([f'{m:.12g}',f'{pars.M:.12g}',f'{Delta:.12g}',f'{xa/math.sqrt(Delta):.12g}',f'{2*pars.M/math.sqrt(Delta):.12g}',f'{float(holonomy_factor(xa,pars)):.12g}',f'{abs(xa-xn):.12g}',f'{(2*m)**(1/3):.12g}'])
    return target

def generate_plot(outdir: Path, Delta: float, mass_min: float=0.1, mass_max: float=1e5, n: int=400) -> Path:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    outdir.mkdir(parents=True, exist_ok=True)
    ms=np.logspace(math.log10(mass_min),math.log10(mass_max),n)
    xs=np.array([transition_radius_analytic(Parameters(M=float(m),Delta=Delta))/math.sqrt(Delta) for m in ms])
    approx=(2*ms)**(1/3)
    horizon=2*ms
    fig, ax=plt.subplots(figsize=(8.5,5.2))
    ax.loglog(ms,xs,label=r'$x_\Delta/\sqrt{\Delta}$ (exact cubic root)')
    ax.loglog(ms,approx,'--',label=r'large-mass approximation $(2M/\sqrt{\Delta})^{1/3}$')
    ax.loglog(ms,horizon,':',label=r'classical horizon $2M/\sqrt{\Delta}$')
    ax.set_xlabel(r'$M/\sqrt{\Delta}$')
    ax.set_ylabel(r'Radius divided by $\sqrt{\Delta}$')
    ax.set_title('Effective-LQG metric: transition surface scale')
    ax.grid(True,which='both',alpha=.25); ax.legend(fontsize=8)
    fig.tight_layout(); target=outdir/'transition_surface_scaling.png'; fig.savefig(target,dpi=180); plt.close(fig)
    return target

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--outdir',type=Path,default=Path('results'))
    parser.add_argument('--delta',type=float,default=1.0)
    parser.add_argument('--mass-min',type=float,default=0.1,help='minimum M/sqrt(Delta)')
    parser.add_argument('--mass-max',type=float,default=1e5,help='maximum M/sqrt(Delta)')
    parser.add_argument('--n',type=int,default=400)
    args=parser.parse_args()
    if args.mass_min<=0 or args.mass_max<=args.mass_min or args.n<10: parser.error('Require 0<mass-min<mass-max and n>=10')
    masses=np.logspace(math.log10(args.mass_min),math.log10(args.mass_max),max(12,min(args.n,100)))
    table=generate_table(args.outdir,[float(x) for x in masses],args.delta)
    plot=generate_plot(args.outdir,args.delta,args.mass_min,args.mass_max,args.n)
    sample=Parameters(M=10.0*math.sqrt(args.delta),Delta=args.delta)
    xa=transition_radius_analytic(sample); xn=transition_radius_numeric(sample)
    metadata={
      'model':'covariant effective-LQG metric benchmark',
      'reference_doi':'10.1103/t6q4-4l77',
      'units':'G=c=hbar=1',
      'parameters':asdict(sample),
      'sample_transition_radius_analytic':xa,
      'sample_transition_radius_numeric':xn,
      'sample_h_at_transition_radius':float(holonomy_factor(xa,sample)),
      'sample_classical_horizon':2*sample.M,
      'interpretation':'algebraic transition-surface benchmark only; not a global geodesic extension or proof of physical black-to-white transition'
    }
    (args.outdir/'run_metadata.json').write_text(json.dumps(metadata,indent=2)+'\n',encoding='utf-8')
    print(f'M={sample.M:g}, Delta={sample.Delta:g}')
    print(f'x_delta analytic = {xa:.12g}')
    print(f'x_delta numeric  = {xn:.12g}')
    print(f'h(x_delta)       = {float(holonomy_factor(xa,sample)):.6g}')
    print(f'classical horizon= {2*sample.M:.12g}')
    print(f'Wrote {table} and {plot}')
    print('Scope: algebraic benchmark; no claim of complete LQG derivation or escape proof.')

if __name__=='__main__': main()
