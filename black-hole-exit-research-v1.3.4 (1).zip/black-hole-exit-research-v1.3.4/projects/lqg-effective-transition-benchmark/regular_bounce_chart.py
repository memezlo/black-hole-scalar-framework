#!/usr/bin/env python3
"""Local proper-time chart at the h(x)=0 reflection surface.

This module derives local geometric data for the reflected extension of the
specified effective metric. It is not a global atlas and does not integrate
geodesics through the outer horizon or solve the complete effective LQG field
equations. The local continuation assumes the transition surface is a
reflection-symmetry/minimum-areal-radius surface, as interpreted in the cited
model.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

from model import Parameters, f_metric, holonomy_factor, transition_radius_analytic


@dataclass(frozen=True)
class BounceData:
    M: float
    Delta: float
    x_delta: float
    f_delta: float
    h_delta: float
    h_prime_delta: float
    A_delta: float
    F_prime_delta: float
    x_second_derivative_tau: float
    A_second_derivative_tau: float
    ricci_scalar_delta: float
    ricci_tensor_square_delta: float
    kretschmann_delta: float
    metric_determinant_factor_abs: float


def f_prime(x: float, p: Parameters) -> float:
    """Derivative of f=1-2M/x with respect to areal radius x."""
    return 2.0 * p.M / (x * x)


def h_prime(x: float, p: Parameters) -> float:
    """Derivative of h=1+Delta/x^2*(1-2M/x)."""
    return -2.0 * p.Delta / x**3 + 6.0 * p.M * p.Delta / x**4


def local_bounce_data(p: Parameters) -> BounceData:
    """Return local regular-chart derivatives and curvature invariants at x_Delta.

    In the black-hole interior x_Delta < x < 2M, define
        F(x)=-f(x)h(x)>0,  dx/dtau = +/-sqrt(F).
    Reflection across tau=0 gives x(0)=x_Delta, x'(0)=0, x''(0)=F'(x_Delta)/2.
    The local metric is ds^2=-d tau^2 + A(tau)dy^2 + x(tau)^2 dOmega^2,
    A(tau)=-f(x(tau))>0. Symbolic contraction of its Riemann tensor yields
        R|_Delta = A''/A + 4 x''/x + 2/x^2,
        S|_Delta = R_ab R^ab = (U+2V)^2 + U^2 + 2(V+W)^2,
        K|_Delta = (A''/A)^2 + 8 (x''/x)^2 + 4/x^4,
    with U=A''/(2A), V=x''/x, W=1/x^2.
    These are local results at the reflection surface only.
    """
    p.validate()
    x = transition_radius_analytic(p)
    f = float(f_metric(x, p))
    h = float(holonomy_factor(x, p))
    hp = h_prime(x, p)
    fp = f_prime(x, p)
    if not (x > 0.0 and f < 0.0 and hp > 0.0):
        raise ValueError("transition root is outside the expected black-hole interior branch")
    A = -f
    Fp = -f * hp  # h(x_Delta)=0 => F'=-f h'
    xdd = 0.5 * Fp
    Add = -fp * xdd  # A=-f(x(tau)); x'(0)=0
    A_ratio = Add / A
    x_ratio = xdd / x
    ricci = A_ratio + 4.0 * x_ratio + 2.0 / (x * x)
    ricci_tensor_square = (0.5 * A_ratio + 2.0 * x_ratio)**2 + (0.5 * A_ratio)**2 + 2.0 * (x_ratio + 1.0 / (x * x))**2
    kretschmann = A_ratio**2 + 8.0 * x_ratio**2 + 4.0 / x**4
    det_factor_abs = A * x**4  # |det g| = A*x^4*sin(theta)^2 in this chart
    vals = (f, h, hp, A, Fp, xdd, Add, ricci, ricci_tensor_square, kretschmann, det_factor_abs)
    if not all(math.isfinite(value) for value in vals):
        raise ArithmeticError("non-finite local geometry data at the transition surface")
    return BounceData(
        M=p.M, Delta=p.Delta, x_delta=x, f_delta=f, h_delta=h,
        h_prime_delta=hp, A_delta=A, F_prime_delta=Fp,
        x_second_derivative_tau=xdd, A_second_derivative_tau=Add,
        ricci_scalar_delta=ricci, ricci_tensor_square_delta=ricci_tensor_square,
        kretschmann_delta=kretschmann,
        metric_determinant_factor_abs=det_factor_abs,
    )


def generate_table(outdir: Path, ratios: list[float], Delta: float) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "regular_bounce_chart.csv"
    fields = list(asdict(local_bounce_data(Parameters(M=ratios[0] * math.sqrt(Delta), Delta=Delta))).keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for ratio in ratios:
            data = local_bounce_data(Parameters(M=float(ratio) * math.sqrt(Delta), Delta=Delta))
            writer.writerow(asdict(data))
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=Path("results"))
    parser.add_argument("--delta", type=float, default=1.0)
    parser.add_argument("--mass-min", type=float, default=0.1)
    parser.add_argument("--mass-max", type=float, default=1e3)
    parser.add_argument("--n", type=int, default=40)
    args = parser.parse_args()
    if not math.isfinite(args.delta) or args.delta <= 0 or not math.isfinite(args.mass_min) or args.mass_min <= 0 or not math.isfinite(args.mass_max) or args.mass_max <= args.mass_min or args.n < 2:
        parser.error("Require Delta>0, 0<mass-min<mass-max, and n>=2")
    ratios = [math.exp(math.log(args.mass_min) + i * (math.log(args.mass_max) - math.log(args.mass_min)) / (args.n - 1)) for i in range(args.n)]
    csv_path = generate_table(args.outdir, ratios, args.delta)
    sample = local_bounce_data(Parameters(M=10.0 * math.sqrt(args.delta), Delta=args.delta))
    metadata = {
        "model": "local reflected proper-time chart at h=0",
        "parent_model_reference_doi": "10.1103/t6q4-4l77",
        "parameters": asdict(Parameters(M=10.0 * math.sqrt(args.delta), Delta=args.delta)),
        "sample": asdict(sample),
        "scope": "local curvature/regularity diagnostic only; not a global geodesic extension or observational evidence",
    }
    (args.outdir / "regular_bounce_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(f"x_delta={sample.x_delta:.12g}")
    print(f"R_delta={sample.ricci_scalar_delta:.12g}")
    print(f"RicciTensorSquare_delta={sample.ricci_tensor_square_delta:.12g}")
    print(f"K_delta={sample.kretschmann_delta:.12g}")
    print(f"Wrote {csv_path}")
    print("Scope: local reflected chart at h=0 only; global continuation remains open.")


if __name__ == "__main__":
    main()
