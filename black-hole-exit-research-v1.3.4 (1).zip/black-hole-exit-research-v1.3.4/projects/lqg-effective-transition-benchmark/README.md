# Effective-LQG Transition-Surface Benchmark

This project independently checks the algebraic transition-surface condition in one **covariant effective model motivated by loop quantum gravity**, following Belfaqih et al., *Physical Review Letters* 135, 161501 (2025), DOI [10.1103/t6q4-4l77](https://doi.org/10.1103/t6q4-4l77).

For

\[
ds^2=-f(x)dt^2+\frac{dx^2}{h(x)f(x)}+x^2d\Omega^2,\quad f=1-2M/x,\quad h=1+\Delta f/x^2,
\]

the transition-surface condition `h(x_delta)=0` becomes `x_delta^3 + Delta*x_delta - 2*M*Delta = 0`. A closed-form positive root is checked against a separate bracketed numerical solve. The project exports a CSV, a plot, metadata, and regression tests. The `regular_bounce_chart.py` script additionally evaluates a local proper-time reflected chart and Ricci, Ricci-tensor-square, and Kretschmann invariants directly at `h=0`. `horizon_extension.py` checks the local Kruskal limit, surface gravity, and curvature invariants at the outer horizon `x=2M`.

## Run

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python model.py --outdir results
python regular_bounce_chart.py --outdir results
python horizon_extension.py --outdir results
```

## Scope and caveat

This is an independent numerical benchmark of one published effective metric, not a derivation of full LQG. It does not establish the global extension across the transition surface, prove that outgoing causal curves reach the same external infinity, or demonstrate that astrophysical black holes become white holes. Version 0.1.0 now supplies a local proper-time reflected chart and finite curvature invariants at `h=0` under the model's reflection assumption. The two local charts are not yet a globally matched atlas; global causal structure, effective constraints, backreaction, and observation remain unresolved. See [the derivation note](docs/REGULAR_BOUNCE_CHART_DERIVATION_RU.md).
