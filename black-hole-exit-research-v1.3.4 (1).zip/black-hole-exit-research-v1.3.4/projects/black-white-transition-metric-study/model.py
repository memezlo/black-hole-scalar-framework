#!/usr/bin/env python3
"""Reproduce a published phenomenological black-hole-to-white-hole metric.

The formulas and illustrative parameters follow Hergott, Husain & Rastgoo,
Phys. Rev. D 113, 024049 (2026), arXiv:2505.15096.
This is a metric-level reproduction, not a derivation from fundamental LQG.
Coordinates and parameters are treated as dimensionless in units l0=1. The
illustrative run uses A=0.8, explicitly stated below, to obtain the reported
qualitative horizon sequence; it is not asserted to be the exact figure setup.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.optimize import brentq, minimize_scalar
import mpmath as mp


@dataclass(frozen=True)
class Parameters:
    M0: float = 4.0
    a: float = 2.0
    b: float = 3.0
    r0: float = 5.0
    t0: float = 0.0
    l0: float = 1.0
    alpha: float = 1.0
    A: float = 0.8
    n: float = 1.0
    lam: float = 1.0

    def validate(self) -> None:
        values = (self.M0, self.a, self.b, self.r0, self.t0, self.l0,
                  self.alpha, self.A, self.n, self.lam)
        if not all(np.isfinite(value) for value in values):
            raise ValueError("all model parameters must be finite")
        if self.M0 <= 0 or self.a <= 0 or self.b <= 0:
            raise ValueError("M0, a and b must be positive")
        if self.r0 < 0:
            raise ValueError("r0 must be non-negative")
        if self.l0 <= 0 or self.alpha <= 0 or self.A <= 0 or self.n <= 0 or self.lam <= 0:
            raise ValueError("l0, alpha, A, n and lambda must be positive")


def velocity(r: np.ndarray | float, t: float, p: Parameters) -> np.ndarray:
    """Dimensionless radial velocity function v(r,t) from the reference model."""
    r_arr = np.asarray(r, dtype=float)
    if not np.all(np.isfinite(r_arr)) or np.any(r_arr < 0):
        raise ValueError("r must be finite and non-negative")
    if not np.isfinite(t):
        raise ValueError("t must be finite")
    return p.A / np.power(1.0 + r_arr, p.n) * np.tanh((t - p.t0) / p.l0)


def mass_function(r: np.ndarray | float, t: float, p: Parameters) -> np.ndarray:
    """Smooth mass profile m(r,t), in the paper's l0=1 units."""
    r_arr = np.asarray(r, dtype=float)
    if not np.all(np.isfinite(r_arr)) or np.any(r_arr < 0):
        raise ValueError("areal radius r must be finite and non-negative")
    if not np.isfinite(t):
        raise ValueError("t must be finite")
    v = velocity(r_arr, t, p)
    front = (r_arr - p.r0 - v * t) / (p.alpha * p.l0)
    # tanh is numerically stable; non-negative r keeps the fractional-power base non-negative.
    return p.M0 * np.power(1.0 + np.tanh(front), p.a) * np.power(np.tanh(r_arr / p.l0), p.b)


def shift_N(r: np.ndarray | float, t: float, p: Parameters) -> np.ndarray:
    """Signed Painleve-Gullstrand shift N^r; sign reversal encodes the bounce."""
    r_arr = np.asarray(r, dtype=float)
    if not np.all(np.isfinite(r_arr)) or np.any(r_arr <= 0):
        raise ValueError("evaluate N^r at finite r > 0")
    if not np.isfinite(t):
        raise ValueError("t must be finite")
    m = mass_function(r_arr, t, p)
    return -np.tanh(p.lam * (t - p.t0)) * np.sqrt(np.maximum(0.0, 2.0 * m / r_arr))


def null_expansions(r: np.ndarray | float, t: float, p: Parameters) -> tuple[np.ndarray, np.ndarray]:
    """Return theta_plus and theta_minus for future radial null congruences."""
    r_arr = np.asarray(r, dtype=float)
    if np.any(r_arr <= 0):
        raise ValueError("evaluate null expansions at r > 0")
    N = shift_N(r_arr, t, p)
    theta_plus = 2.0 / r_arr * (1.0 - N)
    theta_minus = 2.0 / r_arr * (-1.0 - N)
    return theta_plus, theta_minus


def _mp_parameters(p: Parameters) -> dict[str, mp.mpf]:
    """Convert declared decimal parameter values to arbitrary precision.

    ``str(float_value)`` preserves the public decimal representation of the
    configuration, rather than importing the binary float expansion into MP.
    For more precision in an input parameter, store it as a decimal string in a
    future parameter schema instead of passing a Python float.
    """
    names = ("M0", "a", "b", "r0", "t0", "l0", "alpha", "A", "n", "lam")
    return {name: mp.mpf(str(getattr(p, name))) for name in names}


def _mp_shift_value(r: mp.mpf, t: mp.mpf, pmp: dict[str, mp.mpf]) -> mp.mpf:
    """Arbitrary-precision counterpart of ``shift_N`` for r > 0."""
    if r <= 0:
        raise ValueError("evaluate N^r at r > 0")
    v = pmp["A"] / (1 + r) ** pmp["n"] * mp.tanh((t - pmp["t0"]) / pmp["l0"])
    front = (r - pmp["r0"] - v * t) / (pmp["alpha"] * pmp["l0"])
    mass = pmp["M0"] * (1 + mp.tanh(front)) ** pmp["a"] * mp.tanh(r / pmp["l0"]) ** pmp["b"]
    return -mp.tanh(pmp["lam"] * (t - pmp["t0"])) * mp.sqrt(2 * mass / r)


def _mp_bisect(func, a: mp.mpf, b: mp.mpf, *, dps: int) -> mp.mpf:
    """Bisection in MP arithmetic; the endpoints must bracket a sign change."""
    fa = func(a)
    fb = func(b)
    if fa == 0:
        return a
    if fb == 0:
        return b
    if (fa < 0) == (fb < 0):
        raise ValueError("MP bisection requires a sign-changing bracket")
    tol = mp.power(10, -dps + 8) * max(mp.mpf(1), abs(a), abs(b))
    for _ in range(4 * dps + 100):
        mid = (a + b) / 2
        fm = func(mid)
        if fm == 0 or abs(b - a) <= tol:
            return mid
        if (fa < 0) != (fm < 0):
            b, fb = mid, fm
        else:
            a, fa = mid, fm
    return (a + b) / 2


def _mp_roots_near_extremum(
    t: float | mp.mpf,
    p: Parameters,
    *,
    target: float,
    r_lo: float,
    r_center: float,
    r_hi: float,
    dps: int = 80,
) -> list[mp.mpf]:
    """High-precision local classification of a tangent/near-tangent root."""
    with mp.workdps(dps):
        pmp = _mp_parameters(p)
        tmp = mp.mpf(t) if isinstance(t, mp.mpf) else mp.mpf(str(t))
        tgt = mp.mpf(str(target))
        lo, center, hi = map(lambda z: mp.mpf(str(z)), (r_lo, r_center, r_hi))

        def func(radius: mp.mpf) -> mp.mpf:
            return _mp_shift_value(radius, tmp, pmp) - tgt

        derivative = lambda radius: mp.diff(func, radius)
        d_lo, d_hi = derivative(lo), derivative(hi)
        if d_lo == 0:
            rcrit = lo
        elif d_hi == 0:
            rcrit = hi
        elif (d_lo < 0) != (d_hi < 0):
            rcrit = _mp_bisect(derivative, lo, hi, dps=dps)
        else:
            try:
                rcrit = mp.findroot(derivative, (lo, hi), solver="secant", maxsteps=100)
            except (ValueError, ZeroDivisionError):
                # No valid stationary point was refined in this local bracket;
                # leave the already-detected ordinary roots unchanged.
                return []
            if not lo <= rcrit <= hi:
                return []

        fcrit = func(rcrit)
        tangent_tol = mp.power(10, -dps + 8) * max(mp.mpf(1), abs(tgt))
        if abs(fcrit) <= tangent_tol:
            return [rcrit]

        roots: list[mp.mpf] = []
        fleft, fright = func(lo), func(hi)
        if fleft != 0 and ((fleft < 0) != (fcrit < 0)):
            roots.append(_mp_bisect(func, lo, rcrit, dps=dps))
        if fright != 0 and ((fright < 0) != (fcrit < 0)):
            roots.append(_mp_bisect(func, rcrit, hi, dps=dps))
        return sorted(roots)


def horizon_radii_high_precision(
    t: float | mp.mpf,
    p: Parameters,
    *,
    r_max: float = 60.0,
    n_grid: int = 3001,
    dps: int = 80,
) -> tuple[list[mp.mpf], list[mp.mpf]]:
    """Find horizon roots in arbitrary precision, including near-tangent pairs.

    This expensive path is intended for near-extremal checks, not every point
    in a large plotting grid. It scans sign changes and independently refines
    extrema. If an extremum lies at the target, it reports one tangent root;
    if it lies just across the target, it brackets both nearby simple roots.

    ``t`` may be an ``mp.mpf`` to preserve a high-precision critical parameter.
    A Python float cannot recover precision that was already lost when that
    input was rounded to float64.
    """
    p.validate()
    if not np.isfinite(float(t)) or not np.isfinite(r_max) or r_max <= 0 or n_grid < 10:
        raise ValueError("t must be finite, r_max positive and finite, and n_grid >= 10")
    if dps < 30:
        raise ValueError("dps must be at least 30 for the near-extremal fallback")

    with mp.workdps(dps):
        pmp = _mp_parameters(p)
        tmp = mp.mpf(t) if isinstance(t, mp.mpf) else mp.mpf(str(t))
        r_min = mp.mpf("1e-5")
        r_max_mp = mp.mpf(str(r_max))
        grid = [r_min + (r_max_mp - r_min) * i / (n_grid - 1) for i in range(n_grid)]

        def roots_for_target(target_int: int) -> list[mp.mpf]:
            target = mp.mpf(target_int)

            def func(radius: mp.mpf) -> mp.mpf:
                return _mp_shift_value(radius, tmp, pmp) - target

            values = [func(radius) for radius in grid]
            roots: list[mp.mpf] = []

            # Sign-changing roots; all refinement is performed in MP precision.
            for i, value in enumerate(values):
                if value == 0:
                    roots.append(grid[i])
                if i and value != 0 and values[i - 1] != 0 and ((value < 0) != (values[i - 1] < 0)):
                    roots.append(_mp_bisect(func, grid[i - 1], grid[i], dps=dps))

            # Near a double root, the two roots can be much closer than one
            # grid cell. Refine all sampled local extrema near the target.
            derivative = lambda radius: mp.diff(func, radius)
            critical_tol = mp.power(10, -dps + 8) * max(mp.mpf(1), abs(target))
            for i in range(1, len(grid) - 1):
                dleft = values[i] - values[i - 1]
                dright = values[i + 1] - values[i]
                is_extremum = (dleft > 0 and dright < 0) or (dleft < 0 and dright > 0)
                if not is_extremum or abs(values[i]) > mp.mpf("0.05"):
                    continue
                dl = derivative(grid[i - 1])
                dr = derivative(grid[i + 1])
                if dl == 0:
                    rcrit = grid[i - 1]
                elif dr == 0:
                    rcrit = grid[i + 1]
                elif (dl < 0) != (dr < 0):
                    rcrit = _mp_bisect(derivative, grid[i - 1], grid[i + 1], dps=dps)
                else:
                    # A flat sampled peak may have derivative signs that round
                    # poorly at the bracket endpoints; use a guarded secant solve.
                    try:
                        rcrit = mp.findroot(derivative, (grid[i - 1], grid[i + 1]), solver="secant", maxsteps=100)
                    except (ValueError, ZeroDivisionError):
                        continue
                    if not (grid[i - 1] <= rcrit <= grid[i + 1]):
                        continue
                fcrit = func(rcrit)
                fleft = func(grid[i - 1])
                fright = func(grid[i + 1])
                if abs(fcrit) <= critical_tol:
                    roots.append(rcrit)
                    continue
                if fleft != 0 and ((fleft < 0) != (fcrit < 0)):
                    roots.append(_mp_bisect(func, grid[i - 1], rcrit, dps=dps))
                if fright != 0 and ((fright < 0) != (fcrit < 0)):
                    roots.append(_mp_bisect(func, rcrit, grid[i + 1], dps=dps))

            roots.sort()
            unique: list[mp.mpf] = []
            for root in roots:
                duplicate_tol = mp.power(10, -dps + 8) * max(mp.mpf(1), abs(root))
                if not unique or abs(root - unique[-1]) > duplicate_tol:
                    unique.append(root)
            return unique

        return roots_for_target(+1), roots_for_target(-1)


def horizon_residual(root: float | mp.mpf, t: float | mp.mpf, p: Parameters, target: float) -> float | mp.mpf:
    """Evaluate |N^r-target| in matching precision for reported horizon roots."""
    if isinstance(root, mp.mpf) or isinstance(t, mp.mpf):
        with mp.workdps(80):
            pmp = _mp_parameters(p)
            rmp = mp.mpf(root)
            tmp = mp.mpf(t) if isinstance(t, mp.mpf) else mp.mpf(str(t))
            return abs(_mp_shift_value(rmp, tmp, pmp) - mp.mpf(str(target)))
    return abs(float(shift_N(float(root), float(t), p)) - target)


def horizon_radii(
    t: float | mp.mpf,
    p: Parameters,
    *,
    r_max: float = 60.0,
    n_grid: int = 3001,
) -> tuple[list[float | mp.mpf], list[float | mp.mpf]]:
    """Find roots of theta_plus (N^r=+1) and theta_minus (N^r=-1).

    The fast float64 scan handles ordinary simple roots. When an extremum is
    within 1e-6 of the target, an arbitrary-precision fallback reclassifies the
    entire target family, preventing a near-critical pair from being mislabeled
    as one tangent root by a fixed float64 residual threshold. Returned roots
    from that fallback are ``mp.mpf`` values so close pairs are not merged by a
    hard-coded coordinate tolerance.
    """
    p.validate()
    t_float = float(t)
    if not np.isfinite(t_float) or not np.isfinite(r_max) or r_max <= 0 or n_grid < 10:
        raise ValueError("t must be finite, r_max positive and finite, and n_grid >= 10")
    r = np.linspace(1e-5, r_max, n_grid)
    N = shift_N(r, t_float, p)
    plus_roots = _roots_for_target(r, N, target=1.0, t=t_float, t_precise=t, p=p, r_max=r_max, n_grid=n_grid)
    minus_roots = _roots_for_target(r, N, target=-1.0, t=t_float, t_precise=t, p=p, r_max=r_max, n_grid=n_grid)
    return plus_roots, minus_roots


def _roots_for_target(
    r: np.ndarray,
    N: np.ndarray,
    *,
    target: float,
    t: float,
    t_precise: float | mp.mpf,
    p: Parameters,
    r_max: float,
    n_grid: int,
) -> list[float | mp.mpf]:
    y = N - target
    roots: list[float | mp.mpf] = []
    finite = np.isfinite(y)
    exact_indices = np.flatnonzero(finite & (y == 0.0))
    crossing_indices = np.flatnonzero(finite[:-1] & finite[1:] & (y[:-1] * y[1:] < 0.0))
    roots.extend(float(r[i]) for i in exact_indices)
    for i in crossing_indices:
        roots.append(float(brentq(
            lambda rr: float(shift_N(rr, t, p) - target),
            float(r[i]), float(r[i + 1])
        )))

    fallback_indices: set[int] = set()
    # Exact rounded values with the same sign on the nearest nonzero samples
    # indicate a tangent/flat peak rather than a regular sign-changing root.
    for i in exact_indices:
        left, right = i - 1, i + 1
        while left >= 0 and y[left] == 0.0:
            left -= 1
        while right < len(y) and y[right] == 0.0:
            right += 1
        if left >= 0 and right < len(y) and ((y[left] < 0) == (y[right] < 0)):
            fallback_indices.add(int(i))

    # Refine the local shape in float64 first. A small residual is only a signal
    # to recheck, never sufficient to declare a tangent root.
    slope_left = y[1:-1] - y[:-2]
    slope_right = y[2:] - y[1:-1]
    center_y = y[1:-1]
    near_target = np.abs(center_y) <= 5e-2
    is_min = (slope_left < 0.0) & (slope_right > 0.0)
    is_max = (slope_left > 0.0) & (slope_right < 0.0)
    candidate_indices = np.flatnonzero(near_target & (is_min | is_max)) + 1
    fallback_trigger = 1e-6 * max(1.0, abs(target))
    for i in candidate_indices:
        i = int(i)
        lo, hi = float(r[i - 1]), float(r[i + 1])
        objective = lambda rr: float(shift_N(rr, t, p) - target)
        if is_max[i - 1] and not is_min[i - 1]:
            objective = lambda rr: -float(shift_N(rr, t, p) - target)
        optimum = minimize_scalar(objective, bounds=(lo, hi), method="bounded",
                                  options={"xatol": 1e-12})
        if optimum.success:
            residual = abs(float(shift_N(float(optimum.x), t, p) - target))
            if residual <= fallback_trigger:
                fallback_indices.add(i)

    # A machine-flat, near-target plateau may not produce a strict discrete
    # extremum (both finite differences can round to zero). Trigger the local
    # MP check only for that rare signature, not for ordinary root crossings.
    flat_tol = 64.0 * np.finfo(float).eps * max(1.0, abs(target))
    flat_near_target = (
        (np.abs(center_y) <= fallback_trigger)
        & (np.abs(slope_left) <= flat_tol)
        & (np.abs(slope_right) <= flat_tol)
    )
    fallback_indices.update(int(i + 1) for i in np.flatnonzero(flat_near_target))

    if fallback_indices:
        mp_roots: list[mp.mpf] = []
        covered_intervals: list[tuple[float, float]] = []
        for i in sorted(fallback_indices):
            if i <= 0 or i >= len(r) - 1:
                continue
            lo, center, hi = float(r[i - 1]), float(r[i]), float(r[i + 1])
            local = _mp_roots_near_extremum(
                t_precise, p, target=target, r_lo=lo, r_center=center, r_hi=hi, dps=80
            )
            if local:
                mp_roots.extend(local)
                covered_intervals.append((lo, hi))

        # Keep ordinary roots outside local MP-refinement intervals. Inside each
        # interval the MP result replaces float64 roots, including false roots.
        for root in roots:
            rf = float(root)
            if not any(lo <= rf <= hi for lo, hi in covered_intervals):
                mp_roots.append(mp.mpf(str(root)))
        mp_roots.sort()
        unique_mp: list[mp.mpf] = []
        with mp.workdps(80):
            for root in mp_roots:
                duplicate_tol = mp.power(10, -80 + 8) * max(mp.mpf(1), abs(root))
                if not unique_mp or abs(root - unique_mp[-1]) > duplicate_tol:
                    unique_mp.append(root)
        return unique_mp

    # Float fast path: deduplicate only within a scale-aware floating-point
    # tolerance, not a fixed physical distance such as 1e-6.
    unique: list[float | mp.mpf] = []
    for root in sorted(roots):
        duplicate_tol = 64 * np.finfo(float).eps * max(1.0, abs(float(root)))
        if not unique or abs(float(root) - float(unique[-1])) > duplicate_tol:
            unique.append(root)
    return unique


def write_horizon_table(outdir: Path, p: Parameters, *, r_max: float, n_grid: int) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "horizon_samples.csv"
    times = [-1200, -800, -400, -100, -20, -1, 0, 1, 20, 200, 600, 1200]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["t_l0", "family", "root_index_inner_to_outer", "r_over_l0", "interpretation"])
        for t in times:
            bh, wh = horizon_radii(float(t), p, r_max=r_max, n_grid=n_grid)
            for i, root in enumerate(bh, 1):
                writer.writerow([t, "theta_plus_zero_N_eq_plus_1", i, f"{float(root):.12g}", "black-hole trapped-region boundary for t<0"])
            for i, root in enumerate(wh, 1):
                writer.writerow([t, "theta_minus_zero_N_eq_minus_1", i, f"{float(root):.12g}", "white-hole anti-trapped-region boundary for t>0"])
    return path


def write_plot(outdir: Path, p: Parameters, *, r_max: float, n_grid: int, n_times: int = 481) -> Path:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    outdir.mkdir(parents=True, exist_ok=True)
    times = np.linspace(-1200.0, 1200.0, n_times)
    bh_tracks = np.full((n_times, 2), np.nan)
    wh_tracks = np.full((n_times, 2), np.nan)
    for i, t in enumerate(times):
        bh, wh = horizon_radii(float(t), p, r_max=r_max, n_grid=n_grid)
        for j, r in enumerate(bh[:2]):
            bh_tracks[i, j] = r
        for j, r in enumerate(wh[:2]):
            wh_tracks[i, j] = r

    fig, ax = plt.subplots(figsize=(9, 5.2))
    ax.plot(times, bh_tracks[:, 0], label="BH inner boundary: theta+ = 0")
    ax.plot(times, bh_tracks[:, 1], label="BH outer boundary: theta+ = 0")
    ax.plot(times, wh_tracks[:, 0], label="WH inner boundary: theta- = 0")
    ax.plot(times, wh_tracks[:, 1], label="WH outer boundary: theta- = 0")
    ax.axvline(p.t0, linestyle="--", linewidth=1, label="shift sign change")
    ax.set_xlabel(r"Time $t/l_0$")
    ax.set_ylabel(r"Areal radius $r/l_0$")
    ax.set_title("Horizon roots in the published phenomenological metric")
    ax.set_xlim(times[0], times[-1])
    ax.set_ylim(0, min(r_max, 45))
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    # Zoom into the transition interval so the finite horizon-free gap is visible.
    axins = ax.inset_axes([0.38, 0.08, 0.28, 0.43])
    axins.plot(times, bh_tracks[:, 0])
    axins.plot(times, bh_tracks[:, 1])
    axins.plot(times, wh_tracks[:, 0])
    axins.plot(times, wh_tracks[:, 1])
    axins.axvline(p.t0, linestyle="--", linewidth=0.8)
    axins.set_xlim(-100, 100)
    axins.set_ylim(0, 36)
    axins.set_title("Transition interval", fontsize=8)
    axins.tick_params(labelsize=7)
    axins.grid(True, alpha=0.2)
    fig.tight_layout()
    path = outdir / "horizon_diagram.png"
    fig.savefig(path, dpi=180)
    plt.close(fig)
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=Path("results"))
    parser.add_argument("--r-max", type=float, default=60.0)
    parser.add_argument("--n-grid", type=int, default=6001)
    parser.add_argument("--plot", action="store_true")
    args = parser.parse_args()
    p = Parameters()
    p.validate()
    csv_path = write_horizon_table(args.outdir, p, r_max=args.r_max, n_grid=args.n_grid)
    print(f"Parameters: {p}")
    print(f"ADM mass M_ADM=2^a M0 = {2**p.a*p.M0:g} (model units)")
    print(f"Wrote horizon samples: {csv_path.resolve()}")
    for t in [-1200, -800, 0, 20, 200, 1200]:
        bh, wh = horizon_radii(float(t), p, r_max=args.r_max, n_grid=args.n_grid)
        print(f"t={t:>6}: theta_plus roots (BH family)={bh}; theta_minus roots (WH family)={wh}")
    if args.plot:
        img_path = write_plot(args.outdir, p, r_max=args.r_max, n_grid=args.n_grid)
        print(f"Wrote plot: {img_path.resolve()}")


if __name__ == "__main__":
    main()
