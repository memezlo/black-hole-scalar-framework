import unittest
import numpy as np
import mpmath as mp

from model import (
    Parameters, horizon_radii, horizon_residual, mass_function, null_expansions,
    shift_N, horizon_radii_high_precision, _mp_parameters, _mp_shift_value,
)


class PublishedTransitionMetricTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p = Parameters()

    def test_asymptotic_mass_matches_paper(self):
        expected = (2.0 ** self.p.a) * self.p.M0
        actual = float(mass_function(2000.0, -800.0, self.p))
        self.assertAlmostEqual(actual, expected, delta=1e-8)

    def test_black_hole_trapped_region_before_bounce(self):
        tp, tm = null_expansions(16.0, -100.0, self.p)
        self.assertLess(float(tp), 0.0)
        self.assertLess(float(tm), 0.0)
        self.assertGreater(float(shift_N(16.0, -100.0, self.p)), 1.0)

    def test_white_hole_antitrapped_region_after_bounce(self):
        tp, tm = null_expansions(16.0, 100.0, self.p)
        self.assertGreater(float(tp), 0.0)
        self.assertGreater(float(tm), 0.0)
        self.assertLess(float(shift_N(16.0, 100.0, self.p)), -1.0)

    def test_no_horizon_at_sign_switching_time(self):
        bh, wh = horizon_radii(0.0, self.p)
        self.assertEqual(bh, [])
        self.assertEqual(wh, [])

    def test_reference_horizon_sequence(self):
        bh_early, wh_early = horizon_radii(-1200.0, self.p)
        self.assertEqual(bh_early, [])
        self.assertEqual(wh_early, [])

        bh, wh = horizon_radii(-800.0, self.p)
        self.assertGreaterEqual(len(bh), 2)
        self.assertAlmostEqual(bh[-1], 32.0, delta=0.25)
        self.assertEqual(wh, [])

        bh, wh = horizon_radii(20.0, self.p)
        self.assertEqual(bh, [])
        self.assertGreaterEqual(len(wh), 2)
        self.assertAlmostEqual(wh[-1], 32.0, delta=0.25)

        bh_late, wh_late = horizon_radii(1200.0, self.p)
        self.assertEqual(bh_late, [])
        self.assertEqual(wh_late, [])

    def test_mass_profile_nonnegative_and_regular_at_origin(self):
        rs = np.array([0.0, 1e-4, 0.01, 1.0, 10.0])
        mass = mass_function(rs, 0.0, self.p)
        self.assertTrue(np.all(np.isfinite(mass)))
        self.assertTrue(np.all(mass >= 0))
        self.assertAlmostEqual(float(mass[0]), 0.0, delta=1e-15)

    def test_non_finite_parameters_are_rejected(self):
        with self.assertRaises(ValueError):
            Parameters(A=float("nan")).validate()
        with self.assertRaises(ValueError):
            Parameters(M0=float("inf")).validate()
        with self.assertRaises(ValueError):
            horizon_radii(float("nan"), self.p)

    def test_horizon_counts_and_roots_converge_across_grid_and_domain(self):
        # The chosen representative times cover the BH branch, transition gap,
        # WH branch, and asymptotic no-horizon epochs. All are compared to an
        # explicitly declared baseline (r_max=60, n_grid=3001).
        times = (-1200.0, -800.0, -200.0, -20.0, -1.0, 0.0, 1.0, 20.0, 200.0, 800.0, 1200.0)
        configs = ((40.0, 1001), (60.0, 3001), (100.0, 6001))
        baseline = (60.0, 3001)
        for t in times:
            reference = horizon_radii(t, self.p, r_max=baseline[0], n_grid=baseline[1])
            for r_max, n_grid in configs:
                candidate = horizon_radii(t, self.p, r_max=r_max, n_grid=n_grid)
                for expected_roots, found_roots, target in (
                    (reference[0], candidate[0], 1.0),
                    (reference[1], candidate[1], -1.0),
                ):
                    self.assertEqual(len(found_roots), len(expected_roots), msg=f"root count mismatch at t={t}, r_max={r_max}, n_grid={n_grid}")
                    for expected, found in zip(expected_roots, found_roots):
                        self.assertAlmostEqual(found, expected, delta=1e-5)
                        residual = abs(float(shift_N(found, t, self.p)) - target)
                        self.assertLess(residual, 1e-8)

    def _high_precision_critical_pair_birth(self):
        # Solve N^r(r,t)=+1 and dN^r/dr=0 together. Retaining an mp.mpf time
        # avoids turning an exactly critical input into an arbitrary float64
        # perturbation that physically lies just to one side of pair birth.
        with mp.workdps(80):
            pmp = _mp_parameters(self.p)
            def shift(radius, time):
                return _mp_shift_value(radius, time, pmp)
            r_critical, t_critical = mp.findroot(
                lambda radius, time: (
                    shift(radius, time) - 1,
                    mp.diff(lambda x: shift(x, time), radius),
                ),
                (mp.mpf("31.7"), mp.mpf("-981.9")),
                tol=mp.mpf("1e-70"), maxsteps=100,
            )
            return +r_critical, +t_critical

    def test_horizon_tangency_is_detected_at_pair_birth_in_mp(self):
        with mp.workdps(80):
            r_critical, t_critical = self._high_precision_critical_pair_birth()
            bh_roots, wh_roots = horizon_radii(t_critical, self.p, r_max=60.0, n_grid=6001)
            self.assertEqual(len(bh_roots), 1)
            self.assertEqual(wh_roots, [])
            self.assertLess(horizon_residual(bh_roots[0], t_critical, self.p, 1.0), mp.mpf("1e-60"))
            self.assertLess(abs(bh_roots[0] - r_critical), mp.mpf("1e-50"))

    def test_near_extremal_pair_is_not_collapsed_by_float64_deduplication(self):
        with mp.workdps(80):
            _, t_critical = self._high_precision_critical_pair_birth()
            # A shift by 1e-20 is lost if the time is first coerced to float64,
            # yet its root pair remains resolvable with arbitrary precision.
            below, _ = horizon_radii(t_critical - mp.mpf("1e-20"), self.p, r_max=60.0, n_grid=6001)
            above, _ = horizon_radii(t_critical + mp.mpf("1e-20"), self.p, r_max=60.0, n_grid=6001)
            self.assertEqual(below, [])
            self.assertEqual(len(above), 2)
            separation = abs(above[1] - above[0])
            self.assertGreater(separation, mp.mpf("1e-12"))
            self.assertLess(separation, mp.mpf("1e-8"))
            for root in above:
                self.assertLess(horizon_residual(root, t_critical + mp.mpf("1e-20"), self.p, 1.0), mp.mpf("1e-55"))

    def test_explicit_high_precision_api_agrees_with_automatic_fallback(self):
        with mp.workdps(80):
            _, t_critical = self._high_precision_critical_pair_birth()
            t_above = t_critical + mp.mpf("1e-20")
            auto_roots, _ = horizon_radii(t_above, self.p, r_max=60.0, n_grid=6001)
            explicit_roots, _ = horizon_radii_high_precision(
                t_above, self.p, r_max=60.0, n_grid=6001, dps=80
            )
            self.assertEqual(len(auto_roots), 2)
            self.assertEqual(len(explicit_roots), 2)
            for auto, explicit in zip(auto_roots, explicit_roots):
                self.assertLess(abs(auto - explicit), mp.mpf("1e-50"))

    def test_old_float_residual_threshold_no_longer_reports_false_tangent(self):
        with mp.workdps(80):
            _, t_critical = self._high_precision_critical_pair_birth()
            # On this side the local maximum lies below N^r=+1. The old fixed
            # float residual tolerance could report a spurious single tangent root.
            t_below = t_critical - mp.mpf("1e-8")
            bh_roots, wh_roots = horizon_radii(t_below, self.p, r_max=60.0, n_grid=6001)
            self.assertEqual(bh_roots, [])
            self.assertEqual(wh_roots, [])


class NullRayCausalityTests(unittest.TestCase):
    def test_null_ray_can_leave_temporary_trapped_region_in_ansatz(self):
        from trace_null_ray import trace_outgoing_null_ray

        p = Parameters()
        theta_plus, theta_minus = null_expansions(7.0, -5.0, p)
        self.assertLess(float(theta_plus), 0.0)
        self.assertLess(float(theta_minus), 0.0)

        times, radii = trace_outgoing_null_ray(p, sample_count=1026, max_step=0.05)
        r_start = float(radii[0])
        r_early = float(np.interp(-4.0, times, radii))
        r_end = float(radii[-1])
        self.assertAlmostEqual(r_start, 7.0, places=9)
        self.assertLess(r_early, r_start)  # initially ingoing despite choosing outgoing branch
        self.assertGreater(r_end, 250.0)

    def test_null_ray_result_is_stable_under_smaller_max_step(self):
        from trace_null_ray import trace_outgoing_null_ray

        p = Parameters()
        _, r1 = trace_outgoing_null_ray(p, sample_count=101, max_step=0.05)
        _, r2 = trace_outgoing_null_ray(p, sample_count=101, max_step=0.025)
        self.assertAlmostEqual(float(r1[-1]), float(r2[-1]), delta=1e-5)

    def test_null_ray_reaches_large_radius_in_long_finite_time_run(self):
        from trace_null_ray import trace_outgoing_null_ray

        p = Parameters()
        times, radii = trace_outgoing_null_ray(
            p, t_start=-5.0, t_end=10000.0, r_start=7.0,
            max_step=5.0, sample_count=101,
        )
        n_end = float(shift_N(float(radii[-1]), float(times[-1]), p))
        self.assertGreater(float(radii[-1]), 10000.0)
        self.assertLess(n_end, 0.0)
        self.assertGreater(1.0 - n_end, 1.0)
        # For t >= 0 the prescribed shift is non-positive, hence dr/dt = 1-N^r >= 1.
        mask = times >= 0.0
        r_at_zero = float(np.interp(0.0, times, radii))
        self.assertTrue(np.all(radii[mask] >= r_at_zero + times[mask] - 1e-6))

if __name__ == "__main__":
    unittest.main(verbosity=2)
