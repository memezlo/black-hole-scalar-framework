#!/usr/bin/env python3
"""Reproduce near-extremal horizon classification in arbitrary precision."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import mpmath as mp
from scipy.optimize import minimize_scalar

from model import Parameters, _mp_parameters, _mp_shift_value, horizon_radii, horizon_residual, shift_N


def build_records(p: Parameters, *, r_max: float = 60.0, n_grid: int = 6001, dps: int = 80) -> list[dict[str, str]]:
    p.validate()
    rows: list[dict[str, str]] = []
    with mp.workdps(dps):
        pmp = _mp_parameters(p)

        def shift(r, t):
            return _mp_shift_value(r, t, pmp)

        r_critical, t_critical = mp.findroot(
            lambda r, t: (
                shift(r, t) - 1,
                mp.diff(lambda x: shift(x, t), r),
            ),
            (mp.mpf("31.7"), mp.mpf("-981.9")),
            tol=mp.power(10, -dps + 10), maxsteps=100,
        )
        cases = (
            ("below_pair_birth_1e-20", -mp.mpf("1e-20")),
            ("critical_tangency", mp.mpf("0")),
            ("above_pair_birth_1e-20", mp.mpf("1e-20")),
            ("legacy_false_tangent_regression_1e-8", -mp.mpf("1e-8")),
        )
        for name, offset in cases:
            t = t_critical + offset
            bh_roots, wh_roots = horizon_radii(t, p, r_max=r_max, n_grid=n_grid)
            root_strings = ";".join(mp.nstr(r, 50) for r in bh_roots)
            sep = mp.nstr(abs(bh_roots[-1] - bh_roots[0]), 40) if len(bh_roots) >= 2 else ""
            residuals = [horizon_residual(r, t, p, 1.0) for r in bh_roots]
            max_residual = mp.nstr(max(residuals), 12) if residuals else ""
            t_float = float(t)
            # Demonstrate the old float64 residual pathology independently.
            peak = minimize_scalar(
                lambda radius: -float(shift_N(radius, t_float, p)),
                bounds=(1e-5, r_max), method="bounded", options={"xatol": 1e-12},
            )
            peak_residual = mp.nstr(mp.mpf(str(-float(peak.fun) - 1.0)), 12)
            rows.append({
                "case": name,
                "delta_t_from_critical": mp.nstr(offset, 30),
                "t_mp": mp.nstr(t, 50),
                "t_as_float64": repr(t_float),
                "float64_peak_residual_N_minus_1": peak_residual,
                "old_float_root_tol": "1e-10",
                "mp_root_count": str(len(bh_roots)),
                "mp_roots_r": root_strings,
                "mp_pair_separation": sep,
                "max_mp_root_residual": max_residual,
                "dps": str(dps),
                "r_max": str(r_max),
                "n_grid": str(n_grid),
            })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("results/near_extremal_horizon_benchmark.csv"))
    parser.add_argument("--r-max", type=float, default=60.0)
    parser.add_argument("--n-grid", type=int, default=6001)
    parser.add_argument("--dps", type=int, default=80)
    args = parser.parse_args()
    rows = build_records(Parameters(), r_max=args.r_max, n_grid=args.n_grid, dps=args.dps)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0])
    with args.out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    for row in rows:
        print(f"{row['case']}: roots={row['mp_root_count']}, separation={row['mp_pair_separation'] or 'n/a'}, residual={row['max_mp_root_residual'] or 'n/a'}")
    print(f"Wrote {args.out.resolve()}")


if __name__ == "__main__":
    main()
