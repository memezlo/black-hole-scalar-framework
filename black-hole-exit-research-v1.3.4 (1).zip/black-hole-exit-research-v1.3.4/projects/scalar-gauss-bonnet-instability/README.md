# Scalar instability on a Schwarzschild background: a reproducible numerical experiment

**Version:** 1.1.0. **Status:** exploratory numerical research. This is not a quantum-gravity theory and does not demonstrate a black-hole-to-white-hole transition.

This project computes the threshold of a massless, spherically symmetric scalar perturbation with quadratic Gauss–Bonnet coupling on a fixed Schwarzschild background. It then integrates the linear growth rate along an externally prescribed toy mass-loss law to estimate when a user-defined logarithmic amplification threshold is reached.

## What is computed

- a dimensionless static zero-mode threshold `q_crit`;
- the unstable-mode growth rate `sigma = Gamma r_H` above threshold;
- accumulated linear amplification under a specified mass-loss law;
- conditional sensitivity to the coupling length and chosen amplitude threshold;
- numerical convergence checks for the outer boundary and matching domain.

## A formal limitation of the bounce claim

The background metric is fixed in the scalar perturbation calculation. The code does not evolve the metric or compute horizon dynamics, so a black-hole-to-white-hole transition cannot be a predicted output of this setup. See [`docs/BOUNCE_LOGIC_AUDIT_RU.md`](docs/BOUNCE_LOGIC_AUDIT_RU.md) for the detailed audit and [`docs/NEXT_STAGE_PLAN_RU.md`](docs/NEXT_STAGE_PLAN_RU.md) for a research roadmap.

## What is not established

This project does **not** derive equations from loop quantum gravity (LQG) or fundamental string theory, solve the full nonlinear Einstein-scalar system, calculate the self-consistent Hawking flux with greybody factors, prove curvature regularity, or demonstrate a bounce or white-hole transition. The metric is fixed in the linear scalar calculation; the mass-loss coefficient in `dM/dt = -kappa/M^2` is an external toy-model input.

## Illustrative benchmark

For `ell_GB = 100 l_Pl`, `Delta = 10`, `kappa = 1/(15360 pi)`, and `q_max = 0.85`, the current implementation returns approximately:

- `q_crit = 0.725612849259`;
- `r_H/sqrt(alpha) = 0.83010408` under `alpha = 8 ell_GB^2`;
- conditional `q_end = 0.7261033167`;
- conditional fractional mass decrease to the imposed threshold of about `0.033786%`.

The value `Delta = ln(A_nl/|A_seed|) = 10` is an input, not a prediction. The derived endpoint and mass decrement are model-dependent; reaching the threshold only signals breakdown of the chosen linear-amplitude description.

The threshold near `r_H/sqrt(alpha) ~ 0.83` is consistent with published work on the relevant class of scalar–Gauss–Bonnet models; see Fernandes, Mulryne & Delgado (2022), [DOI: 10.1088/1361-6382/aca010](https://doi.org/10.1088/1361-6382/aca010). The threshold is not claimed as a new discovery.

## Run locally

Python 3.10 or later is recommended.

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python black_hole_scalar_model.py --ell-gb 100 --delta-log 10 --qmax 0.85 --outdir results --plot
```

Add `--static-convergence` to re-evaluate the threshold with several outer boundaries. Outputs include CSV data and `run_metadata.json`; plots are created when `--plot` is enabled.

See [the Russian technical note](docs/PHYSICS_RU.md) and [research-status statement](docs/RESEARCH_STATUS.md) for the mathematical definitions and scope.

## Scientific integrity

Uploading code to GitHub does not turn a result into an established fact. Stronger claims require independent reproduction, a careful novelty review, a nonlinear evolution including metric backreaction, and a justified evaporation model. The repository is deliberately written to distinguish computed quantities from assumptions and interpretation.
