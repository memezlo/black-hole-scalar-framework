## v1.4.6 — 2026-10-20

- Added an equation-level mapping from the project's chosen static metric to Eqs. (1), (5), and (6) of Belfaqih et al., PRL 135, 161501 (2025), for the explicit scale choice λ(x)=√Δ/x.
- Added a SymPy audit for the transition-surface cubic and radial scalar potential, plus five regression tests for the algebraic/numerical mapping.
- Corrected the radial-potential formula in the greybody solver docstring to include the required nested factor of f. The implementation was already using the corrected expression.
- Explicitly distinguishes a derivation within a published covariant effective-LQG model from a derivation out of full fundamental LQG. No claim of a complete quantum-gravity derivation, self-consistent collapse, global black-to-white transition, or information-paradox solution is made.

## v1.4.5 — 2026-10-20

- Added Project G, a nonlinear-closure sensitivity diagnostic. Two amplitude equations share the same linear instability (`dA/dt = Gamma*A + O(A^3)`) but have different nonlinear futures (saturation vs growth to a declared diagnostic stop). This proves that the linear pre-threshold formula alone does not identify the endpoint. An explicitly phenomenological energy ledger closes to numerical precision by construction and is not derived from Einstein's equations.
- Added Project H, a finite-dimensional Haar-random pure-state entropy benchmark. The von Neumann entropy of reduced subsystems is numerically estimated and compared with Page's exact Haar-average formula. It validates the quantum-information calculation for a toy finite Hilbert space; it is not a black-hole evaporation circuit, QES/island derivation or proof of unitarity for gravitational collapse.
- Added 12 tests, increased the local regression suite from 96 to 108 tests, and extended Bash/PowerShell test runners. Generated deterministic CSV/JSON examples are checked into the two new projects.
- Added context on del Río & Marañón-González (arXiv:2607.11737, July 2026), who derive a quasi-stationary backreacted solution in semiclassical 3+1D gravity. Their framework is not combined with our fixed-background sGB or effective-LQG tracks; semiclassical backreaction does not by itself resolve the Planck-regime endpoint or information recovery.
- The science scope is unchanged: no claim that a nonlinear black-to-white-hole transition or the Hawking information paradox has been solved.

## v1.4.4 — 2026-10-20

- Added Project F, which integrates one coherent quasi-static system up to a chosen linear-amplitude threshold: `dM/dt=-kappa/M^2`, `q=ell_GB^2/M^2`, and `d ln|A|/dt=Gamma(M)` with `sigma=2M Gamma`. Derived and implemented the coupled equations in q-space.
- The solver cross-checks the numerical amplitude integral against direct quadrature, the time against a closed-form expression, and the mass-loss law through the chain rule. It refuses to extrapolate the precomputed scalar-growth spectrum.
- The calculation stops at the user-supplied threshold and expressly does not model the nonlinear stage, black-to-white transition, or quantum information. The LQG flux/metric and Schwarzschild scalar-growth tracks remain separate until the scalar equation is derived on the same effective background.
- Added 8 unit tests and the coupled reproduction stage. The local regression suite is expected to contain 96 tests (17 + 22 + 21 + 15 + 8 + 8 + 5 repository-integrity tests).
- Corrected the written greybody potential formula to match the radial-equation derivation and implementation: the final term inside the bracket includes the additional factor `f`.

# Changelog

## v1.4.3 — 2026-10-20

- Added a standalone numerical reproduction of the low-frequency s-wave Hawking mass-loss integral used in Belfaqih et al., *Phys. Rev. Lett.* 135, 161501 (2025), DOI 10.1103/t6q4-4l77. Uses the dimensionless variable `z=M*omega`, computes the `Delta=0` coefficient `kappa` directly, tabulates the mass-dependent flux and integrates the model-specific finite mass interval. Explicitly preserves the source approximation's limits.
- Added a separate entropy-bookkeeping diagnostic showing coarse-grained Hawking-like entropy versus an explicitly imposed Page-like min-envelope. All output labels this as a toy comparator, not an island/QES computation or a unitarity proof.
- Added a direct numerical solver for the static effective-metric scalar s-wave radial equation, matching incoming/outgoing waves and checking flux conservation. A frequency-grid audit finds a model-specific ~46.6% difference between the numerical greybody integral and the all-frequency extrapolation of the displayed low-frequency coefficient at Delta/M^2=0; this is recorded as an approximation caveat, not as a refutation of the paper.
- Added 23 regression tests over the v1.4.2 baseline: 9 formula-flux tests, 6 direct greybody-scattering tests, and 8 entropy-diagnostic tests. The repository test runners now include five project suites plus repository integrity; expected suite count is 88 tests (17 + 22 + 21 + 15 + 8 + 5).
- Added `docs/RESEARCH_ADVANCE_V1_4_3_RU.md` with quantified new results and precise remaining blockers. Project A, B and C equations remain separate; no unsupported unification or claim of solving the Hawking information paradox is made.

## v1.4.2 — 2026-10-20

- Added an independent audit of the Project A threshold formula: the same tabulated linear growth spectrum is integrated in q-space and mass-space, providing a direct change-of-variables cross-check. The baseline integrals agree to about 5.31e-10 relative.
- Added a one-parameter-at-a-time sensitivity table for the input log-amplification threshold, the imposed mass-loss coefficient, and the coupling scale. These remain conditional results, not predictions of a bounce.
- Added four regression tests for the dual-integral identity, baseline threshold, out-of-domain handling, and invalid parameters. The suite is now 65 tests (17 + 22 + 21 + 5).
- Corrected a stale Project A example endpoint in `projects/scalar-gauss-bonnet-instability/docs/PHYSICS_RU.md` to match the v1.4.1 canonical run metadata.
- Added `docs/FORMULA_TO_PHYSICS_BRIDGE_AUDIT_RU.md`, explicitly separating the verified conditional threshold calculation from nonlinear collapse, self-consistent Hawking backreaction, a global black-to-white transition, and the information paradox.
- Scientific equations for Projects A–C were not changed. No claim is made that the black-hole information paradox is solved; the three tracks are not derived from a common field-equation system.

## v1.4.1 — 2026-10-19

- Closed a broken local documentation link: the v1.3.9 report pointed to a v1.4.0 audit file that had not actually been included. This release contains the current independent recheck report and has a local-link regression test.
- Isolated Matplotlib caches per test suite in Bash and PowerShell runners. The Bash runner executes four independent, read-only suites in parallel, writes separate temporary logs, and checks all exit codes; this also avoids aggregate test-runner wall-time issues. The visualization now uses 121 time samples and at most 1001 radial points, and the canonical high-precision benchmark uses 1501 scan points; a regression checks that the `1e-74` pair separation agrees with a denser 601/1501 comparison to relative `1e-30`, while the separate horizon convergence audit still reaches 6001 points.
- Added repository-integrity validation for local Markdown links; PowerShell test runner now also runs the repository-integrity tests and verifies the checksum manifest, matching the Unix runner.
- Excludes interpreter caches and generated `validation_runs/` outputs from the release archive; immutable source hashes and archive SHA-256 are rebuilt after the final tests.
- Project equations and scientific scope are unchanged by this maintenance release. Any successful test applies only to the stated mathematical models and does not prove that astrophysical white holes exist or that a ray exits an unchanged global event horizon.
- Added `tools/build_release.py` to create deterministic ZIP/TAR.GZ archives and a SHA-256 sidecar; a regression test covers exclusion of caches and generated outputs. The current suite contains 61 tests (13 + 22 + 21 + 5). The reproduction runner now supports `core` (stages 1–3) and `trajectories` (stages 4–8) phases as an alternative to its default `all` run. Both phases passed separately; a single all-in-one invocation exceeded this audit environment’s command-time limit near stage 7, so the release report does not claim that a single-process full run passed. Final measured test/reproduction counts and environment are recorded in `docs/INDEPENDENT_RECHECK_V1_4_1_RU.md`; fresh suite logs are saved under each project's `results/test_log.txt` and `tools/test_log.txt`.

## v1.4.0 — 2026-10-19

- Re-ran the canonical demonstration script from a clean release tree: all eight stages completed successfully, including the long finite-time null-ray run to `t=10000` and the local Kantowski–Sachs ray check.
- Regenerated Project A tracked CSVs, PNGs and `run_metadata.json` using the updated source and canonical input parameters; the old checked-in endpoint was stale. Current `q_end = 0.7261032564717468`, conditional fractional mass decrease `0.00033775502414` (about `0.0337755%`).
- Recomputed the direct growth rate at the current `q_end` and updated the interpolation comparison: relative difference is about `9.10e-8` against the serialized growth-rate grid.
- Corrected the primary and Russian READMEs and canonical/test reports so current result numbers and reproduction status agree with generated metadata. Added a three-track model-scope matrix and expanded the bibliography with the 2025 covariant-holonomy paper and 2026 holonomy-corrected scalarization paper, clearly marked as related literature rather than direct validation.
- Improved Project A and Project C CSV precision and added float64 round-trip regression tests. Added 30 guard digits to the near-extremal benchmark so pair locations, not just root counts, are stable between the 80- and 100-digit output modes. Improved the reproduction runner's unbuffered progress reporting. The remote GitHub Actions workflow remains unverified because no remote repository run has been performed.
- Verification performed: 58 local tests in four suites; canonical reproductions 8/8; two SymPy symbolic checks; horizon convergence table (108 rows, zero root-count disagreements); syntax, CSV/JSON shape, local Markdown links, checksum manifest and clean-archive integrity. The expected separate v1.4.0 audit file was missing from the historical working tree; v1.4.1 records the actual release checks in `docs/INDEPENDENT_RECHECK_V1_4_1_RU.md`.
- Scientific scope remains limited to the stated models: no claim of a completed global causal atlas, self-consistent Hawking backreaction, physical white-hole detection, or proof of escape from a genuine global event horizon.

## v1.3.9 — 2026-10-19

- Project A now directly solves four additional growth-rate samples at offsets `q-q_crit = 0.00025, 0.00050, 0.00100, 0.00200`; the matching-domain cap is `Y=120000`.
- Tightened the growth ODE absolute/relative tolerances and increased `growth_max_step` to 12 after a regression compared `max_step=12` and `6` near onset. This preserves measured relative agreement while reducing the cost of long-domain integrations.
- Added regression coverage for the near-threshold grid and max-step refinement. The full local suite has 55 tests (12 + 20 + 20 + 3 repository-integrity tests).
- Project B visualization is explicitly downsampled (161 time samples and at most 2001 radial grid points); high-resolution horizon tables and root-convergence tests remain the numerical evidence. This avoids spending the full reproduction budget on a plot that is not a convergence dataset.
- The illustrative Project A endpoint was recalculated as `q_end ≈ 0.7261032552`, with a conditional mass loss of about `0.033775%` for the stated inputs. This is a numerical result of a fixed-background linear model with a prescribed mass-loss law, not a bounce prediction.
- The full single-process reproduction script is still being independently checked in this release process. Do not interpret successful unit tests as evidence of global black-hole escape or physical white-hole existence.

## v1.3.8 — 2026-10-19

- Hardened release reproducibility: generated near-extremal benchmark CSVs are written under `validation_runs/`, compared byte-for-byte, and no longer overwrite curated source tables.
- Added `tools/update_checksums.py` with `--write` and `--check`; generated validation outputs and Python caches are excluded from the immutable root manifest.
- Added three repository-integrity tests and wired manifest validation into CI.
- Removed a placeholder GitHub URL from the LQG benchmark's `CITATION.cff`.

## v1.3.7 — 2026-10-19

- Fixed the near-extremal benchmark's absolute-time serialization: `t_mp` now preserves the significant digits needed to distinguish the critical time from offsets of `±1e-74`. The explicit high-precision root finder and MP residual check now use the same `dps` setting, and the benchmark rejects `dps < 80` instead of silently running below the fixed-offset test's precision requirement.
- Added `--also-write` support; the benchmark automatically refreshes both checked-in copies when using the default or canonical project output path, and the canonical reproduction script explicitly refreshes both from the same records.
- Added two Project B regression tests for high-precision time serialization and byte-for-byte synchronization of the two benchmark CSVs. The suite is now 50 tests (10 + 20 + 20).
- Added a release audit report and updated the current README and test-report version/count. Numerical tests still validate only the stated models and tolerances; they do not prove a physical black-to-white transition.

## v1.3.6 — 2026-10-19

- Tightened high-precision near-tangent classification after a further audit found that the previous `10^(-dps+8)` threshold could merge a resolvable horizon pair into one tangent root at a `+1e-70` time offset. The threshold is now `10^(-dps+2)` and the benchmark covers `±1e-74`; `+1e-76` is explicitly outside the guaranteed classification range at 80 dps.
- Added a regression for the `+1e-74` root pair; current local suite is 48 tests (10 + 18 + 20).
- Re-ran 36 automatic-versus-explicit high-precision comparisons across three grid/domain configurations and twelve offsets; root counts and positions agree within the declared tolerances.
- Re-generated the near-extremal benchmark and 108-row horizon convergence CSV; horizon-count mismatch rows = 0, maximum root residual `2.63e-13`, maximum matched-root deviation from baseline `3.73e-13`.
- Re-ran both symbolic curvature checks successfully. The all-in-one reproduction orchestrator still exceeds the tool timeout at its last KS stage, so that final local-ray calculation is reported as a separately successful run rather than a successful single-process orchestrator.

## v1.3.5 — 2026-10-19

- Fixed Project B near-extremal horizon classification: the float64 scan no longer turns every extremum with a small residual into a tangent root, and the fixed `1e-6` root-deduplication tolerance no longer merges nearby roots in the fast path.
- Added an automatic `mpmath` 80-decimal-digit fallback for extrema near a horizon target. It recomputes the local near-extremum interval in arbitrary precision, refines the extremum, distinguishes no-root/tangent/two-root cases, and preserves close roots as `mp.mpf` values.
- Added an explicit `horizon_radii_high_precision` API and precision-matched `horizon_residual`; `horizon_convergence.py` now writes MP residuals and preserves high-precision root coordinates when the fallback activates.
- Added regressions for high-precision pair birth, a root pair shifted by `1e-20` across criticality, removal of a false tangent root that the old `1e-10` residual threshold could report, and agreement between automatic and explicit MP APIs. After release review, two more regression cases were added: a float64 value rounding to exactly zero at a grid node although the MP function has no root, and duplicate simple roots being reported by both the sign scan and extremum refinement.
- Corrected the spoken explanation: this implementation does not use Newton's method. Ordinary sign-changing roots use SciPy `brentq`; extrema are located from sampled slopes/`minimize_scalar`; the near-critical fallback uses `mpmath` derivative evaluation and bisection.
- Added `mpmath>=1.3` to shared and Project B dependencies. The v1.3.5 suite contained 47 tests (10 + 17 + 20) before the additional tangency-tolerance regression was added in v1.3.6. Local checks do not replace remote CI or independent review.
- Additional review sweep compares automatic and explicit high-precision root APIs across 30 combinations of three grid/domain configurations and ten time offsets; all root counts and roots agree within the selected comparison tolerance. Explicit scope: 80 dps is finite, candidate extrema are seeded by a finite grid, and a Python float input cannot preserve parameter/time differences already rounded away. Use an `mp.mpf` time inside `mp.workdps(...)` for sub-float64 critical offsets. This improves numerical robustness but is not a proof for all parameter space or of any physical black-to-white transition.

## v1.3.3 — 2026-10-19

- Reproducibly fixed the Project A static-convergence runner: `--static-convergence` now writes the same documented five-column CSV schema as the checked-in benchmark and compares the new asymptotic Robin estimate with the legacy finite-boundary estimate. An unbracketed legacy root is recorded as blank rather than fabricated.
- Added a retained legacy estimator solely for quantifying its finite-domain bias and a regression test showing the old estimator's error decreases with increasing outer boundary while the corrected threshold stays stable.
- Removed a redundant `max(..., 1e-12)` floor from the large-tortoise-coordinate Newton initial guess; the branch condition already guarantees its logarithm argument is positive.
- Made the Project C local Kantowski–Sachs null-ray solver's maximum proper-time step configurable, added validation for invalid steps/tolerances, and added max-step convergence tests.
- Synchronized stale documentation: the artifact sweep uses 13 representative epochs, the unit-test spot check uses 11; the release currently contains 42 tests (10 + 12 + 20).
- Refreshed canonical outputs, symbolic-check logs, test logs and all checksum manifests.
- Re-ran 42 local regression tests, the full canonical demonstration runs, and both optional SymPy curvature checks. The GitHub Actions workflow is defined, but remote CI and independent external replication remain unverified until the repository is pushed and reviewed.
- Kept the critical physical limits explicit: Project B is phenomenological; Project C's KS transit is local and stops before the outer horizon; global atlas matching, self-consistent collapse/backreaction, stability and observational confirmation remain open.

## v1.3.2 — 2026-10-19

- Audited both user-reported numerical concerns and documented which parts are present in the source versus inferred incorrectly from another metric/chart.
- Removed Project B's silent `r=max(r, 1e-10)` state clipping; integration now raises an explicit error if `r <= 0`.
- Replaced Project A's finite-boundary zero-mode residual `phi(X)+X*phi'(X)` with an eighth-order asymptotic Robin condition derived from the actual linear scalar ODE.
- Regenerated the static threshold table across `x=r/r_H=50...2000`, including the old estimator as an audit comparison.
- Added tests for asymptotic-series order convergence and stability against integration max-step changes.
- Changed the default static integration max step from 0.08 to 1.0 after a direct comparison showed `q_crit` stable to much better than the declared tolerance; this reduces canonical-run time without claiming improved physics.
- Recomputed the growth-rate spectrum, conditional growth integral, sensitivity table and plots under the corrected threshold.
- Added a local Kantowski–Sachs-chart radial null-ray integrator for Project C; it crosses the assumed reflection point and explicitly stops before the outer horizon. No global escape claim is made.
- Regenerated the Project B horizon convergence audit for 13 representative times and three `(r_max, n_grid)` configurations.
- Re-ran the full demonstration script, two symbolic curvature checks and the 39-test suite locally.
- Remote GitHub Actions and independent external replication remain unverified; full global causal structure, nonlinear backreaction and observations remain open.

## v1.3.1 — 2026-10-19

- Added a reproducible Project B horizon-root convergence audit over three `(r_max, n_grid)` configurations and representative epochs.
- Added a regression test requiring matching root counts, root locations, and residuals across the tested configurations.
- Cleaned generated Python bytecode from the source archive and refreshed checksums.

## v1.3.0 — 2026-10-19

- Added the full master research roadmap with nine work packages, exit criteria and explicit stop conditions.
- Added the math/code/model/empirical-physics boundary guide, cross-project audit, and CSV issue register.
- Added root-level dependencies and GitHub Actions CI for Python 3.10–3.12.
- Added dependency checks to Unix/PowerShell test runners.
- Added a reproducible canonical-runs script, separate from quick unit tests.
- Improved phenomenological horizon root detection to refine local extrema and detect tangent/double roots at horizon pair birth/death.
- Added regression tests for tangent roots and non-finite model parameters.
- Added `regular_bounce_chart.py` for a local proper-time reflected chart at the effective-LQG transition surface `h=0`.
- Derived and tested local Ricci scalar, Ricci-tensor square, and Kretschmann scalar values at the transition surface under the reflection-symmetry assumption.
- Added outer-horizon Kruskal-limit analysis and symbolic formulas for the curvature invariants at `x=2M`.
- Added optional SymPy-based independent tensor contraction checks and GitHub Actions configuration.
- No claim about physical black-to-white transitions is made; global geodesics, outer-horizon atlas, self-consistent collapse/backreaction, stability, and observations remain open.
