"""Fast repository-hygiene tests; run by the main test runner and CI."""
from __future__ import annotations

import re
import subprocess
import sys
import unittest
from pathlib import Path
from urllib.parse import unquote, urlsplit

from update_checksums import ROOT, should_include
from build_release import collect_archive_files, should_archive


class ReleaseIntegrityTests(unittest.TestCase):
    def test_regeneratable_validation_outputs_are_excluded_but_readme_is_kept(self) -> None:
        self.assertFalse(should_include(Path("validation_runs/example.csv")))
        self.assertFalse(should_include(Path("validation_runs/.matplotlib-config/fontlist.json")))
        self.assertTrue(should_include(Path("validation_runs/README.md")))

    def test_python_caches_and_root_manifest_are_excluded(self) -> None:
        self.assertFalse(should_include(Path("projects/demo/__pycache__/module.cpython-313.pyc")))
        self.assertFalse(should_include(Path("projects/demo/module.pyc")))
        self.assertFalse(should_include(Path("venv/lib/python/site.py")))
        self.assertFalse(should_include(Path(".tox/py313/lib/site.py")))
        self.assertFalse(should_include(Path("SHA256SUMS.txt")))
        self.assertTrue(should_include(Path("projects/demo/model.py")))
        self.assertTrue(should_include(Path("projects/demo/results/reference.csv")))

    def test_local_markdown_links_resolve(self) -> None:
        """Relative links to project files must not point to missing artifacts."""
        pattern = re.compile(r"(?<!!)\[[^\]]*\]\(([^)]+)\)")
        checked: list[str] = []
        skipped_parts = {".git", ".venv", "__pycache__", "validation_runs"}
        for markdown in ROOT.rglob("*.md"):
            if any(part in skipped_parts for part in markdown.relative_to(ROOT).parts):
                continue
            content = markdown.read_text(encoding="utf-8", errors="replace")
            for match in pattern.finditer(content):
                raw_target = match.group(1).strip().split(maxsplit=1)[0].strip("<>")
                parsed = urlsplit(raw_target)
                if parsed.scheme or parsed.netloc or raw_target.startswith("#"):
                    continue
                target = unquote(parsed.path)
                if not target:
                    continue
                resolved = (markdown.parent / target).resolve()
                checked.append(f"{markdown.relative_to(ROOT)} -> {raw_target}")
                self.assertTrue(
                    resolved.exists(),
                    msg=f"Broken local Markdown link in {markdown.relative_to(ROOT)}: {raw_target}",
                )
        self.assertGreaterEqual(len(checked), 10, "link audit should inspect the project's documented local references")

    def test_release_builder_excludes_generated_outputs_and_caches(self) -> None:
        """The release must be rebuildable without runtime artifacts."""
        files = collect_archive_files(ROOT)
        names = {path.as_posix() for path in files}
        self.assertIn("SHA256SUMS.txt", names)
        self.assertIn("validation_runs/README.md", names)
        self.assertIn("tools/build_release.py", names)
        self.assertNotIn("validation_runs/phenomenological/horizon_samples.csv", names)
        self.assertFalse(should_archive(Path("projects/demo/__pycache__/module.pyc")))
        self.assertFalse(should_archive(Path(".git/config")))
        self.assertFalse(should_archive(Path("venv/lib/python/site.py")))
        self.assertFalse(should_archive(Path("validation_runs/generated.csv")))
        self.assertTrue(should_archive(Path("projects/demo/model.py")))

    def test_checksum_manifest_is_current(self) -> None:
        command = [sys.executable, str(ROOT / "tools" / "update_checksums.py"), "--check"]
        result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)
        self.assertEqual(result.returncode, 0, msg=result.stdout + result.stderr)
        self.assertIn("immutable files", result.stdout)


if __name__ == "__main__":
    unittest.main()
