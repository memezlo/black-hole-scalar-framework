#!/usr/bin/env python3
"""Symbolically check curvature invariants of the static effective-LQG metric at x=2M.

Requires the optional dependency in `requirements-symbolic.txt`. The script
builds the Levi-Civita connection and curvature tensors from the metric rather
than copying the closed-form horizon expressions into a numerical test.

This checks local invariants in the stated effective metric only; it does not
prove a global transition or astrophysical white-hole existence.
"""
from __future__ import annotations

import sympy as sp


def main() -> None:
    t, x, theta, phi, M, Delta = sp.symbols("t x theta phi M Delta", positive=True, real=True)
    f = 1 - 2 * M / x
    h = 1 + Delta * f / x**2
    metric = sp.diag(-f, 1 / (h * f), x**2, x**2 * sp.sin(theta)**2)
    inverse = sp.simplify(metric.inv())
    coordinates = (t, x, theta, phi)
    n = 4

    gamma = [[[sp.S.Zero for _ in range(n)] for _ in range(n)] for _ in range(n)]
    for a in range(n):
        for b in range(n):
            for c in range(n):
                gamma[a][b][c] = sp.simplify(sum(
                    inverse[a, d] * (
                        sp.diff(metric[d, c], coordinates[b])
                        + sp.diff(metric[d, b], coordinates[c])
                        - sp.diff(metric[b, c], coordinates[d])
                    )
                    for d in range(n)
                ) / 2)

    riemann_up = [[[[sp.S.Zero for _ in range(n)] for _ in range(n)]
                   for _ in range(n)] for _ in range(n)]
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    value = sp.diff(gamma[a][d][b], coordinates[c]) - sp.diff(
                        gamma[a][c][b], coordinates[d]
                    )
                    value += sum(
                        gamma[a][c][e] * gamma[e][d][b]
                        - gamma[a][d][e] * gamma[e][c][b]
                        for e in range(n)
                    )
                    if value != 0:
                        riemann_up[a][b][c][d] = sp.trigsimp(sp.simplify(value))

    ricci = sp.zeros(n)
    for b in range(n):
        for d in range(n):
            ricci[b, d] = sp.factor(sp.simplify(sum(riemann_up[a][b][a][d] for a in range(n))))
    scalar = sp.factor(sp.simplify(sum(inverse[a, b] * ricci[a, b]
                                       for a in range(n) for b in range(n))))
    ricci_square = sp.factor(sp.simplify(sum(
        inverse[a, a] * inverse[b, b] * ricci[a, b] * ricci[a, b]
        for a in range(n) for b in range(n)
    )))
    kretschmann = sp.S.Zero
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    lowered = sp.simplify(metric[a, a] * riemann_up[a][b][c][d])
                    if lowered != 0:
                        kretschmann += (
                            inverse[a, a] * inverse[b, b] * inverse[c, c] * inverse[d, d]
                            * lowered**2
                        )
    kretschmann = sp.factor(sp.trigsimp(sp.simplify(kretschmann)))

    actual = [sp.simplify(sp.limit(expr, x, 2 * M)) for expr in (scalar, ricci_square, kretschmann)]
    expected = [
        -Delta / (32 * M**4),
        Delta**2 / (2048 * M**8),
        (Delta**2 - 32 * Delta * M**2 + 768 * M**4) / (1024 * M**8),
    ]
    names = ("Ricci scalar at x=2M", "Ricci tensor square at x=2M", "Kretschmann scalar at x=2M")
    for name, value, target in zip(names, actual, expected):
        residual = sp.simplify(value - target)
        print(f"{name} residual: {residual}")
        if residual != 0:
            raise SystemExit(f"FAILED symbolic identity: {name}")
    print("PASS: all outer-horizon curvature formulas verified by explicit symbolic tensor contraction and limits.")
    print("Scope: local invariants of the stated static effective metric only; global causality remains open.")


if __name__ == "__main__":
    main()
