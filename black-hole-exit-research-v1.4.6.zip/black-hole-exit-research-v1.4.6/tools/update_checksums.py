#!/usr/bin/env python3
"""Create or verify the immutable-content SHA-256 manifest for this package.

Generated `validation_runs/` outputs, interpreter caches, VCS metadata, build
folders, and the manifest itself are deliberately excluded. This means users
can rerun the canonical examples without making the source checksum manifest
stale.
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "SHA256SUMS.txt"


def should_include(relative: Path) -> bool:
    parts = relative.parts
    if not parts or relative.as_posix() == "SHA256SUMS.txt":
        return False
    excluded_dirs = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", "build", "dist", "node_modules"}
    if any(part in excluded_dirs for part in parts):
        return False
    if relative.suffix.lower() in {".pyc", ".pyo"} or relative.name == ".DS_Store":
        return False
    if parts[0] == "validation_runs/" or parts[0] == "validation_runs":
        return relative.as_posix() == "validation_runs/README.md"
    return True


def manifest_text(root: Path = ROOT) -> str:
    entries: list[str] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if not should_include(relative):
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        entries.append(f"{digest}  ./{relative.as_posix()}")
    entries.sort(key=lambda line: line.split("  ./", 1)[1])
    return "\n".join(entries) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--write", action="store_true", help="rewrite SHA256SUMS.txt")
    group.add_argument("--check", action="store_true", help="fail if SHA256SUMS.txt is stale (default)")
    args = parser.parse_args(argv)
    expected = manifest_text()
    if args.write:
        MANIFEST.write_text(expected, encoding="utf-8")
        print(f"Wrote {MANIFEST.relative_to(ROOT)} ({len(expected.splitlines())} files)")
        return 0
    if not MANIFEST.exists():
        print("SHA256SUMS.txt is missing; run with --write", file=sys.stderr)
        return 2
    actual = MANIFEST.read_text(encoding="utf-8")
    if actual != expected:
        print("SHA256SUMS.txt is stale. Run: python tools/update_checksums.py --write", file=sys.stderr)
        expected_lines = expected.splitlines()
        actual_lines = actual.splitlines()
        print(f"expected entries: {len(expected_lines)}; current entries: {len(actual_lines)}", file=sys.stderr)
        return 1
    print(f"SHA256SUMS.txt OK ({len(expected.splitlines())} immutable files; generated outputs and caches excluded)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
