#!/usr/bin/env python3
"""Build deterministic ZIP/TAR.GZ release archives and a SHA-256 sidecar.

Usage:
    python tools/build_release.py
    python tools/build_release.py --output-dir /path/to/output

The archives contain the immutable source, tests, docs, references, and the root
SHA256SUMS.txt manifest. Interpreter caches, VCS/venv/build folders, and all
regeneratable validation_runs outputs except validation_runs/README.md are
omitted. Archive paths are rooted at the repository directory name.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import stat
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_DIRS = {
    ".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", ".tox", "build", "dist", "node_modules",
}


def should_archive(relative: Path) -> bool:
    """Return whether a relative repository path belongs in a release archive."""
    if not relative.parts:
        return False
    if any(part in EXCLUDED_DIRS for part in relative.parts):
        return False
    if relative.suffix.lower() in {".pyc", ".pyo"} or relative.name == ".DS_Store":
        return False
    if relative.parts[0] == "validation_runs":
        return relative.as_posix() == "validation_runs/README.md"
    return True


def collect_archive_files(root: Path = ROOT) -> list[Path]:
    """Return a sorted list of archiveable regular files, relative to root."""
    files: list[Path] = []
    for path in root.rglob("*"):
        if path.is_symlink() or not path.is_file():
            continue
        relative = path.relative_to(root)
        if should_archive(relative):
            files.append(relative)
    files.sort(key=lambda path: path.as_posix())
    return files


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _archive_name(root: Path, relative: Path) -> str:
    return f"{root.name}/{relative.as_posix()}"


def build_zip(root: Path, files: list[Path], destination: Path) -> None:
    """Create a deterministic ZIP archive with preserved executable bits."""
    with zipfile.ZipFile(
        destination, mode="w", compression=zipfile.ZIP_DEFLATED, compresslevel=9,
        strict_timestamps=True,
    ) as archive:
        for relative in files:
            source = root / relative
            info = zipfile.ZipInfo(_archive_name(root, relative), date_time=(2020, 1, 1, 0, 0, 0))
            info.create_system = 3  # Unix permissions in external_attr.
            mode = stat.S_IMODE(source.stat().st_mode)
            file_type = stat.S_IFREG
            info.external_attr = (file_type | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            info.flag_bits |= 0x800  # UTF-8 names.
            archive.writestr(info, source.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def build_tar_gz(root: Path, files: list[Path], destination: Path) -> None:
    """Create a deterministic gzip-compressed PAX tar archive."""
    with destination.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for relative in files:
                    source = root / relative
                    info = tarfile.TarInfo(_archive_name(root, relative))
                    info.size = source.stat().st_size
                    info.mtime = 0
                    info.uid = 0
                    info.gid = 0
                    info.uname = ""
                    info.gname = ""
                    info.mode = stat.S_IMODE(source.stat().st_mode)
                    with source.open("rb") as handle:
                        archive.addfile(info, handle)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir", type=Path, default=ROOT.parent,
        help="directory for the archives and checksum sidecar (default: parent of the repository)",
    )
    args = parser.parse_args(argv)
    output_dir = args.output_dir.expanduser().resolve()
    root = ROOT.resolve()
    try:
        output_dir.relative_to(root)
    except ValueError:
        pass
    else:
        parser.error("--output-dir must be outside the repository tree")

    output_dir.mkdir(parents=True, exist_ok=True)
    stem = root.name
    zip_path = output_dir / f"{stem}.zip"
    tar_path = output_dir / f"{stem}.tar.gz"
    sums_path = output_dir / f"{stem}-SHA256.txt"
    files = collect_archive_files(root)
    build_zip(root, files, zip_path)
    build_tar_gz(root, files, tar_path)
    # Only list files that actually exist beside the sidecar so the standard
    # `sha256sum -c <sidecar>` command succeeds. The inner manifest digest is
    # recorded as a comment; it is a member of the archives, not a sidecar file.
    sums_path.write_text(
        "".join(
            f"{sha256_file(path)}  {path.name}\n"
            for path in (zip_path, tar_path)
        ) + f"# SHA256SUMS.txt inside archive (verify after extraction): {sha256_file(root / 'SHA256SUMS.txt')}\n",
        encoding="utf-8",
    )
    print(f"Release files included: {len(files)}")
    print(f"ZIP: {zip_path} ({zip_path.stat().st_size:,} bytes, SHA-256 {sha256_file(zip_path)})")
    print(f"TAR.GZ: {tar_path} ({tar_path.stat().st_size:,} bytes, SHA-256 {sha256_file(tar_path)})")
    print(f"Checksums: {sums_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
