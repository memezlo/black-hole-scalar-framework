#!/usr/bin/env python3
"""Independently verify the local curvature formulas with symbolic tensors.

Optional dependency: `python -m pip install -r requirements-symbolic.txt`.
This script builds the metric diag(-1, A(tau), x(tau)^2, x(tau)^2 sin(theta)^2),
constructs its Levi-Civita connection, Ricci tensor and Riemann tensor, then
checks the invariant formulas at a reflection point where A'=x'=0.

This is a local geometric identity check. It does not validate the effective
LQG field equations or prove a global black-to-white transition.
"""
from __future__ import annotations

import sympy as sp


def main() -> None:
    tau, y, theta, phi = sp.symbols("tau y theta phi", real=True)
    coordinates = (tau, y, theta, phi)
    A = sp.Function("A")(tau)
    x = sp.Function("x")(tau)
    metric = sp.diag(-1, A, x**2, x**2 * sp.sin(theta)**2)
    inverse = sp.simplify(metric.inv())
    n = len(coordinates)

    gamma = [[[sp.S.Zero for _ in range(n)] for _ in range(n)] for _ in range(n)]
    for a in range(n):
        for b in range(n):
            for c in range(n):
                gamma[a][b][c] = sp.simplify(sum(
                    inverse[a, d] * (
                        sp.diff(metric[d, c], coordinates[b])
                        + sp.diff(metric[d, b], coordinates[c])
                        - sp.diff(metric[b, c], coordinates[d])
                    )
                    for d in range(n)
                ) / 2)

    # R^a_{ b c d } = d_c Gamma^a_{db} - d_d Gamma^a_{cb}
    #                  + Gamma^a_{ce} Gamma^e_{db} - Gamma^a_{de} Gamma^e_{cb}.
    riemann_up = [[[[sp.S.Zero for _ in range(n)] for _ in range(n)]
                   for _ in range(n)] for _ in range(n)]
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    value = sp.diff(gamma[a][d][b], coordinates[c]) - sp.diff(
                        gamma[a][c][b], coordinates[d]
                    )
                    value += sum(
                        gamma[a][c][e] * gamma[e][d][b]
                        - gamma[a][d][e] * gamma[e][c][b]
                        for e in range(n)
                    )
                    if value != 0:
                        riemann_up[a][b][c][d] = sp.trigsimp(sp.simplify(value))

    ricci = sp.zeros(n)
    for b in range(n):
        for d in range(n):
            ricci[b, d] = sp.simplify(sum(riemann_up[a][b][a][d] for a in range(n)))

    ricci_scalar = sp.simplify(sum(
        inverse[a, b] * ricci[a, b] for a in range(n) for b in range(n)
    ))
    ricci_square = sp.simplify(sum(
        inverse[a, a] * inverse[b, b] * ricci[a, b] * ricci[a, b]
        for a in range(n) for b in range(n)
    ))

    # With a diagonal metric, contract the fully lowered Riemann tensor using
    # four diagonal inverse-metric factors.
    kretschmann = sp.S.Zero
    for a in range(n):
        for b in range(n):
            for c in range(n):
                for d in range(n):
                    lowered = sp.simplify(metric[a, a] * riemann_up[a][b][c][d])
                    if lowered != 0:
                        kretschmann += (
                            inverse[a, a] * inverse[b, b] * inverse[c, c] * inverse[d, d]
                            * lowered**2
                        )
    kretschmann = sp.trigsimp(sp.simplify(kretschmann))

    A0, x0, A2, x2 = sp.symbols("A0 x0 A2 x2", nonzero=True, real=True)
    bounce = {
        sp.diff(A, tau): 0,
        sp.diff(A, tau, 2): A2,
        sp.diff(x, tau): 0,
        sp.diff(x, tau, 2): x2,
        A: A0,
        x: x0,
    }
    actual_R = sp.simplify(ricci_scalar.subs(bounce))
    actual_S = sp.simplify(ricci_square.subs(bounce))
    actual_K = sp.simplify(kretschmann.subs(bounce))

    U = A2 / (2 * A0)
    V = x2 / x0
    W = 1 / x0**2
    expected_R = A2 / A0 + 4 * x2 / x0 + 2 / x0**2
    expected_S = (U + 2 * V)**2 + U**2 + 2 * (V + W)**2
    expected_K = (A2 / A0)**2 + 8 * (x2 / x0)**2 + 4 / x0**4

    checks = {
        "Ricci scalar R": sp.simplify(actual_R - expected_R),
        "Ricci tensor square R_ab R^ab": sp.simplify(actual_S - expected_S),
        "Kretschmann scalar R_abcd R^abcd": sp.simplify(actual_K - expected_K),
    }
    for name, residual in checks.items():
        print(f"{name} residual: {residual}")
        if residual != 0:
            raise SystemExit(f"FAILED: symbolic identity did not simplify to zero: {name}")
    print("PASS: all local bounce curvature formulas verified by explicit symbolic tensor contraction.")
    print("Scope: this is not a global atlas or a derivation of the full effective-LQG dynamics.")


if __name__ == "__main__":
    main()
