#!/usr/bin/env bash
# Re-run the canonical examples and put fresh outputs in validation_runs/.
# This is separate from unit tests because the full plots/integrations take longer.
set -euo pipefail
PHASE="${1:-all}"
case "$PHASE" in
  all|core|trajectories|flux|coupled|diagnostics) ;;
  *) echo "Usage: bash run_all_reproductions.sh [all|core|trajectories|flux|coupled|diagnostics]" >&2; exit 2 ;;
esac
# Keep per-stage Python output visible in terminal logs even when redirected.
export PYTHONUNBUFFERED=1
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/validation_runs"
mkdir -p "$OUT"
# Use a fresh Matplotlib cache per run. Reusing one left by a killed process
# can leave a stale font-cache lock; sharing this fresh cache is safe because
# the reproduction stages run sequentially in this script.
MPL_TMP=""
if [[ -z "${MPLCONFIGDIR:-}" ]]; then
  MPL_TMP="$(mktemp -d "${TMPDIR:-/tmp}/bhe-mpl.XXXXXX")"
  export MPLCONFIGDIR="$MPL_TMP"
  trap 'rm -rf "$MPL_TMP"' EXIT
else
  mkdir -p "$MPLCONFIGDIR"
  export MPLCONFIGDIR
fi
export MPLBACKEND=Agg
if [[ "$PHASE" == "all" || "$PHASE" == "core" ]]; then
  echo "[1/14] Project A: scalar instability and toy growth integral"
  (cd "$ROOT/projects/scalar-gauss-bonnet-instability" && \
   python -u black_hole_scalar_model.py --ell-gb 100 --delta-log 10 --qmax 0.85 \
     --outdir "$OUT/scalar-gauss-bonnet")
  # High-cost boundary-convergence reruns and plotting are kept as explicit
  # diagnostics, separate from the bounded full reproduction suite. The checked-
  # in convergence table and plots were regenerated after the v1.3.9 grid update.
  # To rerun the boundary convergence and plots independently, use:
  # (cd "$ROOT/projects/scalar-gauss-bonnet-instability" && \
  #  python -u black_hole_scalar_model.py --ell-gb 100 --delta-log 10 --qmax 0.85 \
  #    --outdir "$OUT/scalar-gauss-bonnet-diagnostics" --static-convergence --plot)
  echo "[2/14] Project B: phenomenological horizon table and plot"
  (cd "$ROOT/projects/black-white-transition-metric-study" && \
   python -u model.py --outdir "$OUT/phenomenological" --r-max 60 --n-grid 6001 --plot)
  # Keep canonical runs out of the curated source/result tree. The two generated
  # copies below live under validation_runs and do not invalidate checked-in hashes.
  echo "[3/14] Project B: high-precision near-extremal benchmark"
  mkdir -p "$OUT/near-extremal-horizon-benchmark"
  # The arbitrary-precision extremum/root refinement controls local accuracy;
  # use a moderate scan grid here. The independent convergence audit still uses
  # the 1001/3001/6001 grid/domain sweep.
  (cd "$ROOT/projects/black-white-transition-metric-study" && \
   python -u near_extremal_horizon_benchmark.py --n-grid 1501 \
     --out "$OUT/near-extremal-horizon-benchmark/project.csv" \
     --also-write "$OUT/near-extremal-horizon-benchmark/root-mirror.csv")
  cmp -s "$OUT/near-extremal-horizon-benchmark/project.csv" \
    "$OUT/near-extremal-horizon-benchmark/root-mirror.csv"
fi

if [[ "$PHASE" == "all" || "$PHASE" == "trajectories" ]]; then
  echo "[4/14] Project B: finite-time outgoing null-ray integration"
  (cd "$ROOT/projects/black-white-transition-metric-study" && \
   python -u trace_null_ray.py --outdir "$OUT/phenomenological" --t-start -5 --t-end 200 \
     --r-start 7 --max-step 0.05 --sample-count 1026)
  echo "[5/14] Project B: long finite-time outgoing null-ray integration"
  (cd "$ROOT/projects/black-white-transition-metric-study" && \
   python -u trace_null_ray.py --outdir "$OUT/phenomenological_long" --t-start -5 --t-end 10000 \
     --r-start 7 --max-step 5.0 --sample-count 101 --no-plot)
  echo "[6/14] Project C: effective LQG transition-surface algebra"
  (cd "$ROOT/projects/lqg-effective-transition-benchmark" && \
   python -u model.py --outdir "$OUT/effective-lqg" --mass-min 0.1 --mass-max 1e5 --n 400 && \
   echo "[7/14] Project C: local reflected KS-chart curvature" && \
   python -u regular_bounce_chart.py --outdir "$OUT/effective-lqg-local" --delta 1 --mass-min 0.1 --mass-max 1e3 --n 40 && \
   echo "[8/14] Project C: outer-horizon patch and local KS ray" && \
   python -u horizon_extension.py --outdir "$OUT/effective-lqg-horizon" --delta 1 --mass-min 0.1 --mass-max 1e3 --n 40 && \
   python -u trace_null_ray_ks.py --outdir "$OUT/effective-lqg-null-ray" --mass 10 --delta 1 --tau-max 0.5 --samples 401 --max-step 0.005)
fi

if [[ "$PHASE" == "all" || "$PHASE" == "flux" ]]; then
  echo "[9/14] Project D: published low-frequency Hawking flux integral"
  (cd "$ROOT/projects/lqg-hawking-flux-reproduction" && \
   python -u run_example.py --delta 1 --initial-mass 100 --output "$OUT/published-low-frequency-flux")
  echo "[10/14] Project D: direct static-metric scalar s-wave scattering"
  (cd "$ROOT/projects/lqg-hawking-flux-reproduction" && \
   python -u run_exact_scattering.py --deltas 0 0.05775591715976331 1 --grid-size 30 --z-min 0.01 \
     --output "$OUT/numerical-greybody-scattering")
  echo "[11/14] Project E: toy Page-curve entropy bookkeeping"
  (cd "$ROOT/projects/information-paradox-diagnostic" && \
   python -u run_example.py --eta-eff 1.3333333333333333 --output "$OUT/toy-page-curve")
fi
if [[ "$PHASE" == "all" || "$PHASE" == "coupled" ]]; then
  echo "[12/14] Project F: coupled quasi-static pre-threshold evolution"
  (cd "$ROOT" && python -u projects/coupled-quasistatic-evolution/coupled_evolution.py \
    --ell-gb 100 --delta-log 10 --qmax 0.85 --samples 1001 \
    --output "$OUT/coupled-quasistatic-evolution")
fi
if [[ "$PHASE" == "all" || "$PHASE" == "diagnostics" ]]; then
  echo "[13/14] Project G: nonlinear closure sensitivity"
  (cd "$ROOT/projects/nonlinear-closure-sensitivity" && \
   python -u run_example.py --output-dir "$OUT/nonlinear-closure-sensitivity")
  echo "[14/14] Project H: finite-dimensional Page benchmark"
  (cd "$ROOT/projects/unitary-page-benchmark" && \
   python -u run_example.py --qubits 8 --samples 64 --seed 20261020 --output-dir "$OUT/unitary-page-benchmark")
fi

echo "Canonical reproduction phase '$PHASE' finished. Fresh outputs are under: $OUT"
