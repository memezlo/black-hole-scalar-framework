#!/usr/bin/env python3
"""Run the closure-underdetermination demonstration and save CSV/summary."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
from nonlinear_closures import ClosureParameters, simulate, analytic_saturation_amplitude

HERE = Path(__file__).resolve().parent

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--gamma', type=float, default=0.05)
    p.add_argument('--nonlinear-rate', type=float, default=0.1)
    p.add_argument('--duration', type=float, default=300.0)
    p.add_argument('--samples', type=int, default=1001)
    p.add_argument('--output-dir', type=Path, default=HERE / 'results')
    args = p.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summaries = {}
    for closure in ('saturating', 'runaway'):
        params = ClosureParameters(gamma=args.gamma, nonlinear_rate=args.nonlinear_rate,
                                   closure=closure, duration=args.duration, samples=args.samples)
        rows = simulate(params)
        csv_path = args.output_dir / f'{closure}_closure.csv'
        with csv_path.open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader(); writer.writerows(rows)
        summaries[closure] = {
            'rows': len(rows), 'last_time': rows[-1]['time'],
            'last_amplitude': rows[-1]['amplitude'],
            'maximum_absolute_energy_ledger_error': max(abs(float(r['ledger_total_change'])) for r in rows),
            'interpretation': 'phenomenological normal form only; not a black-hole field solution',
        }
    summaries['shared_linearization'] = 'dA/dt = Gamma*A + O(A^3) for both closures'
    summaries['saturating_fixed_point'] = analytic_saturation_amplitude(args.gamma, args.nonlinear_rate)
    (args.output_dir / 'closure_sensitivity_summary.json').write_text(json.dumps(summaries, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(summaries, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
