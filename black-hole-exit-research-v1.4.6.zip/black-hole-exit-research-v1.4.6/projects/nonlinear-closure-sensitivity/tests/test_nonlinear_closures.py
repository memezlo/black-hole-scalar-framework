import math
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from nonlinear_closures import (ClosureParameters, amplitude_rhs,
                                analytic_saturation_amplitude,
                                energy_ledger_rhs, simulate)

class NonlinearClosureTests(unittest.TestCase):
    def test_same_linearization_at_small_amplitude(self):
        a, gamma, lam = 1e-8, 0.2, 0.3
        s = amplitude_rhs(a, gamma, lam, 'saturating')
        r = amplitude_rhs(a, gamma, lam, 'runaway')
        self.assertAlmostEqual(s/a, gamma, delta=1e-14)
        self.assertAlmostEqual(r/a, gamma, delta=1e-14)

    def test_nonlinear_futures_differ(self):
        a, gamma, lam = 1.0, 0.2, 0.3
        self.assertLess(amplitude_rhs(a, gamma, lam, 'saturating'), 0)
        self.assertGreater(amplitude_rhs(a, gamma, lam, 'runaway'), 0)

    def test_energy_ledger_closes_for_both_closures(self):
        for closure in ('saturating', 'runaway'):
            result = energy_ledger_rhs(0.37, 0.12, 0.08, 2.5, closure)
            self.assertAlmostEqual(result['total_energy_rate'], 0.0, delta=1e-14)

    def test_saturation_fixed_point(self):
        gamma, lam = 0.2, 0.8
        a_star = analytic_saturation_amplitude(gamma, lam)
        self.assertAlmostEqual(amplitude_rhs(a_star, gamma, lam, 'saturating'), 0.0, places=14)

    def test_integrated_energy_ledger_stays_closed(self):
        rows = simulate(ClosureParameters(gamma=0.02, nonlinear_rate=0.1,
                                         energy_scale=0.4, initial_amplitude=1e-3,
                                         stop_amplitude=2.0, duration=30, samples=51,
                                         closure='saturating'))
        self.assertLess(max(abs(float(r['ledger_total_change'])) for r in rows), 1e-9)

    def test_invalid_closure_rejected(self):
        with self.assertRaises(ValueError):
            amplitude_rhs(0.1, 0.2, 0.3, 'mystery')
        with self.assertRaises(ValueError):
            ClosureParameters(initial_amplitude=1.0, stop_amplitude=0.5).validate()
        with self.assertRaises(ValueError):
            energy_ledger_rhs(0.1, math.nan, 0.2, 1.0, 'saturating')

if __name__ == '__main__':
    unittest.main()
