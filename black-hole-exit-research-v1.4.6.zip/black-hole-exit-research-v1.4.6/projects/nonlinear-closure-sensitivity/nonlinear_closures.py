#!/usr/bin/env python3
"""Compare nonlinear closures with the same linear instability.

This is a mathematical identifiability diagnostic, NOT a black-hole field
solution. It demonstrates that the pre-threshold equation dA/dt = Gamma*A
cannot determine the late-time outcome without independently derived
nonlinear terms and a consistent stress tensor.

Two closures share the same linearization at A=0:
  saturation: dA/dt = Gamma*A - lambda*A**3
  runaway:    dA/dt = Gamma*A + lambda*A**3
For constant Gamma > 0 and lambda > 0, the first has a stable nonzero fixed
point; the second increases without bound in this normal-form model.

An optional energy ledger E_cloud = E_scale*A**2 is included. Its transfer
terms are defined to make the ledger close identically; that is bookkeeping,
not a derivation from Einstein's equations.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Literal

import numpy as np
from scipy.integrate import solve_ivp

Closure = Literal["saturating", "runaway"]


@dataclass(frozen=True)
class ClosureParameters:
    gamma: float = 0.05
    nonlinear_rate: float = 0.1
    energy_scale: float = 1.0
    initial_amplitude: float = 1e-3
    stop_amplitude: float = 1.0
    closure: Closure = "saturating"
    duration: float = 300.0
    samples: int = 1001

    def validate(self) -> None:
        for name in ("gamma", "nonlinear_rate", "energy_scale", "initial_amplitude", "stop_amplitude", "duration"):
            value = getattr(self, name)
            if not math.isfinite(value) or value < 0:
                raise ValueError(f"{name} must be finite and non-negative")
        if self.energy_scale <= 0:
            raise ValueError("energy_scale must be positive")
        if self.initial_amplitude <= 0 or self.stop_amplitude <= self.initial_amplitude:
            raise ValueError("require 0 < initial_amplitude < stop_amplitude")
        if self.closure not in ("saturating", "runaway"):
            raise ValueError("closure must be 'saturating' or 'runaway'")
        if self.duration <= 0 or not isinstance(self.samples, int) or self.samples < 3:
            raise ValueError("duration must be positive and samples must be an integer >= 3")


def amplitude_rhs(amplitude: float, gamma: float, nonlinear_rate: float,
                  closure: Closure) -> float:
    """Return dA/dt. Both modes linearize to Gamma*A as A -> 0."""
    if not all(math.isfinite(x) for x in (amplitude, gamma, nonlinear_rate)):
        raise ValueError("amplitude and rates must be finite")
    if amplitude < 0 or nonlinear_rate < 0:
        raise ValueError("amplitude and nonlinear_rate must be non-negative")
    if closure == "saturating":
        return gamma * amplitude - nonlinear_rate * amplitude**3
    if closure == "runaway":
        return gamma * amplitude + nonlinear_rate * amplitude**3
    raise ValueError("closure must be 'saturating' or 'runaway'")


def energy_ledger_rhs(amplitude: float, gamma: float, nonlinear_rate: float,
                      energy_scale: float, closure: Closure) -> dict[str, float]:
    """Construct a closed toy ledger for cloud, hole, and radiation powers.

    Here E_cloud=energy_scale*A**2. L_H is omitted as a separate common term;
    callers may add it equally as -L_H to the hole and +L_H to radiation.
    Values are power-transfer terms in the model's chosen units.
    """
    if not all(math.isfinite(x) for x in (amplitude, gamma, nonlinear_rate, energy_scale)):
        raise ValueError("energy-ledger inputs must be finite")
    if energy_scale <= 0 or amplitude < 0 or nonlinear_rate < 0:
        raise ValueError("invalid energy-ledger inputs")
    if closure == "saturating":
        # Cloud receives 2 E*Gamma*A^2, and dissipates 2 E*lambda*A^4.
        p_hole_to_cloud = 2.0 * energy_scale * gamma * amplitude**2
        p_cloud_to_rad = 2.0 * energy_scale * nonlinear_rate * amplitude**4
    elif closure == "runaway":
        # In this closure both linear and cubic growth draw energy from the hole.
        p_hole_to_cloud = 2.0 * energy_scale * (gamma * amplitude**2 + nonlinear_rate * amplitude**4)
        p_cloud_to_rad = 0.0
    else:
        raise ValueError("unknown closure")
    d_e_cloud = p_hole_to_cloud - p_cloud_to_rad
    d_e_hole = -p_hole_to_cloud
    d_e_rad = p_cloud_to_rad
    return {
        "dE_hole_dt": d_e_hole,
        "dE_cloud_dt": d_e_cloud,
        "dE_radiation_dt": d_e_rad,
        "total_energy_rate": d_e_hole + d_e_cloud + d_e_rad,
    }


def simulate(params: ClosureParameters) -> list[dict[str, float | str]]:
    """Integrate amplitude and the toy energy ledger until stop or duration.

    State is [A, E_hole_transfer, E_radiated], excluding a separate Hawking
    baseline flux. The ledger terms close by construction. A maximum-amplitude
    event prevents the runaway branch from being numerically continued beyond
    its defined diagnostic range.
    """
    params.validate()
    e0 = params.energy_scale * params.initial_amplitude**2

    def rhs(t: float, state: np.ndarray) -> list[float]:
        a = max(float(state[0]), 0.0)
        adot = amplitude_rhs(a, params.gamma, params.nonlinear_rate, params.closure)
        ledger = energy_ledger_rhs(a, params.gamma, params.nonlinear_rate,
                                   params.energy_scale, params.closure)
        return [adot, ledger["dE_hole_dt"], ledger["dE_radiation_dt"]]

    def stop_event(t: float, state: np.ndarray) -> float:
        return params.stop_amplitude - float(state[0])
    stop_event.terminal = True  # type: ignore[attr-defined]
    stop_event.direction = -1   # type: ignore[attr-defined]

    sol = solve_ivp(rhs, (0.0, params.duration),
                    [params.initial_amplitude, 0.0, 0.0], method="DOP853",
                    rtol=1e-10, atol=1e-13, dense_output=True,
                    events=stop_event, max_step=params.duration / 500.0)
    if not sol.success:
        raise RuntimeError(sol.message)
    ts = np.linspace(0.0, float(sol.t[-1]), params.samples)
    ys = sol.sol(ts)
    rows: list[dict[str, float | str]] = []
    for t, a, eh, er in zip(ts, ys[0], ys[1], ys[2]):
        ecloud = params.energy_scale * float(a)**2
        rows.append({
            "time": float(t), "amplitude": float(a), "closure": params.closure,
            "hole_energy_change": float(eh), "cloud_energy": ecloud,
            "radiated_energy": float(er),
            "ledger_total_change": float(eh) + ecloud - e0 + float(er),
        })
    return rows


def analytic_saturation_amplitude(gamma: float, nonlinear_rate: float) -> float:
    """Stable positive fixed point for the saturating normal form (if Gamma>0)."""
    if gamma < 0 or nonlinear_rate <= 0 or not math.isfinite(gamma + nonlinear_rate):
        raise ValueError("require finite gamma >= 0 and nonlinear_rate > 0")
    return math.sqrt(gamma / nonlinear_rate)
