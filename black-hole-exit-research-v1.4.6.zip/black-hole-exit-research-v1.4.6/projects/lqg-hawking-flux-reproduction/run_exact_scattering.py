#!/usr/bin/env python3
"""Benchmark exact numerical s-wave scattering against the paper's LF formula.

This solves the radial equation for the static effective exterior metric on a
frequency grid. The emitted-flux integral is then estimated by interpolating
that grid. The result is a single massless scalar s-wave diagnostic only; it
is not a complete Hawking luminosity (which needs all relevant species and
angular modes), not a dynamic-backreaction solution, and not an info-paradox
calculation.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from pathlib import Path
import sys

import numpy as np
from scipy.integrate import quad
from scipy.interpolate import PchipInterpolator

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from greybody_scattering import ScatteringSettings, transmission_probability
from hawking_flux import dimensionless_emission_integral, transmission_s_wave


def bose_flux_integrand(z: float, transmission: float) -> float:
    if z <= 0:
        return 0.0
    x = 8.0 * math.pi * z
    bose = math.exp(-x) if x > 700 else 1.0 / math.expm1(x)
    return z * transmission * bose


def exact_flux_estimate(z_grid: np.ndarray, t_grid: np.ndarray) -> dict[str, float]:
    """Interpolate T(z) monotonically and integrate with transparent tails.

    Low-z tail uses universal leading behavior T~16 z^2; high-z tail uses
    T<=1 as a rigorous upper bound, not a claimed exact tail value.
    """
    if len(z_grid) < 8 or np.any(np.diff(z_grid) <= 0):
        raise ValueError("z_grid must have >=8 strictly increasing frequencies")
    if np.any(t_grid < 0) or np.any(t_grid > 1.0 + 1e-6):
        raise ValueError("numerical transmission probability must lie in [0,1]")
    interp = PchipInterpolator(z_grid, t_grid, extrapolate=False)
    zlo, zhi = float(z_grid[0]), float(z_grid[-1])
    middle, middle_err = quad(lambda z: bose_flux_integrand(z, float(interp(z))),
                              zlo, zhi, epsabs=1e-12, epsrel=2e-5, limit=300)
    # For T~16 z^2 and exp(8*pi*z)-1~8*pi*z, leading integrand is 2 z^2/pi.
    low_tail = 2.0 * zlo**3 / (3.0 * math.pi)
    # Actual high-z tail is no larger than this T=1 envelope.
    high_tail_upper, _ = quad(lambda z: bose_flux_integrand(z, 1.0), zhi, math.inf,
                              epsabs=1e-14, epsrel=1e-8, limit=300)
    j_lower = low_tail + middle
    j_upper = j_lower + high_tail_upper
    # Approximation formula only used for the same covered frequency interval;
    # its all-frequency integral is also reported by the base project tables.
    return {
        "J_middle_interpolated": float(middle),
        "J_low_z_leading_tail": float(low_tail),
        "J_high_z_upper_bound": float(high_tail_upper),
        "J_total_central_estimate": float(j_lower),
        "J_total_central_plus_high_tail_envelope": float(j_upper),
        "interpolation_quad_error_estimate": float(middle_err),
        "relative_tail_bound_width": float(high_tail_upper / j_lower),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--deltas', type=float, nargs='+', default=[0.0, 1.0/(4.16**2), 1.0],
                        help='dimensionless delta=Delta/M^2 values to compare')
    parser.add_argument('--grid-size', type=int, default=22, help='number of log-spaced z nodes, minimum 12')
    parser.add_argument('--z-min', type=float, default=0.01, help='smallest dimensionless frequency')
    parser.add_argument('--z-max', type=float, default=0.75, help='largest dimensionless frequency')
    parser.add_argument('--output', type=Path, default=HERE / 'results' / 'exact-scattering')
    args = parser.parse_args()
    if args.grid_size < 12:
        parser.error('--grid-size must be >= 12')
    if not (math.isfinite(args.z_min) and math.isfinite(args.z_max) and 0 < args.z_min < args.z_max):
        parser.error('require 0 < z-min < z-max')
    if any(not math.isfinite(d) or d < 0 for d in args.deltas):
        parser.error('--deltas values must be finite and non-negative')

    # Include points near changes in the published rational coefficient so the
    # comparison cannot be determined solely by the log grid.
    z_grid = np.unique(np.concatenate([
        np.geomspace(args.z_min, args.z_max, args.grid_size),
        np.asarray([0.01, 0.02, 0.04, 0.08, 0.1, 0.2, 0.25, 0.3, 0.5])
    ]))
    z_grid = z_grid[(z_grid >= args.z_min) & (z_grid <= args.z_max)]
    args.output.mkdir(parents=True, exist_ok=True)
    settings = ScatteringSettings()
    summary = {
        'model': 'Numerical s-wave scattering on selected static effective LQG-inspired exterior metric',
        'source_comparison': 'Belfaqih et al., Phys. Rev. Lett. 135, 161501 (2025), DOI 10.1103/t6q4-4l77',
        'dimensionless_frequency': 'z=M*omega',
        'dimensionless_quantum_parameter': 'delta=Delta/M^2',
        'settings': {
            'horizon_epsilon': settings.horizon_epsilon,
            'r_max_rule': 'max(minimum_r_max, r_max_factor_over_z/z)',
            'minimum_r_max': settings.minimum_r_max,
            'r_max_factor_over_z': settings.r_max_factor_over_z,
            'max_step': settings.max_step,
            'rtol': settings.rtol,
            'atol': settings.atol,
        },
        'frequency_grid': [float(z) for z in z_grid],
        'per_delta': {},
        'scope_warning': 'This is a static metric, one massless scalar s-wave, and a frequency-grid/interpolation estimate with bounded high-frequency tail. It does not include all angular modes/species, time-dependent backreaction, a full quantum state, or unitarity.',
    }

    for delta in args.deltas:
        rows = []
        num_t = []
        num_r = []
        for z in z_grid:
            result = transmission_probability(float(z), float(delta), settings)
            t_approx = transmission_s_wave(float(z), 1.0, float(delta))
            row = {
                'delta_dimensionless': f'{delta:.16g}',
                'z_M_omega': f'{z:.16g}',
                'omega_over_T_H': f'{8.0*math.pi*z:.16g}',
                'T_numerical': f'{result.transmission:.16g}',
                'R_numerical': f'{result.reflection:.16g}',
                'T_plus_R_minus_1': f'{result.flux_balance_error:.8g}',
                'T_published_low_frequency_formula': f'{t_approx:.16g}',
                'published_formula_exceeds_one': str(t_approx > 1.0),
                'r_max': f'{result.r_max_used:.16g}',
                'nfev': result.function_evaluations,
            }
            rows.append(row)
            num_t.append(result.transmission)
            num_r.append(result.reflection)
        out_csv = args.output / f'greybody_delta_{delta:.8g}.csv'
        with out_csv.open('w', newline='', encoding='utf-8') as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
            writer.writeheader(); writer.writerows(rows)
        tarr = np.asarray(num_t)
        rarr = np.asarray(num_r)
        estimate = exact_flux_estimate(z_grid, tarr)
        # Reproduce the all-frequency integral of the displayed low-frequency
        # expression for comparison; it is explicitly not treated as exact.
        j_published_lf, j_published_lf_error = dimensionless_emission_integral(
            1.0, float(delta)
        )

        # Leave-one-subgrid-out sensitivity diagnostic: approximate the middle
        # integral after selecting every other node. This tests interpolation
        # sensitivity; it is not a full independent ODE convergence study.
        coarse = exact_flux_estimate(z_grid[::2] if len(z_grid[::2]) >= 8 else z_grid,
                                     tarr[::2] if len(tarr[::2]) >= 8 else tarr)
        k = f'{delta:.8g}'
        summary['per_delta'][k] = {
            'data_csv': out_csv.name,
            'points': int(len(z_grid)),
            'max_abs_flux_balance_error': float(np.max(np.abs([float(row['T_plus_R_minus_1']) for row in rows]))),
            'min_numerical_transmission': float(np.min(tarr)),
            'max_numerical_transmission': float(np.max(tarr)),
            'count_published_low_frequency_T0_gt_1': int(sum(float(row['T_published_low_frequency_formula']) > 1 for row in rows)),
            'exact_metric_scattering_flux_integral_estimate': estimate,
            'published_low_frequency_formula_integral_extrapolated_to_infinity': float(j_published_lf),
            'published_formula_quadrature_error_estimate': float(j_published_lf_error),
            'numerical_to_published_flux_ratio': float(estimate['J_total_central_estimate'] / j_published_lf),
            'relative_difference_numerical_vs_published': float(estimate['J_total_central_estimate'] / j_published_lf - 1.0),
            'coarse_subgrid_flux_integral_estimate': coarse,
            'coarse_vs_full_relative_difference': float(abs(coarse['J_total_central_estimate'] - estimate['J_total_central_estimate']) / estimate['J_total_central_estimate']),
        }
        print(f'delta={delta:.8g}: T in [{np.min(tarr):.6g},{np.max(tarr):.6g}], '
              f'max |T+R-1|={summary["per_delta"][k]["max_abs_flux_balance_error"]:.3e}, '
              f'J≈{estimate["J_total_central_estimate"]:.8g}, high-tail envelope +{estimate["J_high_z_upper_bound"]:.2g}')

    (args.output / 'exact_scattering_summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(f'Wrote exact-scattering benchmark to {args.output}')
    print('Interpretation: numerical greybody factors for the chosen static effective metric only; not a solution to the information paradox.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
