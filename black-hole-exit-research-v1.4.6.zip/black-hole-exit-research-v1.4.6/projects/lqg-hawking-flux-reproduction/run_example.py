#!/usr/bin/env python3
"""Reproduce flux and finite-range evaporation-time tables for PRL's approximation."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from hawking_flux import (classical_kappa, dimensionless_emission_integral,
                          elapsed_time_between_masses, fraction_below_z_cut,
                          illustrative_transition_mass, luminosity, transmission_s_wave)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--delta', type=float, default=1.0, help='holonomy parameter Delta (Planck units squared)')
    ap.add_argument('--initial-mass', type=float, default=100.0, help='initial mass in Planck units')
    ap.add_argument('--output', type=Path, default=HERE / 'results')
    args = ap.parse_args()
    if args.delta <= 0:
        ap.error('--delta must be positive')
    mf = illustrative_transition_mass(args.delta)
    if args.initial_mass <= mf:
        ap.error(f'--initial-mass must exceed model-specific endpoint estimate {mf:g}')
    args.output.mkdir(parents=True, exist_ok=True)

    masses = sorted(set([mf, mf * 1.01, mf * 1.25, mf * 2, mf * 5, args.initial_mass]))
    out_csv = args.output / 'published_lqg_flux_table.csv'
    with out_csv.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['mass_planck', 'delta', 'kappa_eff', 'power_corrected', 'power_classical', 'ratio_corrected_to_classical'])
        w.writeheader()
        for mass in masses:
            p = luminosity(mass, args.delta)
            pc = luminosity(mass, 0.0)
            w.writerow({'mass_planck': format(mass, '.16g'), 'delta': format(args.delta, '.16g'),
                        'kappa_eff': format(p * mass * mass, '.16g'),
                        'power_corrected': format(p, '.16g'),
                        'power_classical': format(pc, '.16g'),
                        'ratio_corrected_to_classical': format(p / pc, '.16g')})

    # Frequency-window audit: z=M*omega and omega/T_H=8*pi*z.
    # z=1/(8*pi) therefore corresponds to omega=T_H (not omega << T_H).
    cuts = [1.0/(8.0*3.141592653589793), 0.05, 0.1, 0.2, 0.3, 0.5]
    audit_csv = args.output / 'low_frequency_approximation_sensitivity.csv'
    with audit_csv.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['mass_planck', 'delta', 'z_cut', 'omega_cut_over_T_H', 'fraction_of_integral_below_cut', 'fraction_of_integral_above_cut', 'T0_at_z_0_5'])
        w.writeheader()
        for mass in masses:
            for z_cut in cuts:
                below = fraction_below_z_cut(mass, args.delta, z_cut)
                w.writerow({'mass_planck': format(mass, '.16g'), 'delta': format(args.delta, '.16g'),
                            'z_cut': format(z_cut, '.16g'),
                            'omega_cut_over_T_H': format(8.0*3.141592653589793*z_cut, '.16g'),
                            'fraction_of_integral_below_cut': format(below, '.16g'),
                            'fraction_of_integral_above_cut': format(1.0-below, '.16g'),
                            'T0_at_z_0_5': format(transmission_s_wave(0.5, mass, args.delta), '.16g')})

    j0, _ = dimensionless_emission_integral(1.0, 0.0)
    kappa = classical_kappa()
    low_frequency_fraction = fraction_below_z_cut(args.initial_mass, args.delta, 1.0/(8.0*3.141592653589793))
    elapsed, err = elapsed_time_between_masses(args.initial_mass, mf, args.delta)
    summary = {
        'model': 'Belfaqih et al., Phys. Rev. Lett. 135, 161501 (2025), DOI 10.1103/t6q4-4l77',
        'equation': 'dM/dt = -(1/(2*pi))*integral_0^infinity omega*T0(omega)/(exp(8*pi*M*omega)-1) d omega',
        'delta': args.delta,
        'initial_mass_planck': args.initial_mass,
        'model_specific_endpoint_estimate_planck': mf,
        'dimensionless_integral_classical': j0,
        'kappa_classical_from_this_approximation': kappa,
        'elapsed_time_to_endpoint_in_planck_times': elapsed,
        'outer_quadrature_error_estimate': err,
        'fraction_of_integral_from_omega_below_T_H_at_initial_mass': low_frequency_fraction,
        'fraction_of_integral_from_omega_above_T_H_at_initial_mass': 1.0-low_frequency_fraction,
        'frequency_cutoff_audit_csv': 'low_frequency_approximation_sensitivity.csv',
        'scope_warning': 'The paper uses a low-frequency s-wave transmission approximation; this reproduction is not a full all-species flux and not a quantum-state/unitarity calculation.'
    }
    out_json = args.output / 'published_lqg_flux_summary.json'
    out_json.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(f'Wrote: {out_csv}')
    print(f'Wrote: {out_json}')
    print(f'kappa(Delta=0) = {kappa:.12g}')
    print(f'finite-range time {args.initial_mass:g} -> {mf:.12g} = {elapsed:.12g}')
    print(f'fraction of integral from omega < T_H at initial mass = {low_frequency_fraction:.8%}')
    print('Scope: published approximation only; not a resolution of the information paradox.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
