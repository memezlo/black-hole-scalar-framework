#!/usr/bin/env python3
"""Reproduce the low-frequency s-wave mass-loss integral used in PRL 135, 161501 (2025).

Source: Belfaqih, Bojowald, Brahma & Duque, DOI 10.1103/t6q4-4l77,
Eqs. (4), (7) and the displayed low-frequency transmission coefficient.

This is a formula-level reproduction of the paper's approximation, not a new
first-principles derivation and not a complete flux calculation over all fields
and angular modes. In particular, the displayed transmission coefficient is a
low-frequency approximation and its use under an integral extending to infinity
inherits the approximation's limitations.

Units: G = c = hbar = k_B = 1. M and sqrt(Delta) are Planck lengths/masses
in natural units; Delta has dimensions of area.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.integrate import quad


@dataclass(frozen=True)
class FluxSettings:
    epsabs: float = 1e-12
    epsrel: float = 1e-10
    limit: int = 500

    def validate(self) -> None:
        if not (math.isfinite(self.epsabs) and self.epsabs > 0):
            raise ValueError("epsabs must be finite and positive")
        if not (math.isfinite(self.epsrel) and self.epsrel > 0):
            raise ValueError("epsrel must be finite and positive")
        if not isinstance(self.limit, int) or self.limit < 50:
            raise ValueError("limit must be an integer >= 50")


def transmission_s_wave(z: float, mass: float, delta: float) -> float:
    """Published approximate T_0 with z=M*omega.

    T_0 = 16 z^2 / [(1 - 4 z^2)^2 + 4 z^2 (1 + Delta/(12 M^2))^2].

    Do not interpret this expression as a globally accurate greybody factor:
    the source derives it in the low-frequency regime.
    """
    _validate_mass_delta(mass, delta)
    if not math.isfinite(z) or z < 0:
        raise ValueError("z must be finite and non-negative")
    z2 = z * z
    correction = 1.0 + delta / (12.0 * mass * mass)
    denominator = (1.0 - 4.0 * z2) ** 2 + 4.0 * z2 * correction * correction
    if denominator <= 0 or not math.isfinite(denominator):
        raise ArithmeticError("transmission coefficient denominator is invalid")
    return 16.0 * z2 / denominator


def _validate_mass_delta(mass: float, delta: float) -> None:
    if not math.isfinite(mass) or mass <= 0:
        raise ValueError("mass must be finite and positive")
    if not math.isfinite(delta) or delta < 0:
        raise ValueError("Delta must be finite and non-negative")


def dimensionless_emission_integral(mass: float, delta: float,
                                    settings: FluxSettings = FluxSettings()) -> tuple[float, float]:
    """Return J and estimated absolute quadrature error for dimensionless J.

    J(M,Delta) = integral_0^infinity dz z T_0(z;M,Delta)/(exp(8 pi z)-1).
    With z=M omega, P=-dM/dt=J/(2 pi M^2).
    """
    _validate_mass_delta(mass, delta)
    settings.validate()

    def integrand(z: float) -> float:
        if z <= 0.0:
            return 0.0  # continuous limit is zero
        t0 = transmission_s_wave(z, mass, delta)
        x = 8.0 * math.pi * z
        # Avoid overflow for large z; the Bose factor is exp(-x) to machine precision.
        bose = math.exp(-x) if x > 700.0 else 1.0 / math.expm1(x)
        return z * t0 * bose

    value, error = quad(integrand, 0.0, math.inf,
                        epsabs=settings.epsabs, epsrel=settings.epsrel,
                        limit=settings.limit)
    if not (math.isfinite(value) and math.isfinite(error) and value >= 0.0):
        raise ArithmeticError("quadrature returned an invalid emission integral")
    return float(value), float(error)


def luminosity(mass: float, delta: float,
               settings: FluxSettings = FluxSettings()) -> float:
    """Positive power P(M,Delta)=-dM/dt from the cited approximation."""
    j, _ = dimensionless_emission_integral(mass, delta, settings)
    return j / (2.0 * math.pi * mass * mass)


def mass_derivative(mass: float, delta: float,
                    settings: FluxSettings = FluxSettings()) -> float:
    """Signed mass derivative dM/dt, which is negative during evaporation."""
    return -luminosity(mass, delta, settings)


def elapsed_time_between_masses(initial_mass: float, final_mass: float, delta: float,
                                settings: FluxSettings = FluxSettings()) -> tuple[float, float]:
    """Integrate dt=-dM/(dM/dt) from initial_mass down to final_mass.

    The requested range must be positive and final_mass < initial_mass. The
    returned error estimate is the quadrature error for this outer integral;
    it does not fully propagate the inner luminosity quadrature's uncertainty.
    """
    _validate_mass_delta(initial_mass, delta)
    _validate_mass_delta(final_mass, delta)
    settings.validate()
    if final_mass >= initial_mass:
        raise ValueError("final_mass must be smaller than initial_mass")

    def inverse_power(mass: float) -> float:
        return 1.0 / luminosity(mass, delta, settings)

    value, error = quad(inverse_power, final_mass, initial_mass,
                        epsabs=settings.epsabs, epsrel=settings.epsrel,
                        limit=max(settings.limit, 200))
    if not (math.isfinite(value) and math.isfinite(error) and value > 0.0):
        raise ArithmeticError("elapsed-time quadrature returned an invalid result")
    return float(value), float(error)



def fraction_below_z_cut(mass: float, delta: float, z_cut: float,
                          settings: FluxSettings = FluxSettings()) -> float:
    """Fraction of the Eq. (7) integral arising from 0 <= z <= z_cut.

    This diagnostic measures how much of an all-frequency integral is supplied
    by a selected frequency window. It does not certify that the low-frequency
    approximation is valid anywhere; it quantifies dependence on the cutoff.
    """
    _validate_mass_delta(mass, delta)
    settings.validate()
    if not math.isfinite(z_cut) or z_cut <= 0:
        raise ValueError("z_cut must be finite and positive")

    def integrand(z: float) -> float:
        if z <= 0.0:
            return 0.0
        t0 = transmission_s_wave(z, mass, delta)
        x = 8.0 * math.pi * z
        bose = math.exp(-x) if x > 700.0 else 1.0 / math.expm1(x)
        return z * t0 * bose

    total, _ = dimensionless_emission_integral(mass, delta, settings)
    below, _ = quad(integrand, 0.0, z_cut, epsabs=settings.epsabs,
                    epsrel=settings.epsrel, limit=settings.limit)
    fraction = below / total
    if not math.isfinite(fraction) or fraction < 0.0 or fraction > 1.0 + 1e-10:
        raise ArithmeticError("frequency-window fraction is outside [0,1]")
    return min(1.0, max(0.0, float(fraction)))

def classical_kappa(settings: FluxSettings = FluxSettings()) -> float:
    """Calculate kappa in P=kappa/M^2 for the Delta=0 formula.

    The integral is mass-independent at Delta=0, so this is a numerical
    coefficient for the paper's low-frequency formula, not a full all-species
    Page (1976) luminosity coefficient.
    """
    j, _ = dimensionless_emission_integral(1.0, 0.0, settings)
    return j / (2.0 * math.pi)


def illustrative_transition_mass(delta: float) -> float:
    """Return M_f ~= 4.16 sqrt(Delta), a model-specific estimate in PRL 135, 161501.

    This is a cited paper's heuristic scale, not a universal critical mass.
    Delta=0 is rejected because the quantum scale then disappears.
    """
    if not math.isfinite(delta) or delta <= 0:
        raise ValueError("Delta must be finite and positive for this transition-scale estimate")
    return 4.16 * math.sqrt(delta)
