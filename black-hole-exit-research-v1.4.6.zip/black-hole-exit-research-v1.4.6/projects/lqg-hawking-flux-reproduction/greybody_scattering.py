#!/usr/bin/env python3
"""Numerically solve the static exterior s-wave scattering problem.

This module solves the radial wave equation on the *chosen effective static
metric* used in PRL 135, 161501 (2025), rather than extrapolating the paper's
low-frequency transmission approximation to arbitrarily high frequencies.
It is an independent numerical scattering calculation for that effective
metric and its scalar s-wave potential; it is not a full Hawking-flux or
backreaction solution.

Dimensionless variables: r=x/M, z=M*omega, delta=Delta/M**2,
*s=x_*/M with dr/ds=f*sqrt(h), f=1-2/r, h=1+delta*f/r**2.
For l=0, Vhat=M**2 V=f*[2/r**3 + f*(3*delta/r**5 - f*delta/r**4)].
Solve psi''_s + (z**2 - Vhat) psi = 0, with a unit ingoing wave at the
horizon; match the result to incoming/outgoing waves in the far exterior.

The finite-radius matching, near-horizon start, and ODE tolerances are
numerical approximations and must be checked by convergence studies.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
from scipy.integrate import solve_ivp


@dataclass(frozen=True)
class ScatteringSettings:
    horizon_epsilon: float = 1e-7
    r_max: float | None = None
    r_max_factor_over_z: float = 30.0
    minimum_r_max: float = 250.0
    max_step: float = 0.25
    rtol: float = 2e-9
    atol: float = 1e-11
    max_nfev: int = 2_000_000

    def validate(self) -> None:
        if not (math.isfinite(self.horizon_epsilon) and 0 < self.horizon_epsilon < 1e-2):
            raise ValueError("horizon_epsilon must be finite and in (0, 1e-2)")
        if self.r_max is not None and not (math.isfinite(self.r_max) and self.r_max > 2.0):
            raise ValueError("r_max must be None or finite and > 2")
        if not (math.isfinite(self.r_max_factor_over_z) and self.r_max_factor_over_z > 0):
            raise ValueError("r_max_factor_over_z must be finite and positive")
        if not (math.isfinite(self.minimum_r_max) and self.minimum_r_max > 2):
            raise ValueError("minimum_r_max must be finite and > 2")
        if not (math.isfinite(self.max_step) and self.max_step > 0):
            raise ValueError("max_step must be finite and positive")
        if not (math.isfinite(self.rtol) and self.rtol > 0 and math.isfinite(self.atol) and self.atol > 0):
            raise ValueError("rtol and atol must be finite and positive")
        if not isinstance(self.max_nfev, int) or self.max_nfev < 1000:
            raise ValueError("max_nfev must be an integer >= 1000")


@dataclass(frozen=True)
class ScatteringResult:
    z: float
    delta: float
    transmission: float
    reflection: float
    flux_balance_error: float
    r_max_used: float
    function_evaluations: int
    solver_status: int


def _validate(z: float, delta: float) -> None:
    if not math.isfinite(z) or z <= 0:
        raise ValueError("z=M*omega must be finite and positive")
    if not math.isfinite(delta) or delta < 0:
        raise ValueError("delta=Delta/M**2 must be finite and non-negative")


def potential_s_wave(r: float, delta: float) -> float:
    """Dimensionless effective potential Vhat=M^2 V for l=0."""
    if not math.isfinite(r) or r <= 2.0:
        raise ValueError("r must be finite and outside the horizon (r > 2)")
    if not math.isfinite(delta) or delta < 0:
        raise ValueError("delta must be finite and non-negative")
    f = 1.0 - 2.0 / r
    return f * (2.0 / r**3 + f * (3.0 * delta / r**5 - f * delta / r**4))


def transmission_probability(z: float, delta: float = 0.0,
                             settings: ScatteringSettings = ScatteringSettings()) -> ScatteringResult:
    """Solve static exterior s-wave scattering by direct ODE integration.

    A unit ingoing wave is imposed near the horizon. At r=r_max the wave is
    matched to incoming and outgoing plane waves. The result includes R+T-1
    as a numerical flux-conservation diagnostic. Values are not clipped to
    [0,1], so a numerical failure remains visible to the caller.
    """
    _validate(z, delta)
    settings.validate()
    r0 = 2.0 * (1.0 + settings.horizon_epsilon)
    rmax = settings.r_max if settings.r_max is not None else max(
        settings.minimum_r_max, settings.r_max_factor_over_z / z
    )
    if rmax <= r0:
        raise ValueError("r_max must be greater than the near-horizon start radius")

    # State y=(r, psi, dpsi/ds). Complex amplitude is supported by solve_ivp.
    def rhs(_s: float, y: np.ndarray) -> np.ndarray:
        r = float(np.real(y[0]))
        if r <= 2.0:
            # Protect against tiny integration roundoff exactly at the horizon.
            r = math.nextafter(2.0, math.inf)
        f = 1.0 - 2.0 / r
        h = 1.0 + delta * f / (r * r)
        dr_ds = f * math.sqrt(h)
        v = potential_s_wave(r, delta)
        return np.asarray([dr_ds, y[2], -(z * z - v) * y[1]], dtype=np.complex128)

    def reached_outer_radius(_s: float, y: np.ndarray) -> float:
        return float(np.real(y[0])) - rmax
    reached_outer_radius.terminal = True
    reached_outer_radius.direction = 1.0

    y0 = np.asarray([r0, 1.0 + 0.0j, -1j * z], dtype=np.complex128)
    # The arbitrary zero of tortoise coordinate is fixed at r0; it affects
    # phases of A_in/out but not the probabilities.
    s_end = max(2.0 * rmax, 20.0 * math.log(1.0 / settings.horizon_epsilon))
    result = solve_ivp(
        rhs, (0.0, s_end), y0, method="DOP853", rtol=settings.rtol,
        atol=settings.atol, max_step=settings.max_step, events=reached_outer_radius,
    )
    if result.status != 1 or result.t_events[0].size == 0:
        raise RuntimeError(f"Scattering ODE did not reach r_max={rmax:g}; status={result.status}")
    if result.nfev > settings.max_nfev:
        raise RuntimeError(f"Scattering ODE exceeded max_nfev={settings.max_nfev}")

    s_out = float(result.t_events[0][0])
    r_out, psi, dpsi = result.y_events[0][0]
    del r_out  # the matched radius is already recorded as r_max_used
    # psi = A_in exp(-izs) + A_out exp(+izs) at the matching point.
    a_in = 0.5 * np.exp(1j * z * s_out) * (psi - dpsi / (1j * z))
    a_out = 0.5 * np.exp(-1j * z * s_out) * (psi + dpsi / (1j * z))
    if abs(a_in) == 0 or not (np.isfinite(a_in.real) and np.isfinite(a_in.imag)):
        raise ArithmeticError("invalid incoming wave amplitude")
    trans = float(1.0 / (abs(a_in) ** 2))
    refl = float(abs(a_out / a_in) ** 2)
    balance = trans + refl - 1.0
    if not all(math.isfinite(v) for v in (trans, refl, balance)):
        raise ArithmeticError("scattering result contains non-finite values")
    return ScatteringResult(
        z=float(z), delta=float(delta), transmission=trans, reflection=refl,
        flux_balance_error=float(balance), r_max_used=float(rmax),
        function_evaluations=int(result.nfev), solver_status=int(result.status),
    )
