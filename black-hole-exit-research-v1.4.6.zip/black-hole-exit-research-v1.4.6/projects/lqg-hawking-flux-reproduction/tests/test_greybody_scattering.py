import math
import unittest
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from greybody_scattering import (ScatteringSettings, potential_s_wave,
                                transmission_probability)
from hawking_flux import transmission_s_wave


class GreybodyScatteringTests(unittest.TestCase):
    def test_potential_is_finite_and_tends_to_zero_near_horizon(self):
        self.assertTrue(math.isfinite(potential_s_wave(2.000001, 0.0)))
        self.assertLess(abs(potential_s_wave(2.000001, 1.0)), 1e-5)

    def test_effective_metric_potential_matches_direct_metric_derivatives(self):
        # Independently evaluate Vhat=(f*fprime*h + f^2*hprime/2)/r
        # for l=0, where h=1+delta*f/r^2. This catches missing factors of f
        # in the lambda*lambda' term after simplification.
        r, delta = 4.0, 1.0
        f = 1.0 - 2.0 / r
        fprime = 2.0 / r**2
        h = 1.0 + delta * f / r**2
        hprime = delta * (fprime / r**2 - 2.0 * f / r**3)
        expected = (f * fprime * h + f**2 * hprime / 2.0) / r
        self.assertAlmostEqual(potential_s_wave(r, delta), expected, places=15)

    def test_static_scattering_obeys_flux_conservation(self):
        result = transmission_probability(0.1, 0.0)
        self.assertGreaterEqual(result.transmission, 0.0)
        self.assertLessEqual(result.transmission, 1.0 + 1e-8)
        self.assertGreaterEqual(result.reflection, 0.0)
        self.assertLessEqual(result.reflection, 1.0 + 1e-8)
        self.assertLess(abs(result.flux_balance_error), 1e-8)

    def test_transmission_is_bounded_unlike_extrapolated_low_frequency_formula(self):
        result = transmission_probability(0.25, 0.0)
        approx = transmission_s_wave(0.25, 1.0, 0.0)
        self.assertLessEqual(result.transmission, 1.0)
        self.assertGreater(approx, 1.0)

    def test_horizon_start_convergence(self):
        default = transmission_probability(0.1, 0.0)
        moved_start = transmission_probability(
            0.1, 0.0, ScatteringSettings(horizon_epsilon=1e-6)
        )
        self.assertLess(abs(default.transmission - moved_start.transmission), 2e-6)

    def test_frequency_and_delta_validation(self):
        with self.assertRaises(ValueError):
            transmission_probability(0.0, 0.0)
        with self.assertRaises(ValueError):
            transmission_probability(0.1, -1.0)
        with self.assertRaises(ValueError):
            ScatteringSettings(horizon_epsilon=0.0).validate()
        with self.assertRaises(ValueError):
            potential_s_wave(2.0, 0.0)


if __name__ == '__main__':
    unittest.main()
