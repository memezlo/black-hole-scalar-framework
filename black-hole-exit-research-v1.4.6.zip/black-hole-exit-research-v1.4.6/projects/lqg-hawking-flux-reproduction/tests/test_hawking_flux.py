import math
import unittest
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from hawking_flux import (classical_kappa, dimensionless_emission_integral,
                          elapsed_time_between_masses, fraction_below_z_cut,
                          illustrative_transition_mass, luminosity, mass_derivative, transmission_s_wave)


class PublishedLQGFluxTests(unittest.TestCase):
    def test_transmission_vanishes_at_zero_frequency(self):
        self.assertEqual(transmission_s_wave(0.0, 10.0, 1.0), 0.0)

    def test_classical_flux_scales_exactly_as_inverse_mass_squared(self):
        for mass in (0.5, 1.0, 5.0, 100.0):
            self.assertAlmostEqual(luminosity(mass, 0.0) * mass**2, classical_kappa(), delta=1e-12)

    def test_quantum_correction_reduces_low_frequency_flux_for_fixed_mass(self):
        # For the cited approximate transmission coefficient, increasing Delta lowers T0 pointwise.
        for z in (0.01, 0.05, 0.1, 0.25):
            self.assertLess(transmission_s_wave(z, 2.0, 1.0), transmission_s_wave(z, 2.0, 0.0))
        self.assertLess(luminosity(2.0, 1.0), luminosity(2.0, 0.0))

    def test_flux_positive_and_mass_derivative_negative(self):
        self.assertGreater(luminosity(10.0, 1.0), 0.0)
        self.assertLess(mass_derivative(10.0, 1.0), 0.0)

    def test_integral_reports_finite_error(self):
        value, error = dimensionless_emission_integral(10.0, 1.0)
        self.assertGreater(value, 0.0)
        self.assertGreaterEqual(error, 0.0)
        self.assertTrue(math.isfinite(value + error))

    def test_finite_range_elapsed_time_is_positive(self):
        time, error = elapsed_time_between_masses(10.0, 5.0, 1.0)
        self.assertGreater(time, 0.0)
        self.assertGreaterEqual(error, 0.0)


    def test_low_frequency_window_share_is_computed_and_monotone(self):
        z_thermal = 1.0 / (8.0 * math.pi)  # omega = T_H
        fraction = fraction_below_z_cut(10.0, 0.0, z_thermal)
        wider = fraction_below_z_cut(10.0, 0.0, 0.1)
        self.assertGreater(fraction, 0.0)
        self.assertLess(fraction, 0.1)
        self.assertGreater(wider, fraction)
        self.assertLess(wider, 1.0)

    def test_transition_mass_is_model_scale(self):
        self.assertAlmostEqual(illustrative_transition_mass(1.0), 4.16)
        self.assertAlmostEqual(illustrative_transition_mass(4.0), 8.32)

    def test_rejects_invalid_parameters(self):
        with self.assertRaises(ValueError): transmission_s_wave(-1.0, 10.0, 1.0)
        with self.assertRaises(ValueError): fraction_below_z_cut(10.0, 1.0, 0.0)
        with self.assertRaises(ValueError): luminosity(0.0, 1.0)
        with self.assertRaises(ValueError): luminosity(10.0, -1.0)
        with self.assertRaises(ValueError): elapsed_time_between_masses(4.0, 5.0, 1.0)
        with self.assertRaises(ValueError): illustrative_transition_mass(0.0)

if __name__ == '__main__':
    unittest.main()
