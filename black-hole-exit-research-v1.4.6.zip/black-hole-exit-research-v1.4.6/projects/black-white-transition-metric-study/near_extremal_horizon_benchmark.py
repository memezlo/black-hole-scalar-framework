#!/usr/bin/env python3
"""Reproduce near-extremal horizon classification in arbitrary precision."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import mpmath as mp
from scipy.optimize import minimize_scalar

from model import Parameters, _mp_parameters, _mp_shift_value, horizon_radii_high_precision, horizon_residual, shift_N


GUARD_DIGITS = 30
MIN_OUTPUT_DPS = 80


def format_mp(value: mp.mpf, *, dps: int) -> str:
    """Serialize enough significant digits to preserve tiny absolute offsets.

    At |t| ~= 1e3, a 1e-74 offset needs about 78 significant digits to remain
    visible in the absolute time. The benchmark writes at least 80 digits and
    uses additional guard digits internally when locating the critical point.
    """
    return mp.nstr(value, max(50, dps))


def write_records(path: Path, rows: list[dict[str, str]]) -> None:
    """Write the identical benchmark rows to one CSV destination."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def resolve_output_paths(out: Path | None, also_write: list[Path]) -> list[Path]:
    """Resolve outputs and automatically sync the root mirror for canonical runs."""
    project_dir = Path(__file__).resolve().parent
    project_csv = project_dir / "results" / "near_extremal_horizon_benchmark.csv"
    root_csv = project_dir.parent.parent / "results" / "near_extremal_horizon_benchmark.csv"
    if out is None:
        candidates = [project_csv, root_csv, *also_write]
    else:
        candidates = [out, *also_write]
        if out.resolve() == project_csv.resolve():
            candidates.append(root_csv)

    unique: list[Path] = []
    seen: set[Path] = set()
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved not in seen:
            seen.add(resolved)
            unique.append(candidate)
    return unique


def build_records(p: Parameters, *, r_max: float = 60.0, n_grid: int = 6001, dps: int = 80) -> list[dict[str, str]]:
    if dps < MIN_OUTPUT_DPS:
        raise ValueError("dps must be at least 80 to serialize the benchmark's +/-1e-74 time offsets")
    p.validate()
    rows: list[dict[str, str]] = []
    # Critical-point uncertainty is amplified near pair birth: root separation
    # scales like sqrt(|t-t_critical|). Use explicit guard digits so the
    # reported separation is stable, not merely its 0/1/2-root classification.
    working_dps = dps + GUARD_DIGITS
    with mp.workdps(working_dps):
        pmp = _mp_parameters(p)

        def shift(r, t):
            return _mp_shift_value(r, t, pmp)

        r_critical, t_critical = mp.findroot(
            lambda r, t: (
                shift(r, t) - 1,
                mp.diff(lambda x: shift(x, t), r),
            ),
            (mp.mpf("31.7"), mp.mpf("-981.9")),
            tol=mp.power(10, -working_dps + 2), maxsteps=100,
        )
        cases = (
            ("below_pair_birth_1e-20", -mp.mpf("1e-20")),
            ("critical_tangency", mp.mpf("0")),
            ("above_pair_birth_1e-20", mp.mpf("1e-20")),
            ("below_pair_birth_1e-74", -mp.mpf("1e-74")),
            ("above_pair_birth_1e-74", mp.mpf("1e-74")),
            ("legacy_false_tangent_regression_1e-8", -mp.mpf("1e-8")),
        )
        for name, offset in cases:
            t = t_critical + offset
            bh_roots, wh_roots = horizon_radii_high_precision(
                t, p, r_max=r_max, n_grid=n_grid, dps=working_dps
            )
            root_strings = ";".join(mp.nstr(r, dps) for r in bh_roots)
            sep = mp.nstr(abs(bh_roots[-1] - bh_roots[0]), dps) if len(bh_roots) >= 2 else ""
            residuals = [horizon_residual(r, t, p, 1.0, dps=working_dps) for r in bh_roots]
            max_residual = mp.nstr(max(residuals), 12) if residuals else ""
            t_float = float(t)
            # Demonstrate the old float64 residual pathology independently.
            peak = minimize_scalar(
                lambda radius: -float(shift_N(radius, t_float, p)),
                bounds=(1e-5, r_max), method="bounded", options={"xatol": 1e-12},
            )
            peak_residual = mp.nstr(mp.mpf(str(-float(peak.fun) - 1.0)), 12)
            rows.append({
                "case": name,
                "delta_t_from_critical": mp.nstr(offset, 30),
                "t_mp": format_mp(t, dps=dps),
                "t_as_float64": repr(t_float),
                "float64_peak_residual_N_minus_1": peak_residual,
                "old_float_root_tol": "1e-10",
                "mp_root_count": str(len(bh_roots)),
                "mp_roots_r": root_strings,
                "mp_pair_separation": sep,
                "max_mp_root_residual": max_residual,
                "dps": str(dps),
                "working_dps": str(working_dps),
                "r_max": str(r_max),
                "n_grid": str(n_grid),
            })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=None,
                        help="primary CSV destination (default: keep project and root copies synchronized)")
    parser.add_argument("--also-write", type=Path, action="append", default=[],
                        help="additional CSV destination; may be supplied more than once")
    parser.add_argument("--r-max", type=float, default=60.0)
    parser.add_argument("--n-grid", type=int, default=6001)
    parser.add_argument("--dps", type=int, default=80,
                        help="decimal digits serialized to the CSV; calculations use 30 additional guard digits")
    args = parser.parse_args()
    rows = build_records(Parameters(), r_max=args.r_max, n_grid=args.n_grid, dps=args.dps)
    unique_outputs = resolve_output_paths(args.out, args.also_write)
    for output in unique_outputs:
        write_records(output, rows)
    for row in rows:
        print(f"{row['case']}: roots={row['mp_root_count']}, separation={row['mp_pair_separation'] or 'n/a'}, residual={row['max_mp_root_residual'] or 'n/a'}")
    for output in unique_outputs:
        print(f"Wrote {output.resolve()}")


if __name__ == "__main__":
    main()
