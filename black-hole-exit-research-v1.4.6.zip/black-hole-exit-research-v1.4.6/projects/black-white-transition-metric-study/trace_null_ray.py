#!/usr/bin/env python3
"""Trace a radial outgoing null ray in the chosen phenomenological metric.

Metric convention used by model.py:
    ds^2 = -dt^2 + (dr + N^r dt)^2 + r^2 dOmega^2.
For the outgoing radial null branch, dr/dt = 1 - N^r.
This is a diagnostic of the specified time-dependent ansatz. Escaping a temporary
trapped region is NOT the same as escaping from a point behind a global event
horizon; if a causal ray reaches future null infinity, that point was not inside
the global black-hole region by definition.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

from model import Parameters, null_expansions, shift_N


def trace_outgoing_null_ray(
    p: Parameters,
    *,
    t_start: float = -5.0,
    t_end: float = 200.0,
    r_start: float = 7.0,
    max_step: float = 0.05,
    sample_count: int = 1026,
) -> tuple[np.ndarray, np.ndarray]:
    """Return sampled (t, r(t)) for the outgoing radial null ODE."""
    if t_end <= t_start or r_start <= 0 or max_step <= 0 or sample_count < 2:
        raise ValueError("Require t_end > t_start, r_start > 0, max_step > 0, sample_count >= 2")

    def rhs(t: float, y: np.ndarray) -> list[float]:
        r = float(y[0])
        if not np.isfinite(r) or r <= 0.0:
            raise RuntimeError(
                "Null-ray integration reached the r<=0 chart boundary; "
                "stopping is preferable to silently clipping the radius."
            )
        return [1.0 - float(shift_N(r, t, p))]

    sol = solve_ivp(
        rhs,
        (t_start, t_end),
        [r_start],
        method="DOP853",
        rtol=1e-9,
        atol=1e-11,
        max_step=max_step,
        dense_output=True,
    )
    if not sol.success or sol.sol is None:
        raise RuntimeError(f"Null-ray integration failed: {sol.message}")
    times = np.linspace(t_start, t_end, sample_count)
    # Retain exact diagnostic times even during long integrations with a sparse
    # CSV output grid; otherwise linear interpolation could misreport the early trend.
    probes = [t_start + 1.0, -4.0, -1.0, 0.0, 1.0, 5.0, 20.0, 100.0, 200.0, 1200.0]
    probes = [t for t in probes if t_start <= t <= t_end]
    times = np.unique(np.concatenate([times, np.asarray(probes, dtype=float)]))
    radii = np.asarray(sol.sol(times)[0], dtype=float)
    if not np.all(np.isfinite(radii)) or np.any(radii <= 0):
        raise RuntimeError("Null-ray integration produced non-finite/non-positive radius")
    return times, radii


def write_results(
    outdir: Path,
    *,
    make_plot: bool = True,
    t_start: float = -5.0,
    t_end: float = 200.0,
    r_start: float = 7.0,
    max_step: float = 0.05,
    sample_count: int = 1026,
) -> tuple[Path, Path | None]:
    p = Parameters()
    p.validate()
    # The default start point lies within a temporarily trapped region in the
    # illustrative parameter set. Re-check the chosen initial point every run.
    theta_plus, theta_minus = null_expansions(r_start, t_start, p)
    if not (float(theta_plus) < 0 and float(theta_minus) < 0):
        raise RuntimeError("Initial point is not in a trapped region for this parameter set")

    times, radii = trace_outgoing_null_ray(
        p, t_start=t_start, t_end=t_end, r_start=r_start,
        max_step=max_step, sample_count=sample_count
    )
    outdir.mkdir(parents=True, exist_ok=True)
    csv_path = outdir / "null_ray_escape.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["t_l0", "r_over_l0", "N_r", "theta_plus", "theta_minus"])
        for t, r in zip(times, radii):
            n = float(shift_N(float(r), float(t), p))
            thp, thm = null_expansions(float(r), float(t), p)
            writer.writerow([f"{t:.10g}", f"{r:.12g}", f"{n:.12g}", f"{float(thp):.12g}", f"{float(thm):.12g}"])

    plot_path: Path | None = None
    if make_plot:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(8.8, 5.0))
        ax.plot(times, radii, linewidth=2, label=r"Outgoing null ray: $dr/dt=1-N^r$")
        ax.axvline(0.0, linestyle="--", linewidth=1, label="Shift sign-change time")
        ax.scatter([-5, -1, 0, 20, 200], np.interp([-5, -1, 0, 20, 200], times, radii), s=22, zorder=3)
        ax.set_xlabel(r"Time $t/l_0$")
        ax.set_ylabel(r"Areal radius $r/l_0$")
        ax.set_title("A null ray leaves a temporary trapped region in the ansatz")
        ax.grid(True, alpha=0.25)
        ax.legend()
        fig.tight_layout()
        plot_path = outdir / "null_ray_escape.png"
        fig.savefig(plot_path, dpi=180)
        plt.close(fig)
    print(f"Initial trapped point: t={t_start:g}, r={r_start:g}, theta_plus={float(theta_plus):.8g}, theta_minus={float(theta_minus):.8g}")
    if t_start + 1.0 <= t_end:
        r_early = float(np.interp(t_start + 1.0, times, radii))
        print(f"At t={t_start + 1.0:g}, r={r_early:.8f}; check initial radial trend against r_start={r_start:g}")
    n_end = float(shift_N(float(radii[-1]), float(times[-1]), p))
    print(f"At t={t_end:g}, r={float(radii[-1]):.8f}, N^r={n_end:.8f}, dr/dt={1.0-n_end:.8f}")
    print("The endpoint is a finite-time numerical check, not a proof of the full asymptotic spacetime.")
    print(f"Wrote {csv_path}")
    if plot_path:
        print(f"Wrote {plot_path}")
    print("Interpretation: a temporary trapped region is not a global event horizon.")
    return csv_path, plot_path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=Path("results"))
    parser.add_argument("--no-plot", action="store_true")
    parser.add_argument("--t-start", type=float, default=-5.0)
    parser.add_argument("--t-end", type=float, default=200.0)
    parser.add_argument("--r-start", type=float, default=7.0)
    parser.add_argument("--max-step", type=float, default=0.05)
    parser.add_argument("--sample-count", type=int, default=1026)
    args = parser.parse_args()
    write_results(
        args.outdir, make_plot=not args.no_plot,
        t_start=args.t_start, t_end=args.t_end, r_start=args.r_start,
        max_step=args.max_step, sample_count=args.sample_count,
    )


if __name__ == "__main__":
    main()
