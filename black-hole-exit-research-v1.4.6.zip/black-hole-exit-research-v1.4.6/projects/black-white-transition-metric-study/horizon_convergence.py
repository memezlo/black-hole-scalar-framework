#!/usr/bin/env python3
"""Convergence audit for the finite-grid horizon finder in model.py.

The audit varies both the radial search bound and grid resolution, records
root residuals, and compares ordered root families to a declared baseline.
It checks numerical stability over a finite domain; it is not a proof that no
additional roots exist outside the tested domain or at untested times.
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
from typing import Iterable

import numpy as np

import mpmath as mp

from model import Parameters, horizon_radii, horizon_residual

DEFAULT_TIMES = (-1200.0, -800.0, -200.0, -20.0, -5.0, -1.0,
                 0.0, 1.0, 5.0, 20.0, 200.0, 800.0, 1200.0)
DEFAULT_CONFIGS = ((40.0, 1001), (60.0, 3001), (100.0, 6001))
BASELINE = (60.0, 3001)


def audit_convergence(
    p: Parameters,
    *,
    times: Iterable[float] = DEFAULT_TIMES,
    configs: Iterable[tuple[float, int]] = DEFAULT_CONFIGS,
    baseline: tuple[float, int] = BASELINE,
) -> list[dict[str, object]]:
    """Return one record per detected horizon root and per empty family/config.

    A row is written for every (time, config, family), including zero-root
    families, so root-count stability is auditable rather than implicit.
    Ordered roots are matched by index; this is suitable for the reference
    benchmark's simple root branches, not a general root-tracking algorithm.
    """
    p.validate()
    times = tuple(float(t) for t in times)
    configs = tuple((float(rmax), int(n)) for rmax, n in configs)
    if not times or not configs:
        raise ValueError("times and configs must be non-empty")
    for t in times:
        if not np.isfinite(t):
            raise ValueError("all times must be finite")
    for rmax, n in configs:
        if not np.isfinite(rmax) or rmax <= 0 or n < 10:
            raise ValueError("each config requires finite r_max > 0 and n_grid >= 10")
    if baseline not in configs:
        raise ValueError("baseline config must be included in configs")

    results: list[dict[str, object]] = []
    for t in times:
        by_config: dict[tuple[float, int], tuple[list[float], list[float]]] = {}
        for config in configs:
            rmax, n = config
            by_config[config] = horizon_radii(t, p, r_max=rmax, n_grid=n)
        base_pair = by_config[baseline]
        for config in configs:
            rmax, n = config
            pair = by_config[config]
            for family, target, roots, base_roots in (
                ("black_hole", 1.0, pair[0], base_pair[0]),
                ("white_hole", -1.0, pair[1], base_pair[1]),
            ):
                count_equal = len(roots) == len(base_roots)
                for i, root in enumerate(roots):
                    residual = float(horizon_residual(root, t, p, target))
                    if count_equal:
                        with mp.workdps(80):
                            if isinstance(root, mp.mpf) or isinstance(base_roots[i], mp.mpf):
                                matched_delta = mp.nstr(abs(mp.mpf(root) - mp.mpf(base_roots[i])), 30)
                            else:
                                matched_delta = abs(root - base_roots[i])
                    else:
                        matched_delta = float("nan")
                    results.append({
                        "t_l0": t,
                        "r_max_l0": rmax,
                        "n_grid": n,
                        "family": family,
                        "target_N_r": target,
                        "root_index": i + 1,
                        "root_r_over_l0": mp.nstr(root, 40) if isinstance(root, mp.mpf) else root,
                        "abs_residual": residual,
                        "root_count": len(roots),
                        "baseline_r_max_l0": baseline[0],
                        "baseline_n_grid": baseline[1],
                        "abs_delta_from_baseline": matched_delta,
                        "count_matches_baseline": count_equal,
                    })
                if not roots:
                    results.append({
                        "t_l0": t,
                        "r_max_l0": rmax,
                        "n_grid": n,
                        "family": family,
                        "target_N_r": target,
                        "root_index": "",
                        "root_r_over_l0": "",
                        "abs_residual": "",
                        "root_count": 0,
                        "baseline_r_max_l0": baseline[0],
                        "baseline_n_grid": baseline[1],
                        "abs_delta_from_baseline": "",
                        "count_matches_baseline": count_equal,
                    })
    return results


def write_csv(records: list[dict[str, object]], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = [
        "t_l0", "r_max_l0", "n_grid", "family", "target_N_r", "root_index",
        "root_r_over_l0", "abs_residual", "root_count", "baseline_r_max_l0",
        "baseline_n_grid", "abs_delta_from_baseline", "count_matches_baseline",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("results/horizon_convergence.csv"))
    args = parser.parse_args()
    records = audit_convergence(Parameters())
    path = write_csv(records, args.out)
    count_mismatches = sum(not bool(r["count_matches_baseline"]) for r in records)
    finite_residuals = [float(r["abs_residual"]) for r in records if r["abs_residual"] != ""]
    max_residual = max(finite_residuals, default=0.0)
    matched_deltas = [float(r["abs_delta_from_baseline"]) for r in records if r["abs_delta_from_baseline"] != "" and np.isfinite(float(r["abs_delta_from_baseline"]))]
    max_delta = max(matched_deltas, default=0.0)
    print(f"Rows written: {len(records)}")
    print(f"Maximum root residual: {max_residual:.6e}")
    print(f"Maximum matched-root difference vs baseline: {max_delta:.6e}")
    print(f"Root-count mismatch rows: {count_mismatches}")
    print(f"Wrote {path}")
    if count_mismatches:
        raise SystemExit("Convergence audit failed: root count changed vs baseline")


if __name__ == "__main__":
    main()
