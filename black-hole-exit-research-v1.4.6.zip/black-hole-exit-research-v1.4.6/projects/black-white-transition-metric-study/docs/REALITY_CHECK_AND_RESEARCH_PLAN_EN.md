# Can we escape a black hole? What is known about white holes

**Status:** research assessment as of 19 October 2026. This is not a discovery claim.

## Executive conclusion

1. In classical general relativity, no future-directed causal trajectory can escape from the interior of a genuine global event horizon. This follows from the definition of the black-hole region.
2. Phenomenological and quantum-gravity-motivated models propose black-to-white-hole transitions. A consistent metric ansatz demonstrates a conditional mathematical possibility within that ansatz; it does not establish that nature realizes it.
3. There is no confirmed observational detection of an astrophysical white hole. A 2024 review emphasizes the gap between theoretical constructions and observational support; a 2026 dynamical metric paper explicitly describes its construction as a phenomenological model.

## Meaning of “escape”

These cases must be distinguished: (i) escape from inside a global event horizon; (ii) escape from a temporary trapped region; (iii) a hypothesized quantum transition into a white-hole phase. Only the second is demonstrated by the added null-ray integration in this repository.

## Classical causal argument

Let \(\mathscr I^+\) be future null infinity and \(J^-(\mathscr I^+)\) its causal past. The black-hole region is

\[
\mathcal B=\mathcal M\setminus J^-(\mathscr I^+),
\]

and the event horizon is \(\mathcal H^+=\partial J^-(\mathscr I^+)\). If \(p\in\mathcal B\), no future-directed causal curve from \(p\) reaches \(\mathscr I^+\), by definition. This is a global causal result, not a claim about a coordinate singularity.

## Result added to the computational project

In the specified time-dependent Painlevé–Gullstrand metric,

\[
ds^2=-dt^2+(dr+N^r dt)^2+r^2d\Omega^2,
\qquad dr/dt=1-N^r,
\]

the ray starts at \((t,r)=(-5,7)\), where both radial future null expansions are negative. It initially moves inward, then moves outward after the prescribed shift changes sign and reaches \(r\approx309.17481\) at \(t=200\), in model units. A separate long finite-time run gives \(r\approx10996.86689\), \(N^r\approx-0.05394\), and \(dr/dt\approx1.05394\) at \(t=10000\). Within this ansatz a stronger model-level argument applies: for \(t>0\), \(N^r\le0\), so \(dr/dt=1-N^r\ge1\) and hence \(r(t)\ge r(0)+t\). Thus the tracked ray's areal radius grows without bound in the model. This is a consequence of the assumed metric, not independent evidence that white holes exist in nature. This is a numerical demonstration of escape from a **temporary trapped region in the ansatz**, not escape from the global black-hole region: any event whose future-directed causal ray reaches \(\mathscr I^+\) was not in that region. The transition is built into the chosen shift function; it is not derived from a fundamental quantum-gravity theory.

## What would support a white-hole claim?

A serious claim would require (1) well-defined dynamics and initial/boundary data; (2) regularity, curvature, causal-structure, stability and effective-stress-energy checks; (3) independent predictions distinguishable from ordinary astrophysical transients; (4) reproducible data and elimination of alternatives; and (5) independent code/data reproduction and expert scrutiny. A mathematical solution alone cannot establish that astrophysical objects of that type exist.

## Work done and limitations

- **Scalar–Gauss–Bonnet project:** computes a linear scalar zero mode on a fixed Schwarzschild background and a conditional growth integral using an externally prescribed mass-loss law. It is not a self-consistent evaporating spacetime, a nonlinear bounce simulation or an LQG derivation.
- **Transition-metric project:** checks the shift, null expansions, horizon roots and one outgoing null ray in a prescribed time-dependent metric. The bounce is built into the sign-changing shift. The illustrative parameter set is not claimed to reproduce all plotting settings in the source paper.
- Automated tests validate code behavior and selected numerical properties, not the truth of a fundamental theory or the astrophysical existence of white holes.

## Suggested research path

1. Reproduce the reference metric and figures line by line.
2. Compute curvature invariants and the effective stress-energy tensor; test regularity and energy conditions.
3. Analyze global causal structure and families of null geodesics, not just local trapping horizons.
4. Select one consistent effective LQG model or one fully specified classical field theory; do not mix independent ansatzes.
5. Evolve the coupled metric-matter equations nonlinearly and monitor constraints, stability and hyperbolicity.
6. Derive distinguishable observables and compare them with astronomical data and competing explanations.
7. Publish code and data with limitations and seek independent replication.

## References

- R. Gaur & M. Visser, “Black holes, white holes, and near-horizon physics,” *JHEP* (2024), [DOI: 10.1007/JHEP05(2024)172](https://doi.org/10.1007/JHEP05(2024)172).
- S. Hergott, V. Husain & S. Rastgoo, “Dynamical model for black hole to white hole transitions,” *Phys. Rev. D* **113**, 024049 (2026), [DOI: 10.1103/8m7g-zz3k](https://doi.org/10.1103/8m7g-zz3k), [arXiv:2505.15096](https://arxiv.org/abs/2505.15096).
- M. Villani, “Black to white hole transition as a change of the topology of the event horizon,” *Gen. Relativ. Gravit.* **58**, 11 (2026), [DOI: 10.1007/s10714-026-03516-3](https://doi.org/10.1007/s10714-026-03516-3).
- P. Frisoni, “Numerical approach to the black-to-white hole transition,” *Phys. Rev. D* **107**, 126012 (2023), [DOI: 10.1103/PhysRevD.107.126012](https://doi.org/10.1103/PhysRevD.107.126012).
- M. Bojowald, “Black-Hole Models in Loop Quantum Gravity,” *Universe* **6**, 125 (2020), [DOI: 10.3390/universe6080125](https://doi.org/10.3390/universe6080125).

## Current conclusion

What is currently established here is only that a null ray escapes a temporary trapped region in one phenomenological metric and that the numerical result is reproducible within tested tolerances. We have not shown that one can escape from the inside of a genuine classical event horizon, derived the transition from fundamental LQG, or proved that white holes exist in nature.
