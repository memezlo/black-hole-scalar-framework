#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python -m unittest discover -s "$ROOT/tests" -v
