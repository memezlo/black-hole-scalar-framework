# Numerical study of a published phenomenological black-hole-to-white-hole metric

Version 0.3.0. This small project independently implements the metric-level model of Hergott, Husain & Rastgoo, *Phys. Rev. D* 113, 024049 (2026), [arXiv:2505.15096](https://arxiv.org/abs/2505.15096), [DOI: 10.1103/8m7g-zz3k](https://doi.org/10.1103/8m7g-zz3k).

It computes the signed Painlevé–Gullstrand shift, radial null expansions, and sign-changing horizon roots for a clearly stated illustrative parameter set. The implementation reproduces the published metric form, but the chosen `A=0.8` parameter is not claimed to match every plotting parameter in the article. It is a metric-level study of a phenomenological ansatz, **not** a derivation from fundamental loop quantum gravity and not observational evidence that real black holes transition to white holes.

Run:

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python model.py --outdir results --plot
python trace_null_ray.py --outdir results
# Optional long finite-time check
python trace_null_ray.py --outdir results/asymptotic --t-end 10000 --max-step 0.5 --sample-count 2001 --no-plot
```

An additional `trace_null_ray.py` integrates an outgoing radial null ray, `dr/dt = 1 - N^r`. With the illustrative parameters, the ray starts at `t=-5, r=7`, where both null expansions are negative; it initially moves inward and later reaches `r ≈ 309.1748` at `t=200` and `r ≈ 10996.8669` at `t=10000`. For `t>0`, the ansatz has `N^r ≤ 0`, so `dr/dt = 1 - N^r ≥ 1` and the areal radius grows without bound. This is a consequence of the built-in shift sign change, not a derivation from fundamental quantum gravity. This demonstrates escape from a **temporary trapped region in the chosen ansatz**, not escape from inside a global event horizon. By definition, if the ray reaches future null infinity, its starting event was not inside the global black-hole region.

The code does not independently compute all curvature invariants; it should not be cited as an independent proof of full spacetime regularity.

See [`README_RU.md`](README_RU.md) for the equations, interpretation, and caveats in Russian.

## Horizon-root convergence audit

Run the finite grid/domain sweep with:

```bash
python horizon_convergence.py --out results/horizon_convergence.csv
```

The CSV records root counts and residuals for 13 representative times in the CSV audit (the unit test spot-checks 11 times) across three `(r_max, n_grid)` configurations. This is a finite numerical stability check, not a proof that no roots exist for every time or outside the tested domains.



## Near-extremal horizon search (v0.3.0)

Near-target extrema trigger an 80-decimal-digit `mpmath` fallback. The implementation uses `brentq` for ordinary sign-changing roots, sampled extrema plus `minimize_scalar` for the fast-path candidate, and high-precision derivative bisection near pair birth/death. It does **not** use Newton's method. The fallback preserves close roots internally, but still has finite precision and finite-grid candidate detection; an `mp.mpf` time is required to preserve offsets below float64 input precision.


Run the near-extremal horizon benchmark with:

```bash
python near_extremal_horizon_benchmark.py --out results/near_extremal_horizon_benchmark.csv
```

When the benchmark writes to its canonical project output path, it also refreshes the root-level mirror; arbitrary output paths can be mirrored with `--also-write`.
