#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from page_curve import page_turnover_mass_fraction, page_turnover_time_fraction_classical, normalized_row


def main() -> int:
    ap = argparse.ArgumentParser(description='Create an explicitly toy Page-curve entropy comparison.')
    ap.add_argument('--eta-eff', type=float, default=4.0/3.0,
                    help='illustrative entropy/energy ratio; not determined by this model')
    ap.add_argument('--points', type=int, default=101)
    ap.add_argument('--output', type=Path, default=HERE / 'results')
    args = ap.parse_args()
    if args.points < 3:
        ap.error('--points must be >= 3')
    if not math.isfinite(args.eta_eff) or args.eta_eff <= 0:
        ap.error('--eta-eff must be finite and positive')
    args.output.mkdir(parents=True, exist_ok=True)
    rows = [normalized_row(1.0 - i/(args.points-1), args.eta_eff) for i in range(args.points)]
    table = args.output / 'toy_page_curve.csv'
    with table.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    x = page_turnover_mass_fraction(args.eta_eff)
    summary = {
        'scope': 'toy bookkeeping only; not an island/QES calculation and not a proof of unitarity',
        'eta_eff': args.eta_eff,
        'page_turnover_mass_fraction': x,
        'page_turnover_time_fraction_for_classical_dMdt_kappa_over_M2': page_turnover_time_fraction_classical(args.eta_eff),
        'assumption': 'Page-like min envelope is used as a comparator; its declining branch is not derived from the transition geometry.',
        'physical_missing_inputs': ['mode-resolved radiation density matrix', 'greybody-corrected entropy flux', 'bulk entanglement entropy', 'quantum extremal surface/island prescription or an explicit unitary S-matrix']
    }
    report = args.output / 'toy_page_curve_summary.json'
    report.write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
    print(f'Wrote {table}')
    print(f'Wrote {report}')
    print(f'Toy turnover mass fraction = {x:.8f}; not a physical prediction.')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
