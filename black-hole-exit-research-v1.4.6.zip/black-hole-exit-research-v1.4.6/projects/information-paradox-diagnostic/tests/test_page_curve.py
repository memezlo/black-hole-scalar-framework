import math
import unittest
from pathlib import Path
import sys
HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from page_curve import (black_hole_entropy, coarse_grained_radiation_entropy,
                        hawking_temperature, normalized_row,
                        page_curve_envelope, page_turnover_mass_fraction,
                        page_turnover_time_fraction_classical)

class PageCurveDiagnosticTests(unittest.TestCase):
    def test_schwarzschild_entropy_and_temperature(self):
        self.assertAlmostEqual(black_hole_entropy(2.0), 16.0*math.pi)
        self.assertAlmostEqual(hawking_temperature(2.0), 1.0/(16.0*math.pi))

    def test_thermal_entropy_increases_as_mass_decreases(self):
        self.assertGreater(coarse_grained_radiation_entropy(0.5, 1.0),
                           coarse_grained_radiation_entropy(0.8, 1.0))
        self.assertEqual(coarse_grained_radiation_entropy(1.0, 1.0), 0.0)

    def test_page_turnover_branches_cross(self):
        eta = 4.0/3.0
        x = page_turnover_mass_fraction(eta)
        self.assertAlmostEqual(x*x, eta*(1.0-x*x), places=14)

    def test_page_envelope_is_zero_at_initial_and_final_endpoints(self):
        self.assertEqual(page_curve_envelope(1.0, 1.0), 0.0)
        self.assertEqual(page_curve_envelope(0.0, 1.0), 0.0)

    def test_page_envelope_has_positive_midpoint(self):
        self.assertGreater(page_curve_envelope(0.5, 1.0), 0.0)

    def test_normalized_row_consistent_with_formulas(self):
        row = normalized_row(0.25, eta_eff=1.0)
        self.assertAlmostEqual(row['S_BH_over_S0'], 0.0625)
        self.assertAlmostEqual(row['S_rad_coarse_over_S0'], 0.9375)
        self.assertAlmostEqual(row['S_Page_toy_over_S0'], 0.0625)

    def test_classical_page_time_fraction_is_between_zero_and_one(self):
        x = page_turnover_time_fraction_classical()
        self.assertGreater(x, 0.0)
        self.assertLess(x, 1.0)

    def test_invalid_inputs_rejected(self):
        with self.assertRaises(ValueError): black_hole_entropy(-1.0)
        with self.assertRaises(ValueError): hawking_temperature(0.0)
        with self.assertRaises(ValueError): coarse_grained_radiation_entropy(2.0, 1.0)
        with self.assertRaises(ValueError): page_turnover_mass_fraction(0.0)
        with self.assertRaises(ValueError): normalized_row(1.2)

if __name__ == '__main__':
    unittest.main()
