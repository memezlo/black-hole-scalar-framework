#!/usr/bin/env python3
"""Illustrative entropy bookkeeping for Hawking radiation and a Page-like turnover.

This is a deliberately transparent toy diagnostic, NOT an island-formula
calculation and NOT a derivation of unitarity. It quantifies the distinction
between (a) a monotonically increasing coarse-grained thermal entropy estimate
and (b) a Page-inspired envelope that rises and then falls for a globally pure
state. The latter shape is imposed as a comparator and is not predicted by our
black-hole transition metric.

In G = hbar = k_B = c = 1 units:
  S_BH(M) = 4*pi*M^2,
  T_H(M) = 1/(8*pi*M),
  S_rad,coarse(M) = eta_eff * 4*pi*(M0^2 - M^2).

eta_eff is an explicit sensitivity parameter representing the entropy emitted
per unit energy in units of 1/T_H. Its value must be calculated from the
mode-resolved radiation state (including greybody factors) for a physical model.
"""
from __future__ import annotations
import math


def _validate(mass: float, initial_mass: float, eta_eff: float) -> None:
    if not math.isfinite(mass) or mass < 0:
        raise ValueError("mass must be finite and non-negative")
    if not math.isfinite(initial_mass) or initial_mass <= 0:
        raise ValueError("initial_mass must be finite and positive")
    if mass > initial_mass:
        raise ValueError("mass cannot exceed initial_mass in this evaporation diagnostic")
    if not math.isfinite(eta_eff) or eta_eff <= 0:
        raise ValueError("eta_eff must be finite and positive")


def black_hole_entropy(mass: float) -> float:
    if not math.isfinite(mass) or mass < 0:
        raise ValueError("mass must be finite and non-negative")
    return 4.0 * math.pi * mass * mass


def hawking_temperature(mass: float) -> float:
    if not math.isfinite(mass) or mass <= 0:
        raise ValueError("mass must be finite and positive")
    return 1.0 / (8.0 * math.pi * mass)


def coarse_grained_radiation_entropy(mass: float, initial_mass: float,
                                     eta_eff: float = 4.0 / 3.0) -> float:
    """Toy integrated thermal entropy, conditional on a prescribed eta_eff."""
    _validate(mass, initial_mass, eta_eff)
    return 4.0 * math.pi * eta_eff * (initial_mass**2 - mass**2)


def page_turnover_mass_fraction(eta_eff: float = 4.0 / 3.0) -> float:
    """Mass fraction where the two toy entropy branches cross."""
    if not math.isfinite(eta_eff) or eta_eff <= 0:
        raise ValueError("eta_eff must be finite and positive")
    return math.sqrt(eta_eff / (1.0 + eta_eff))


def page_turnover_time_fraction_classical(eta_eff: float = 4.0 / 3.0) -> float:
    """Time fraction under the separate toy law dM/dt=-kappa/M^2.

    This fraction must not be reused for a corrected, mass-dependent LQG flux.
    """
    x_page = page_turnover_mass_fraction(eta_eff)
    return 1.0 - x_page**3


def page_curve_envelope(mass: float, initial_mass: float,
                        eta_eff: float = 4.0 / 3.0) -> float:
    """Page-like min-envelope comparator, not an island formula result."""
    _validate(mass, initial_mass, eta_eff)
    return min(black_hole_entropy(mass),
               coarse_grained_radiation_entropy(mass, initial_mass, eta_eff))


def normalized_row(mass_fraction: float, eta_eff: float = 4.0 / 3.0) -> dict[str, float]:
    """Return entropies normalized by S_BH(initial), for initial mass M0=1."""
    if not math.isfinite(mass_fraction) or not 0.0 <= mass_fraction <= 1.0:
        raise ValueError("mass_fraction must be in [0, 1]")
    _validate(mass_fraction, 1.0, eta_eff)
    s_bh = mass_fraction**2
    s_rad = eta_eff * (1.0 - mass_fraction**2)
    return {
        "mass_fraction": mass_fraction,
        "S_BH_over_S0": s_bh,
        "S_rad_coarse_over_S0": s_rad,
        "S_Page_toy_over_S0": min(s_bh, s_rad),
    }
