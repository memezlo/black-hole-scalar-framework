import math
import sys
import unittest
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from page_benchmark import (entropy_curve_monte_carlo,
                            page_entropy_haar_average,
                            von_neumann_entropy_from_eigenvalues)

class UnitaryPageBenchmarkTests(unittest.TestCase):
    def test_pure_state_endpoints_have_zero_entropy(self):
        rows = entropy_curve_monte_carlo(n_qubits=5, samples=4, seed=12)
        self.assertAlmostEqual(rows[0]['entropy_monte_carlo_nats'], 0.0, places=14)
        self.assertAlmostEqual(rows[-1]['entropy_monte_carlo_nats'], 0.0, places=14)

    def test_page_average_is_symmetric(self):
        for n in range(1, 8):
            for k in range(n + 1):
                self.assertAlmostEqual(page_entropy_haar_average(n, k),
                                       page_entropy_haar_average(n, n-k), places=12)

    def test_page_average_nonnegative_and_bounded_by_smaller_subsystem(self):
        for n in range(1, 8):
            for k in range(n + 1):
                value = page_entropy_haar_average(n, k)
                self.assertGreaterEqual(value, -1e-12)
                self.assertLessEqual(value, min(k, n-k)*math.log(2)+1e-12)

    def test_entropy_eigenvalue_validation(self):
        self.assertAlmostEqual(von_neumann_entropy_from_eigenvalues(np.array([0.5, 0.5])), math.log(2))
        self.assertEqual(von_neumann_entropy_from_eigenvalues(np.array([1.0, 0.0])), 0.0)
        with self.assertRaises(ValueError): von_neumann_entropy_from_eigenvalues(np.array([-0.1, 1.1]))
        with self.assertRaises(ValueError): von_neumann_entropy_from_eigenvalues(np.array([0.2, 0.2]))

    def test_monte_carlo_close_to_page_mean_for_fixed_seed(self):
        rows = entropy_curve_monte_carlo(n_qubits=6, samples=100, seed=12345)
        for row in rows[1:-1]:
            self.assertLess(abs(row['entropy_monte_carlo_nats']-row['page_haar_mean_nats']), 0.12)

    def test_invalid_inputs_rejected(self):
        with self.assertRaises(ValueError): entropy_curve_monte_carlo(n_qubits=0)
        with self.assertRaises(ValueError): entropy_curve_monte_carlo(n_qubits=4, samples=0)
        with self.assertRaises(ValueError): page_entropy_haar_average(4, 5)

if __name__ == '__main__':
    unittest.main()
