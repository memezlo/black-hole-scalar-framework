#!/usr/bin/env python3
"""Finite-dimensional Haar-state entropy benchmark for Page-curve intuition.

For a random pure state on n qubits, this computes the von Neumann entropy of
subsystems of k qubits and compares the Monte Carlo mean with Page's exact
Haar-average formula. It is a quantum-information benchmark only: it has no
black-hole spacetime, Hamiltonian, Hawking pair creation, greybody factors, or
island/QES calculation, so it does not solve the information paradox.
"""
from __future__ import annotations
import math
from typing import Any
import numpy as np


def _validate(n_qubits: int, samples: int) -> None:
    if not isinstance(n_qubits, int) or n_qubits < 1 or n_qubits > 12:
        raise ValueError('n_qubits must be an integer in [1, 12]')
    if not isinstance(samples, int) or samples < 1:
        raise ValueError('samples must be a positive integer')


def von_neumann_entropy_from_eigenvalues(eigenvalues: np.ndarray) -> float:
    """Entropy S=-Tr(rho ln rho), in nats, with robust zero handling."""
    values = np.asarray(eigenvalues, dtype=float)
    if values.ndim != 1 or not np.all(np.isfinite(values)):
        raise ValueError('eigenvalues must be a finite one-dimensional array')
    if np.any(values < -1e-10):
        raise ValueError('density-matrix eigenvalues cannot be negative')
    values = np.clip(values, 0.0, None)
    total = float(values.sum())
    if not math.isclose(total, 1.0, rel_tol=1e-8, abs_tol=1e-10):
        raise ValueError('eigenvalues must sum to one')
    positive = values[values > 0]
    return float(-np.sum(positive * np.log(positive)))


def page_entropy_haar_average(n_qubits: int, k_subsystem: int) -> float:
    """Exact Page average entropy (nats) for a Haar-random pure state split.

    For subsystem dimensions m <= n, <S_A> = H_(mn) - H_n - (m-1)/(2n).
    This is a theorem about Haar-random finite-dimensional pure states.
    """
    if not isinstance(n_qubits, int) or n_qubits < 1 or n_qubits > 12:
        raise ValueError('n_qubits must be an integer in [1, 12]')
    if not isinstance(k_subsystem, int) or not 0 <= k_subsystem <= n_qubits:
        raise ValueError('k_subsystem must be in [0, n_qubits]')
    m0, n0 = 2**k_subsystem, 2**(n_qubits-k_subsystem)
    m, n = min(m0, n0), max(m0, n0)
    h_mn = math.fsum(1.0 / j for j in range(1, m*n+1))
    h_n = math.fsum(1.0 / j for j in range(1, n+1))
    return h_mn - h_n - (m-1.0)/(2.0*n)


def entropy_curve_monte_carlo(n_qubits: int = 8, samples: int = 64,
                              seed: int = 20261020) -> list[dict[str, float | int]]:
    """Average radiation-subsystem entropy for random pure state vectors.

    Each vector is Haar distributed by normalizing iid complex Gaussian
    amplitudes. For each k, the vector is reshaped as (2**k, 2**(N-k)); the
    reduced density matrix is Psi Psi^dagger. This is an entanglement
    benchmark, not a time-evolved evaporation circuit.
    """
    _validate(n_qubits, samples)
    if not isinstance(seed, int):
        raise ValueError('seed must be an integer')
    rng = np.random.default_rng(seed)
    dim = 2**n_qubits
    sums = np.zeros(n_qubits + 1, dtype=float)
    sums_sq = np.zeros(n_qubits + 1, dtype=float)
    for _ in range(samples):
        psi = rng.normal(size=dim) + 1j*rng.normal(size=dim)
        psi = psi / np.linalg.norm(psi)
        for k in range(n_qubits + 1):
            d_a, d_b = 2**k, 2**(n_qubits-k)
            matrix = psi.reshape((d_a, d_b))
            if d_a == 1 or d_b == 1:
                entropy = 0.0
            else:
                rho = matrix @ matrix.conj().T
                rho = (rho + rho.conj().T) * 0.5
                eigvals = np.linalg.eigvalsh(rho)
                eigvals = np.clip(eigvals, 0.0, None)
                eigvals /= eigvals.sum()
                entropy = von_neumann_entropy_from_eigenvalues(eigvals)
            sums[k] += entropy
            sums_sq[k] += entropy*entropy
    rows: list[dict[str, float | int]] = []
    for k in range(n_qubits + 1):
        mean = float(sums[k] / samples)
        variance = max(0.0, float(sums_sq[k] / samples - mean*mean))
        rows.append({
            'n_qubits_total': n_qubits,
            'qubits_in_radiation_subsystem': k,
            'hilbert_dim_radiation': 2**k,
            'hilbert_dim_complement': 2**(n_qubits-k),
            'entropy_monte_carlo_nats': mean,
            'entropy_sample_std_nats': math.sqrt(variance),
            'page_haar_mean_nats': page_entropy_haar_average(n_qubits, k),
            'seed': seed,
            'samples': samples,
        })
    return rows
