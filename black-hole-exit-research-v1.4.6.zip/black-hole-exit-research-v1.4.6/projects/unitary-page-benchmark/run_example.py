#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
from page_benchmark import entropy_curve_monte_carlo

HERE = Path(__file__).resolve().parent

def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--qubits', type=int, default=8)
    p.add_argument('--samples', type=int, default=64)
    p.add_argument('--seed', type=int, default=20261020)
    p.add_argument('--output-dir', type=Path, default=HERE / 'results')
    args = p.parse_args()
    rows = entropy_curve_monte_carlo(args.qubits, args.samples, args.seed)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    out = args.output_dir / 'haar_page_curve.csv'
    with out.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader(); writer.writerows(rows)
    max_abs = max(abs(float(r['entropy_monte_carlo_nats']) - float(r['page_haar_mean_nats'])) for r in rows)
    summary = {
        'model': 'finite-dimensional Haar-random pure state subsystem entanglement benchmark',
        'n_qubits': args.qubits, 'samples': args.samples, 'seed': args.seed,
        'maximum_absolute_deviation_from_analytic_Page_mean_nats': max_abs,
        'initial_entropy_nats': rows[0]['entropy_monte_carlo_nats'],
        'final_entropy_nats': rows[-1]['entropy_monte_carlo_nats'],
        'does_not_include': ['black-hole geometry', 'Hawking pair creation', 'semiclassical backreaction', 'QES/island formula', 'evaporation S-matrix'],
        'interpretation': 'quantum-information benchmark; not a black-hole information-paradox solution',
    }
    (args.output_dir / 'haar_page_curve_summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(summary, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
