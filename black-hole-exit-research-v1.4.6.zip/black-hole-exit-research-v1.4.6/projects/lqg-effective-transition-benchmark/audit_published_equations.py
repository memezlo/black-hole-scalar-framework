#!/usr/bin/env python3
"""Symbolically audit the Project C mapping to published effective-LQG equations.

Requires optional SymPy dependency from the repository root's
requirements-symbolic.txt. This proves algebraic identities for the chosen
ansatz, not that the ansatz follows from full fundamental LQG.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path
import sympy as sp


def audit() -> dict:
    x, M, Delta = sp.symbols("x M Delta", positive=True, finite=True)
    ell = sp.symbols("ell", nonnegative=True, integer=True)
    f = 1 - 2*M/x
    lam = sp.sqrt(Delta)/x
    h = 1 + lam**2*f
    cubic = sp.factor(x**3*h)
    expected_cubic = x**3 + Delta*x - 2*M*Delta
    cubic_residual = sp.simplify(cubic - expected_cubic)

    # Published potential: V=A[l(l+1)/x² + 2M/x³ + f(3MΔ/x⁵ - Δ f/x⁴)].
    V_published = f * (ell*(ell+1)/x**2 + 2*M/x**3
                       + f*(3*M*Delta/x**5 - Delta*f/x**4))
    # General static spherical metric formula for A=f, B=1/(f h).
    A, B = f, 1/(f*h)
    V_metric = A*(ell*(ell+1)/x**2 + (sp.diff(A,x)/A - sp.diff(B,x)/B)/(2*x*B))
    potential_residual = sp.factor(sp.cancel(V_metric - V_published))
    potential_simplified = sp.factor(sp.cancel(V_metric))

    if cubic_residual != 0 or potential_residual != 0:
        raise AssertionError(f"Symbolic identity failure: cubic={cubic_residual}; potential={potential_residual}")
    return {
        "source": "Belfaqih et al., Physical Review Letters 135, 161501 (2025), Eqs. (1), (5), (6)",
        "doi": "10.1103/t6q4-4l77",
        "ansatz": "lambda(x)=sqrt(Delta)/x; h(x)=1+lambda(x)^2 f(x); f(x)=1-2M/x",
        "symbolic_checks": {
            "transition_cubic_identity": {"status": "PASS", "residual": str(cubic_residual), "identity": "x^3 h(x) = x^3 + Delta*x - 2*M*Delta"},
            "scalar_radial_potential_identity": {"status": "PASS", "residual": str(potential_residual), "published_form": str(V_published), "metric_derivative_form_simplified": str(potential_simplified)},
        },
        "scope_warning": "These are algebraic derivations inside the chosen published covariant effective-LQG model. They are not a derivation from the full fundamental LQG Hilbert-space dynamics, a collapse solution, or a proof of a black-to-white transition.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=None, help="optional JSON output path")
    args = parser.parse_args()
    result = audit()
    payload = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload, encoding="utf-8")
    print(payload, end="")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
