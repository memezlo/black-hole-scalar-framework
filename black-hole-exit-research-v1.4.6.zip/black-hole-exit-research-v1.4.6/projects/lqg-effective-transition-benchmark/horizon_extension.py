#!/usr/bin/env python3
"""Local analytic checks at the simple outer horizon x_H=2M.

For the specified effective metric f=1-2M/x and h=1+Delta*f/x^2,
this module derives the horizon surface gravity, the finite regular part of the
modified tortoise coordinate, the Kruskal conformal-factor limit, and curvature
invariants at x=2M. It does not construct the full global atlas or identify the
asymptotic region reached after reflection at x_Delta.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path

from model import Parameters


@dataclass(frozen=True)
class HorizonData:
    M: float
    Delta: float
    x_horizon: float
    f_horizon: float
    h_horizon: float
    f_prime_horizon: float
    surface_gravity: float
    regularized_tortoise_derivative_limit: float
    kruskal_conformal_factor_limit: float
    ricci_scalar_horizon: float
    ricci_tensor_square_horizon: float
    kretschmann_horizon: float


def horizon_data(p: Parameters) -> HorizonData:
    """Exact local formulas evaluated at x_H=2M for the static effective metric."""
    p.validate()
    M, Delta = float(p.M), float(p.Delta)
    x_h = 2.0 * M
    f_h = 0.0
    h_h = 1.0
    f_prime_h = 1.0 / (2.0 * M)
    kappa = 1.0 / (4.0 * M)  # f'(x_H)*sqrt(h_H)/2
    q_prime_limit = 1.0 - Delta / (8.0 * M * M)
    kruskal_limit = -1.0 / (kappa * kappa)
    ricci = -Delta / (32.0 * M**4)
    ricci_square = Delta**2 / (2048.0 * M**8)
    kretschmann = (Delta**2 - 32.0 * Delta * M**2 + 768.0 * M**4) / (1024.0 * M**8)
    values = (x_h, f_h, h_h, f_prime_h, kappa, q_prime_limit, kruskal_limit,
              ricci, ricci_square, kretschmann)
    if not all(math.isfinite(v) for v in values):
        raise ArithmeticError("non-finite outer-horizon data")
    return HorizonData(
        M=M, Delta=Delta, x_horizon=x_h, f_horizon=f_h, h_horizon=h_h,
        f_prime_horizon=f_prime_h, surface_gravity=kappa,
        regularized_tortoise_derivative_limit=q_prime_limit,
        kruskal_conformal_factor_limit=kruskal_limit,
        ricci_scalar_horizon=ricci,
        ricci_tensor_square_horizon=ricci_square,
        kretschmann_horizon=kretschmann,
    )


def regularized_tortoise_derivative(xi: float, p: Parameters) -> float:
    """Evaluate dH/dx for r*=2M log|xi| + H, xi=(x-2M)/(2M).

    The removable limit at xi=0 is returned analytically. Elsewhere use the
    cancellation-reduced dimensionless expression
       ((1+xi)/sqrt(h(xi)) - 1)/xi,
    where h(xi)=1+Delta*xi/(4 M^2 (1+xi)^3).
    """
    p.validate()
    if not math.isfinite(xi) or xi <= -1.0:
        raise ValueError("xi must be finite and greater than -1")
    data = horizon_data(p)
    if xi == 0.0:
        return data.regularized_tortoise_derivative_limit
    h = 1.0 + p.Delta * xi / (4.0 * p.M * p.M * (1.0 + xi)**3)
    if not math.isfinite(h) or h <= 0.0:
        raise ValueError("h must remain positive in the selected near-horizon chart")
    return ((1.0 + xi) / math.sqrt(h) - 1.0) / xi


def generate_table(outdir: Path, mass_ratios: list[float], Delta: float) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "outer_horizon_chart.csv"
    first = asdict(horizon_data(Parameters(M=mass_ratios[0] * math.sqrt(Delta), Delta=Delta)))
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(first))
        writer.writeheader()
        for ratio in mass_ratios:
            writer.writerow(asdict(horizon_data(Parameters(M=float(ratio) * math.sqrt(Delta), Delta=Delta))))
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=Path("results"))
    parser.add_argument("--delta", type=float, default=1.0)
    parser.add_argument("--mass-min", type=float, default=0.1, help="minimum M/sqrt(Delta)")
    parser.add_argument("--mass-max", type=float, default=1e3, help="maximum M/sqrt(Delta)")
    parser.add_argument("--n", type=int, default=40)
    args = parser.parse_args()
    if (not math.isfinite(args.delta) or args.delta <= 0 or
            not math.isfinite(args.mass_min) or args.mass_min <= 0 or
            not math.isfinite(args.mass_max) or args.mass_max <= args.mass_min or args.n < 2):
        parser.error("Require Delta>0, 0<mass-min<mass-max, and n>=2")
    ratios = [math.exp(math.log(args.mass_min) + i * (math.log(args.mass_max)-math.log(args.mass_min))/(args.n-1))
              for i in range(args.n)]
    path = generate_table(args.outdir, ratios, args.delta)
    sample = horizon_data(Parameters(M=10.0 * math.sqrt(args.delta), Delta=args.delta))
    payload = {
        "model": "local outer-horizon Kruskal regularity and curvature benchmark for a restricted effective-LQG-inspired ansatz",
        "inspiration_reference_doi": "10.1103/t6q4-4l77",
        "framework_reference_doi": "10.1103/1tyh-87sr",
        "ansatz_note": "lambda(x)=sqrt(Delta)/x is the explicit choice used here; this local patch does not reproduce a complete global solution from the cited literature",
        "parameters": asdict(Parameters(M=10.0 * math.sqrt(args.delta), Delta=args.delta)),
        "sample": asdict(sample),
        "scope": "local checks at x=2M only; global branch matching and causal destination remain open",
    }
    (args.outdir / "outer_horizon_metadata.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"x_H={sample.x_horizon:.12g}; kappa={sample.surface_gravity:.12g}")
    print(f"R_H={sample.ricci_scalar_horizon:.12g}")
    print(f"RicciTensorSquare_H={sample.ricci_tensor_square_horizon:.12g}")
    print(f"K_H={sample.kretschmann_horizon:.12g}")
    print(f"Kruskal conformal-factor limit={sample.kruskal_conformal_factor_limit:.12g}")
    print(f"Wrote {path}")
    print("Scope: local outer-horizon patch only; no global escape proof.")


if __name__ == "__main__":
    main()
