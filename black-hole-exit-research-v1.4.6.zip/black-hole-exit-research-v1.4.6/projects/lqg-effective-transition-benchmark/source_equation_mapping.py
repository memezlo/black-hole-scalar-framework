#!/usr/bin/env python3
"""Equation-level mapping to the published covariant effective-LQG metric.

This module implements the specific ansatz used in Project C and provides two
independent expressions for the minimally coupled scalar radial potential:
(1) the published simplified expression and (2) the expression obtained from
the general static-spherical metric formula. It is not a full-LQG solver.
"""
from __future__ import annotations
import math


def f_metric(x: float, mass: float) -> float:
    _validate(x, mass, 1.0)
    return 1.0 - 2.0 * mass / x


def h_metric(x: float, mass: float, delta: float) -> float:
    _validate(x, mass, delta)
    return 1.0 + delta * f_metric(x, mass) / x**2


def transition_polynomial(x: float, mass: float, delta: float) -> float:
    _validate(x, mass, delta)
    return x**3 + delta*x - 2.0*mass*delta


def potential_from_published_expression(x: float, mass: float, delta: float,
                                        ell: int = 0) -> float:
    """V_l = f[l(l+1)/x^2 + 2M/x^3 + f(3MΔ/x^5 - Δ f/x^4)]."""
    _validate(x, mass, delta)
    if not isinstance(ell, int) or ell < 0:
        raise ValueError("ell must be a non-negative integer")
    f = f_metric(x, mass)
    return f * (ell*(ell+1)/x**2 + 2.0*mass/x**3
                + f*(3.0*mass*delta/x**5 - delta*f/x**4))


def potential_from_metric_derivatives(x: float, mass: float, delta: float,
                                      ell: int = 0) -> float:
    """Independent static-spherical expression from A=f, B=1/(f h).

    For ds²=-A dt²+B dx²+x²dΩ², the scalar potential is
    V=A[l(l+1)/x² + (A'/A - B'/B)/(2 x B)].
    Algebraically this simplifies to the published expression for this h(x).
    """
    _validate(x, mass, delta)
    if not isinstance(ell, int) or ell < 0:
        raise ValueError("ell must be a non-negative integer")
    f = f_metric(x, mass)
    if f <= 0:
        raise ValueError("potential comparison requires x > 2M")
    fp = 2.0*mass/x**2
    h = 1.0 + delta*f/x**2
    hp = delta*(fp/x**2 - 2.0*f/x**3)
    # A=f and B=1/(f h), so (A'/A - B'/B)/(2*x*B)
    # reduces stably to h*f'/x + f*h'/(2*x).
    return f * (ell*(ell+1)/x**2 + h*fp/x + f*hp/(2.0*x))


def _validate(x: float, mass: float, delta: float) -> None:
    if not all(math.isfinite(v) for v in (x, mass, delta)):
        raise ValueError("x, mass, and delta must be finite")
    if x <= 0 or mass <= 0 or delta < 0:
        raise ValueError("x and mass must be positive; delta must be non-negative")
