import math
import unittest
from source_equation_mapping import (
    h_metric, transition_polynomial,
    potential_from_published_expression, potential_from_metric_derivatives,
)


class PublishedEffectiveLQGMappingTests(unittest.TestCase):
    def test_transition_surface_polynomial_is_equivalent_to_h_zero(self):
        for mass, delta, ratio in [(0.1, 0.01, 0.7), (1.0, 0.5, 0.8), (12.0, 1.2, 0.9), (1e3, 4.0, 0.999)]:
            x = 2*mass*ratio
            lhs = x**3*h_metric(x, mass, delta)
            rhs = transition_polynomial(x, mass, delta)
            self.assertAlmostEqual(lhs, rhs, delta=2e-12*max(1.0, abs(rhs)))

    def test_metric_potential_equals_published_simplified_potential_over_grid(self):
        for mass in (0.3, 1.0, 17.0):
            for delta in (0.0, 1e-5, 0.2, 3.0):
                for ratio in (1.01, 1.2, 2.0, 7.5, 50.0):
                    x = 2*mass*ratio
                    for ell in (0, 1, 2):
                        a = potential_from_published_expression(x, mass, delta, ell)
                        b = potential_from_metric_derivatives(x, mass, delta, ell)
                        self.assertAlmostEqual(a, b, delta=2e-13*max(1.0, abs(a), abs(b)))

    def test_s_wave_potential_reduces_to_schwarzschild_when_delta_zero(self):
        for mass in (0.2, 1.0, 10.0):
            for ratio in (1.01, 1.5, 4.0, 100.0):
                x = 2*mass*ratio
                f = 1 - 2*mass/x
                expected = f*(2*mass/x**3)
                self.assertAlmostEqual(potential_from_published_expression(x, mass, 0.0), expected, places=14)

    def test_h_is_positive_outside_horizon_for_nonnegative_delta(self):
        for mass in (0.1, 1, 100):
            for delta in (0, 0.01, 1, 100):
                for x in (2.0001*mass, 3*mass, 10*mass):
                    self.assertGreater(h_metric(x, mass, delta), 0.0)

    def test_invalid_mode_and_arguments_rejected(self):
        with self.assertRaises(ValueError): potential_from_published_expression(4, 1, 1, -1)
        with self.assertRaises(ValueError): potential_from_metric_derivatives(2, 1, 1, 0)
        with self.assertRaises(ValueError): h_metric(4, 1, -1)
        with self.assertRaises(ValueError): transition_polynomial(float('nan'), 1, 1)

if __name__ == '__main__':
    unittest.main(verbosity=2)
