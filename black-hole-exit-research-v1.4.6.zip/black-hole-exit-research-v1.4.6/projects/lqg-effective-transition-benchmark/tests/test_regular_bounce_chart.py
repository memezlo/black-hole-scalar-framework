import math
import unittest

import numpy as np

from model import Parameters, transition_radius_analytic
from regular_bounce_chart import h_prime, local_bounce_data


class LocalRegularBounceChartTests(unittest.TestCase):
    def test_lapse_and_areal_radius_are_finite_at_reflection_surface(self):
        for p in (Parameters(M=1.0, Delta=1.0), Parameters(M=10.0, Delta=1.0), Parameters(M=100.0, Delta=0.5)):
            data = local_bounce_data(p)
            self.assertGreater(data.x_delta, 0.0)
            self.assertGreater(data.A_delta, 0.0)
            self.assertGreater(data.metric_determinant_factor_abs, 0.0)
            self.assertAlmostEqual(data.h_delta, 0.0, delta=2e-12)

    def test_reflection_turning_point_has_positive_second_derivative(self):
        for p in (Parameters(M=1.0, Delta=1.0), Parameters(M=10.0, Delta=1.0), Parameters(M=1e3, Delta=1.0)):
            data = local_bounce_data(p)
            self.assertGreater(data.F_prime_delta, 0.0)
            self.assertGreater(data.x_second_derivative_tau, 0.0)
            self.assertAlmostEqual(data.x_second_derivative_tau, data.F_prime_delta / 2.0, places=12)

    def test_transition_surface_derivative_identity(self):
        p = Parameters(M=10.0, Delta=1.0)
        data = local_bounce_data(p)
        expected = 3.0 * data.x_delta / p.Delta + 1.0 / data.x_delta
        self.assertAlmostEqual(data.F_prime_delta, expected, delta=1e-10)
        self.assertAlmostEqual(h_prime(data.x_delta, p), 3.0 / data.x_delta + p.Delta / data.x_delta**3, delta=1e-10)

    def test_curvature_invariants_at_surface_are_finite(self):
        for p in (Parameters(M=0.1, Delta=1.0), Parameters(M=1.0, Delta=1.0), Parameters(M=10.0, Delta=1.0), Parameters(M=1e5, Delta=1.0)):
            data = local_bounce_data(p)
            self.assertTrue(math.isfinite(data.ricci_scalar_delta))
            self.assertTrue(math.isfinite(data.ricci_tensor_square_delta))
            self.assertTrue(math.isfinite(data.kretschmann_delta))
            self.assertGreaterEqual(data.ricci_tensor_square_delta, 0.0)
            self.assertGreaterEqual(data.kretschmann_delta, 0.0)

    def test_curvature_scaling_is_dimensionally_consistent(self):
        # At fixed M/sqrt(Delta), R scales as Delta^-1 and K as Delta^-2.
        vals = []
        for delta in (1e-6, 1.0, 1e6):
            p = Parameters(M=10.0 * math.sqrt(delta), Delta=delta)
            data = local_bounce_data(p)
            vals.append((data.ricci_scalar_delta * delta, data.ricci_tensor_square_delta * delta**2, data.kretschmann_delta * delta**2))
        for pair in vals[1:]:
            self.assertAlmostEqual(pair[0], vals[0][0], delta=1e-9 * max(1.0, abs(vals[0][0])))
            self.assertAlmostEqual(pair[1], vals[0][1], delta=1e-8 * max(1.0, abs(vals[0][1])))
            self.assertAlmostEqual(pair[2], vals[0][2], delta=1e-8 * max(1.0, abs(vals[0][2])))

    def test_local_ks_null_ray_crosses_reflection_point_without_metric_epsilon(self):
        from trace_null_ray_ks import trace_local_null_ray, F_value
        p = Parameters(M=10.0, Delta=1.0)
        tau, x, x_dot, y = trace_local_null_ray(p, tau_max=0.5, samples=101, branch=1)
        x_delta = transition_radius_analytic(p)
        center = int(abs(tau).argmin())
        self.assertAlmostEqual(float(tau[center]), 0.0, places=14)
        self.assertAlmostEqual(float(x[center]), x_delta, delta=1e-10)
        self.assertAlmostEqual(float(x_dot[center]), 0.0, delta=1e-10)
        self.assertGreater(float(x[0]), x_delta)
        self.assertGreater(float(x[-1]), x_delta)
        self.assertAlmostEqual(float(x[0]), float(x[-1]), delta=1e-8)
        self.assertLess(float(np.max(np.abs(x_dot**2 - np.array([F_value(float(xx), p) for xx in x])))), 2e-7)
        self.assertTrue(np.all(np.diff(y) > 0.0))

    def test_local_ks_null_ray_is_stable_under_max_step_refinement(self):
        from trace_null_ray_ks import trace_local_null_ray
        p = Parameters(M=10.0, Delta=1.0)
        coarse = trace_local_null_ray(p, tau_max=0.5, samples=201, max_step=0.01)
        fine = trace_local_null_ray(p, tau_max=0.5, samples=201, max_step=0.0025)
        # Compare x and the spatial null coordinate y across the same output grid.
        self.assertLess(float(np.max(np.abs(coarse[1] - fine[1]))), 2e-8)
        self.assertLess(float(np.max(np.abs(coarse[3] - fine[3]))), 2e-8)

    def test_local_ks_null_ray_rejects_nonpositive_max_step(self):
        from trace_null_ray_ks import trace_local_null_ray
        for value in (0.0, -1.0, float("nan"), float("inf")):
            with self.subTest(max_step=value):
                with self.assertRaises(ValueError):
                    trace_local_null_ray(Parameters(M=10.0, Delta=1.0), max_step=value)

    def test_local_ks_chart_refuses_to_cross_outer_horizon(self):
        from trace_null_ray_ks import trace_local_null_ray
        # An intentionally oversized proper-time interval leaves the local chart;
        # the routine must fail explicitly rather than regularize a metric component.
        with self.assertRaises(RuntimeError):
            trace_local_null_ray(Parameters(M=1.0, Delta=1.0), tau_max=3.0, samples=51)


if __name__ == "__main__":
    unittest.main(verbosity=2)
