import math
import unittest

from horizon_extension import horizon_data, regularized_tortoise_derivative
from model import Parameters


class OuterHorizonChartTests(unittest.TestCase):
    def test_horizon_is_simple_and_surface_gravity_is_positive(self):
        for p in (Parameters(M=1.0, Delta=1.0), Parameters(M=10.0, Delta=0.5), Parameters(M=1e3, Delta=1e5)):
            d = horizon_data(p)
            self.assertAlmostEqual(d.x_horizon, 2.0 * p.M)
            self.assertEqual(d.f_horizon, 0.0)
            self.assertEqual(d.h_horizon, 1.0)
            self.assertAlmostEqual(d.f_prime_horizon, 1.0 / (2.0 * p.M))
            self.assertAlmostEqual(d.surface_gravity, 1.0 / (4.0 * p.M))
            self.assertGreater(d.surface_gravity, 0.0)

    def test_regularized_tortoise_derivative_has_two_sided_limit(self):
        p = Parameters(M=10.0, Delta=1.0)
        expected = 1.0 - p.Delta / (8.0 * p.M**2)
        self.assertAlmostEqual(regularized_tortoise_derivative(0.0, p), expected)
        errors = []
        for xi in (1e-3, -1e-3, 1e-4, -1e-4):
            errors.append(abs(regularized_tortoise_derivative(xi, p) - expected))
        self.assertLess(errors[2], errors[0])
        self.assertLess(errors[3], errors[1])
        self.assertTrue(all(math.isfinite(e) for e in errors))

    def test_kruskal_conformal_factor_limit_is_finite_and_scales_as_M_squared(self):
        for p in (Parameters(M=1.0, Delta=1.0), Parameters(M=10.0, Delta=1.0), Parameters(M=100.0, Delta=100.0)):
            d = horizon_data(p)
            self.assertTrue(math.isfinite(d.kruskal_conformal_factor_limit))
            self.assertAlmostEqual(d.kruskal_conformal_factor_limit, -16.0 * p.M**2)
            self.assertAlmostEqual(d.kruskal_conformal_factor_limit / p.M**2, -16.0)

    def test_horizon_curvature_invariants_are_finite_and_recover_schwarzschild_limit(self):
        p = Parameters(M=10.0, Delta=1.0)
        d = horizon_data(p)
        self.assertTrue(math.isfinite(d.ricci_scalar_horizon))
        self.assertTrue(math.isfinite(d.ricci_tensor_square_horizon))
        self.assertTrue(math.isfinite(d.kretschmann_horizon))
        self.assertGreaterEqual(d.ricci_tensor_square_horizon, 0.0)
        self.assertGreaterEqual(d.kretschmann_horizon, 0.0)
        # As Delta/M^2 -> 0, R and R_ab R^ab vanish and K -> 48 M^2/r_H^6 = 3/(4 M^4).
        small = horizon_data(Parameters(M=10.0, Delta=1e-8))
        self.assertLess(abs(small.ricci_scalar_horizon), 1e-10)
        self.assertLess(small.ricci_tensor_square_horizon, 1e-20)
        self.assertAlmostEqual(small.kretschmann_horizon, 3.0 / (4.0 * 10.0**4), delta=1e-12)


if __name__ == "__main__":
    unittest.main(verbosity=2)
