import csv
import math
import tempfile
import unittest
from pathlib import Path
import numpy as np
from model import (Parameters, f_metric, holonomy_factor,
                   transition_radius_analytic, transition_radius_numeric,
                   metric_diagonal_components, generate_table)

class EffectiveLQGTransitionSurfaceTests(unittest.TestCase):
    def test_analytic_and_numeric_roots_agree_across_scales(self):
        for m in [0.01, 0.1, 1.0, 10.0, 1e3, 1e5]:
            p=Parameters(M=m,Delta=1.0)
            self.assertAlmostEqual(transition_radius_analytic(p), transition_radius_numeric(p), delta=2e-8*max(1.0, transition_radius_analytic(p)))

    def test_transition_surface_is_inside_classical_horizon(self):
        for p in [Parameters(M=0.1,Delta=1),Parameters(M=1,Delta=1),Parameters(M=10,Delta=1),Parameters(M=1e4,Delta=1)]:
            x=transition_radius_analytic(p)
            self.assertGreater(x,0)
            self.assertLess(x,2*p.M)
            self.assertLess(abs(float(holonomy_factor(x,p))),2e-12)
            self.assertAlmostEqual(float(f_metric(2*p.M,p)),0.0,places=12)

    def test_cubic_equation_is_satisfied(self):
        for m in [0.01,0.2,2,50,1e3]:
            p=Parameters(M=m,Delta=0.7)
            x=transition_radius_analytic(p)
            residual=x**3+p.Delta*x-2*p.M*p.Delta
            self.assertAlmostEqual(residual,0.0,delta=1e-9*max(1.0,2*p.M*p.Delta))

    def test_large_mass_asymptotic_scaling(self):
        p=Parameters(M=1e6,Delta=1)
        exact=transition_radius_analytic(p)
        approx=(2*p.M*p.Delta)**(1/3)
        self.assertLess(abs(exact/approx-1.0),3e-5)

    def test_delta_rescaling_is_dimensionally_consistent(self):
        # At fixed M/sqrt(Delta), x_delta/sqrt(Delta) must be invariant.
        ratios=[]
        for delta in [1e-8,1.0,1e8]:
            p=Parameters(M=12*math.sqrt(delta),Delta=delta)
            ratios.append(transition_radius_analytic(p)/math.sqrt(delta))
        self.assertTrue(np.allclose(ratios,ratios[0],rtol=1e-12,atol=1e-12))

    def test_metric_helper_does_not_silently_clip_coordinate_singularities(self):
        p=Parameters(M=10,Delta=1)
        with self.assertRaises(ValueError): metric_diagonal_components(2*p.M,p)
        with self.assertRaises(ValueError): metric_diagonal_components(transition_radius_analytic(p),p)

    def test_csv_table_round_trips_float64_values(self):
        ratios = [0.10000000000000001, 0.7261032564717468, 12345.678901234567]
        with tempfile.TemporaryDirectory() as temp_dir:
            path = generate_table(Path(temp_dir), ratios, 1.0)
            with path.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
        self.assertEqual(len(rows), len(ratios))
        for supplied, row in zip(ratios, rows):
            self.assertEqual(float(row["M_over_sqrtDelta"]), supplied)
            expected = transition_radius_analytic(Parameters(M=supplied, Delta=1.0))
            self.assertEqual(float(row["x_delta_over_sqrtDelta"]), expected)
            self.assertLess(float(row["root_abs_difference"]), 1e-10 * max(1.0, expected))

    def test_invalid_parameters_rejected(self):
        with self.assertRaises(ValueError): transition_radius_analytic(Parameters(M=-1,Delta=1))
        with self.assertRaises(ValueError): transition_radius_numeric(Parameters(M=1,Delta=0))

if __name__=='__main__': unittest.main(verbosity=2)
