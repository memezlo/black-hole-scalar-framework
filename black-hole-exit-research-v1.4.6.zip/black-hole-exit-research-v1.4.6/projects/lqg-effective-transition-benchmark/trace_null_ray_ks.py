#!/usr/bin/env python3
"""Trace a radial null ray through a local Kantowski-Sachs bounce chart.

This is a *local* continuation around the h(x)=0 surface in the assumed
reflection-symmetric effective metric. It is not a global path through the
outer horizon and does not establish reachability of the same future null
infinity. No metric component is regularized by adding epsilon.

In the local chart
    ds^2 = -d tau^2 + A(tau) dy^2 + x(tau)^2 dOmega^2,
    A(tau) = -f(x(tau)) > 0,
    (dx/dtau)^2 = F(x) = -f(x)h(x),
we integrate the regular second-order continuation
    d2x/dtau2 = F'(x)/2,
    dy/dtau = branch/sqrt(A).
The latter follows directly from ds^2=0. A conformal coordinate eta defined by
    d eta = d tau/sqrt(A)
would instead give dy/deta = branch*1; that unit-speed relation is not
assumed for proper time tau itself.
"""
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp

from model import Parameters, f_metric, holonomy_factor, transition_radius_analytic
from regular_bounce_chart import f_prime, h_prime


def F_value(x: float, p: Parameters) -> float:
    return -float(f_metric(x, p)) * float(holonomy_factor(x, p))


def F_prime(x: float, p: Parameters) -> float:
    f = float(f_metric(x, p))
    h = float(holonomy_factor(x, p))
    return -f_prime(x, p) * h - f * h_prime(x, p)


def trace_local_null_ray(
    p: Parameters,
    *,
    tau_max: float = 0.5,
    samples: int = 401,
    branch: int = 1,
    max_step: float | None = None,
    rtol: float = 2e-10,
    atol: float = 2e-12,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return tau, x(tau), dx/dtau, y(tau) for one local radial null branch."""
    p.validate()
    if not math.isfinite(tau_max) or tau_max <= 0 or samples < 5:
        raise ValueError("require finite tau_max > 0 and samples >= 5")
    if max_step is None:
        max_step = tau_max / 100.0
    if not math.isfinite(max_step) or max_step <= 0:
        raise ValueError("max_step must be finite and positive")
    if not math.isfinite(rtol) or rtol <= 0 or not math.isfinite(atol) or atol <= 0:
        raise ValueError("rtol and atol must be finite and positive")
    if branch not in (-1, 1):
        raise ValueError("branch must be -1 or +1")

    x_delta = transition_radius_analytic(p)
    if not (0.0 < x_delta < 2.0 * p.M):
        raise ValueError("transition surface must lie within 0 < x_delta < 2M")

    # Stop before A=-f vanishes at the outer horizon: this routine is a local
    # KS-chart solver, not a substitute for a Kruskal-like horizon chart.
    horizon_gap = max(1e-8, 1e-6 * (2.0 * p.M))
    x_limit = 2.0 * p.M - horizon_gap

    def rhs(tau: float, state: np.ndarray) -> list[float]:
        x, x_dot, _y = map(float, state)
        f = float(f_metric(x, p))
        A = -f
        if not math.isfinite(A) or A <= 0.0:
            raise RuntimeError("local KS chart reached its outer-horizon boundary; use a separate horizon chart")
        return [x_dot, 0.5 * F_prime(x, p), float(branch) / math.sqrt(A)]

    def horizon_event(tau: float, state: np.ndarray) -> float:
        return x_limit - float(state[0])
    horizon_event.terminal = True
    horizon_event.direction = 0

    initial = np.array([x_delta, 0.0, 0.0], dtype=float)
    sol_neg = solve_ivp(rhs, (0.0, -tau_max), initial, method="DOP853",
                        rtol=rtol, atol=atol, dense_output=True, events=horizon_event,
                        max_step=max_step)
    sol_pos = solve_ivp(rhs, (0.0, tau_max), initial, method="DOP853",
                        rtol=rtol, atol=atol, dense_output=True, events=horizon_event,
                        max_step=max_step)
    if not sol_neg.success or sol_neg.sol is None:
        raise RuntimeError(f"Backward local-chart integration failed: {sol_neg.message}")
    if not sol_pos.success or sol_pos.sol is None:
        raise RuntimeError(f"Forward local-chart integration failed: {sol_pos.message}")
    if sol_neg.status == 1 or sol_pos.status == 1:
        raise RuntimeError("requested tau_max leaves the local KS chart before reaching the endpoint; use a separate horizon chart")

    n_neg = samples // 2 + 1
    n_pos = samples - n_neg + 1
    tau_neg = np.linspace(-tau_max, 0.0, n_neg)
    tau_pos = np.linspace(0.0, tau_max, n_pos)
    states_neg = sol_neg.sol(tau_neg).T
    states_pos = sol_pos.sol(tau_pos).T
    tau = np.concatenate((tau_neg[:-1], tau_pos))
    states = np.vstack((states_neg[:-1], states_pos))
    x, x_dot, y = states.T

    # Do not let a local-chart integration silently cross the outer horizon.
    x_tol = 1e-9 * max(1.0, abs(x_delta))
    if np.any(x < x_delta - x_tol) or np.any(x >= 2.0 * p.M):
        raise RuntimeError("local chart left its expected domain; reduce tau_max or use a global atlas")
    F = np.array([F_value(float(xx), p) for xx in x])
    A = -np.asarray(f_metric(x, p), dtype=float)
    first_integral_error = np.abs(x_dot**2 - F)
    y_dot_fd = np.gradient(y, tau, edge_order=2)
    null_condition_error = np.abs(-1.0 + A * y_dot_fd**2)
    tolerance = max(2e-7, 1000.0 * atol)
    if float(np.max(first_integral_error)) > tolerance:
        raise RuntimeError("local-chart first-integral check failed")
    if float(np.max(null_condition_error)) > 1e-4:
        raise RuntimeError("finite-difference null-condition check failed; increase samples or tighten integration")
    return tau, x, x_dot, y


def write_results(outdir: Path, *, p: Parameters | None = None, tau_max: float = 0.5,
                  samples: int = 401, branch: int = 1, max_step: float | None = None,
                  make_plot: bool = True) -> Path:
    p = p or Parameters(M=10.0, Delta=1.0)
    tau, x, x_dot, y = trace_local_null_ray(
        p, tau_max=tau_max, samples=samples, branch=branch, max_step=max_step
    )
    outdir.mkdir(parents=True, exist_ok=True)
    path = outdir / "local_ks_null_ray.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["tau", "x_areal", "dx_dtau", "y_spatial", "F=-f*h", "A=-f", "first_integral_residual", "null_condition_residual"])
        y_dot_fd = np.gradient(y, tau, edge_order=2)
        for tt, xx, xd, yy, yd in zip(tau, x, x_dot, y, y_dot_fd):
            ff = F_value(float(xx), p)
            aa = -float(f_metric(float(xx), p))
            writer.writerow([f"{tt:.12g}", f"{xx:.12g}", f"{xd:.12g}", f"{yy:.12g}",
                             f"{ff:.12g}", f"{aa:.12g}", f"{xd*xd-ff:.12g}",
                             f"{-1.0+aa*yd*yd:.12g}"])
    if make_plot:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 2, figsize=(10, 4.3))
        axes[0].plot(tau, x, lw=2)
        axes[0].axhline(transition_radius_analytic(p), ls="--", lw=1, label=r"$x_\Delta$")
        axes[0].set_xlabel(r"Proper time $\tau$")
        axes[0].set_ylabel("Areal radius x")
        axes[0].set_title("Local reflected radius")
        axes[0].legend()
        axes[1].plot(tau, y, lw=2)
        axes[1].set_xlabel(r"Proper time $\tau$")
        axes[1].set_ylabel("Spatial coordinate y")
        axes[1].set_title(r"Null branch: $dy/d\tau=\pm A^{-1/2}$")
        for ax in axes:
            ax.grid(True, alpha=0.25)
        fig.suptitle("Local Kantowski–Sachs chart only; no global escape claim")
        fig.tight_layout()
        fig.savefig(outdir / "local_ks_null_ray.png", dpi=180)
        plt.close(fig)
    print(f"x_delta={transition_radius_analytic(p):.12g}")
    print(f"x(tau=0)={x[np.argmin(np.abs(tau))]:.12g}")
    print(f"x endpoints=({x[0]:.12g}, {x[-1]:.12g})")
    print(f"max |x_dot^2-F|={np.max(np.abs(x_dot**2 - np.array([F_value(float(xx),p) for xx in x]))):.3e}")
    print("Scope: local KS-chart null propagation across tau=0, not a global event-horizon/escape proof.")
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=Path("results/local_ks_null_ray"))
    parser.add_argument("--mass", type=float, default=10.0)
    parser.add_argument("--delta", type=float, default=1.0)
    parser.add_argument("--tau-max", type=float, default=0.5)
    parser.add_argument("--samples", type=int, default=401)
    parser.add_argument("--branch", type=int, choices=(-1, 1), default=1)
    parser.add_argument("--max-step", type=float, default=None,
                        help="maximum proper-time integration step; default tau-max/100")
    parser.add_argument("--no-plot", action="store_true")
    args = parser.parse_args()
    write_results(args.outdir, p=Parameters(M=args.mass, Delta=args.delta),
                  tau_max=args.tau_max, samples=args.samples, branch=args.branch,
                  max_step=args.max_step, make_plot=not args.no_plot)


if __name__ == "__main__":
    main()
