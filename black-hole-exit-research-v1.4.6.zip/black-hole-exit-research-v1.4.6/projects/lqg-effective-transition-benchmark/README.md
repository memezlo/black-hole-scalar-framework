# Effective-LQG Transition-Surface Benchmark

This project checks the algebraic transition-surface condition in one **restricted effective-LQG-inspired metric ansatz**, using the specific scale function `lambda(x)=sqrt(Delta)/x`. The choice is motivated by Belfaqih et al., *Physical Review Letters* 135, 161501 (2025), DOI [10.1103/t6q4-4l77](https://doi.org/10.1103/t6q4-4l77), and the covariant framework described in *Physical Review D* 112, 046022 (2025), DOI [10.1103/1tyh-87sr](https://doi.org/10.1103/1tyh-87sr); the code does not reproduce every gauge, scale-function choice, effective constraint, or global patch of those papers.

For

\[
ds^2=-f(x)dt^2+\frac{dx^2}{h(x)f(x)}+x^2d\Omega^2,\quad f=1-2M/x,\quad h=1+\Delta f/x^2,
\]

the transition-surface condition `h(x_delta)=0` becomes `x_delta^3 + Delta*x_delta - 2*M*Delta = 0`. A closed-form positive root is checked against a separate bracketed numerical solve. The project exports a CSV, a plot, metadata, and regression tests. The `regular_bounce_chart.py` script additionally evaluates a local proper-time reflected chart and Ricci, Ricci-tensor-square, and Kretschmann invariants directly at `h=0`. `horizon_extension.py` checks the local Kruskal limit, surface gravity, and curvature invariants at the outer horizon `x=2M`.

## Run

```bash
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python model.py --outdir results
python regular_bounce_chart.py --outdir results
python horizon_extension.py --outdir results
```

## Scope and caveat

This is an independent numerical benchmark of one restricted ansatz motivated by the effective-LQG literature, not a reproduction of a complete published model and not a derivation of full LQG. It does not establish the global extension across the transition surface, prove that outgoing causal curves reach the same external infinity, or demonstrate that astrophysical black holes become white holes. Version 0.1.0 now supplies a local proper-time reflected chart and finite curvature invariants at `h=0` under the model's reflection assumption. The two local charts are not yet a globally matched atlas; global causal structure, effective constraints, backreaction, and observation remain unresolved. See [the derivation note](docs/REGULAR_BOUNCE_CHART_DERIVATION_RU.md).


## v1.4.6 equation audit

`source_equation_mapping.py` and `audit_published_equations.py` map the selected metric and radial scalar potential to Eqs. (1), (5), and (6) of Belfaqih et al. (PRL 2025). The symbolic residuals are zero. This is an identity inside the selected effective model at `lambda=sqrt(Delta)/x`, not a derivation from full fundamental LQG; global causal structure and dynamical backreaction remain open.
