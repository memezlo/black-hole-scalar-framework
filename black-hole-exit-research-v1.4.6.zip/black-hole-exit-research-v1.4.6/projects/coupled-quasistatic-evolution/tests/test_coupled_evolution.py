from __future__ import annotations
import csv
import math
import tempfile
import unittest
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
ROOT = PROJECT.parents[1]
sys.path.insert(0, str(PROJECT))
from coupled_evolution import (  # noqa: E402
    DEFAULT_GROWTH_TABLE, EvolutionParameters, elapsed_time, evolve,
    load_growth_table, log_gain_integral, mass_from_q,
)


class CoupledEvolutionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.table = load_growth_table(DEFAULT_GROWTH_TABLE)

    def test_growth_table_starts_at_zero_mode(self):
        self.assertAlmostEqual(float(self.table.sigma[0]), 0.0, places=14)
        self.assertTrue(all(float(b) > float(a) for a, b in zip(self.table.q, self.table.q[1:])))

    def test_no_extrapolation(self):
        with self.assertRaises(ValueError):
            self.table.sigma_of_q(float(self.table.q[-1]) + 1e-4)

    def test_mass_q_identity(self):
        ell, q = 100.0, 0.73
        m = mass_from_q(q, ell)
        self.assertAlmostEqual(ell * ell / (m * m), q, places=13)

    def test_zero_gain_at_critical_q(self):
        qc = float(self.table.q[0])
        self.assertEqual(log_gain_integral(qc, qc, 100.0, 1e-4, self.table.sigma_of_q), 0.0)

    def test_closed_time_is_zero_at_onset(self):
        qc = float(self.table.q[0])
        self.assertEqual(elapsed_time(qc, qc, 100.0, 1e-4), 0.0)

    def test_coupled_threshold_and_two_independent_checks(self):
        params = EvolutionParameters(ell_gb=100.0, kappa=1.0/(15360.0*math.pi), delta_log=10.0, q_max=0.85, sample_count=101)
        rows, summary = evolve(params, DEFAULT_GROWTH_TABLE)
        result = summary["results"]
        self.assertTrue(result["threshold_reached"])
        self.assertFalse(str(summary["inputs"]["growth_table"]).startswith("/"))
        self.assertAlmostEqual(result["log_amplification_at_stop"], 10.0, places=6)
        self.assertLess(result["ODE_vs_quadrature_log_gain_absolute_error"], 1e-5)
        self.assertLess(result["ODE_vs_analytic_time_relative_error"], 1e-7)
        self.assertLess(result["mass_equation_chain_rule_max_abs_residual"], 1e-14)
        self.assertEqual(len(rows), 101)
        self.assertAlmostEqual(float(rows[0]["log_amplification"]), 0.0, places=12)
        self.assertGreater(float(rows[-1]["elapsed_time_Planck_times"]), 0.0)

    def test_threshold_not_reached_status_is_explicit(self):
        params = EvolutionParameters(ell_gb=1.0, kappa=1.0/(15360.0*math.pi), delta_log=1e100, q_max=0.75, sample_count=11)
        rows, summary = evolve(params, DEFAULT_GROWTH_TABLE)
        self.assertFalse(summary["results"]["threshold_reached"])
        self.assertEqual(summary["status"], "threshold_not_reached_within_tabulated_domain")
        self.assertAlmostEqual(float(rows[-1]["q"]), 0.75, places=13)

    def test_input_validation(self):
        with self.assertRaises(ValueError):
            EvolutionParameters(ell_gb=0).validate()
        with self.assertRaises(ValueError):
            EvolutionParameters(sample_count=2).validate()

if __name__ == "__main__":
    unittest.main()
