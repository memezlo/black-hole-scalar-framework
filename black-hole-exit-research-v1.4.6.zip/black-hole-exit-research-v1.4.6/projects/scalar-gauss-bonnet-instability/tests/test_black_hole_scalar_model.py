"""Regression and sanity checks for the linear scalar instability solver.

These tests check the numerical implementation and an already-published
threshold; they do not test nonlinear backreaction or a black-hole bounce.
"""
import math
import unittest
import csv
import tempfile
from pathlib import Path
from dataclasses import replace

import numpy as np

from black_hole_scalar_model import (
    NumericalSettings,
    asymptotic_decay_coefficients,
    asymptotic_decay_log_derivative,
    default_q_grid,
    dimensionless_potential,
    find_critical_q,
    find_critical_q_legacy,
    integrate_growth,
    unstable_growth_rate,
    write_outputs,
)


class ScalarGaussBonnetModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.settings = NumericalSettings(outer_x=500.0)
        cls.qcrit = find_critical_q(cls.settings)

    def test_static_threshold_matches_reference_value(self):
        self.assertAlmostEqual(self.qcrit, 0.725612849, delta=2e-8)
        ratio = 1 / math.sqrt(2 * self.qcrit)
        self.assertAlmostEqual(ratio, 0.83010403, delta=2e-7)

    def test_asymptotic_tail_coefficients_follow_the_ode_recurrence(self):
        q = 0.73
        coeff = asymptotic_decay_coefficients(q, order=8)
        self.assertEqual(float(coeff[1]), 1.0)
        self.assertAlmostEqual(float(coeff[2]), 1.0 / 2.0, places=14)
        self.assertAlmostEqual(float(coeff[3]), 1.0 / 3.0, places=14)
        self.assertAlmostEqual(float(coeff[4]), 1.0 / 4.0, places=14)
        self.assertAlmostEqual(float(coeff[5]), (4.0 - 3.0 * q) / 20.0, places=14)
        self.assertLess(asymptotic_decay_log_derivative(q, 100.0, 8), 0.0)

    def test_static_threshold_converges_with_asymptotic_matching(self):
        # Matching to the decaying 1/x series avoids the O(1/X^2) bias of
        # phi + X*phi'. Independent outer boundaries must now agree tightly.
        q50 = find_critical_q(NumericalSettings(outer_x=50.0))
        q100 = find_critical_q(NumericalSettings(outer_x=100.0))
        q500 = find_critical_q(NumericalSettings(outer_x=500.0))
        self.assertLess(abs(q50 - q100), 2.0e-9)
        self.assertLess(abs(q100 - q500), 2.0e-9)
        self.assertAlmostEqual(q500, 0.72561284924, delta=2e-8)

    def test_static_threshold_is_stable_under_max_step_change(self):
        q_coarse = find_critical_q(NumericalSettings(
            outer_x=100.0, static_asymptotic_order=8, static_max_step=1.0
        ))
        q_fine = find_critical_q(NumericalSettings(
            outer_x=100.0, static_asymptotic_order=8, static_max_step=0.08
        ))
        self.assertLess(abs(q_coarse - q_fine), 2.0e-9)

    def test_legacy_finite_boundary_estimator_has_expected_domain_bias(self):
        # The old phi(X)+X*phi'(X) estimator has an O(X^-2) bias. This test
        # preserves an auditable comparison and guards against accidentally
        # reintroducing the old estimator as the production boundary condition.
        q_robin_100 = find_critical_q(NumericalSettings(outer_x=100.0))
        q_robin_200 = find_critical_q(NumericalSettings(outer_x=200.0))
        q_legacy_100 = find_critical_q_legacy(NumericalSettings(outer_x=100.0))
        q_legacy_200 = find_critical_q_legacy(NumericalSettings(outer_x=200.0))
        err100 = abs(q_legacy_100 - q_robin_100)
        err200 = abs(q_legacy_200 - q_robin_200)
        self.assertGreater(err100, 1e-5)
        self.assertGreater(err100 / err200, 3.5)
        self.assertLess(abs(q_robin_100 - q_robin_200), 2e-9)

    def test_static_threshold_converges_with_asymptotic_series_order(self):
        # At a moderately large outer boundary the ODE-derived Robin condition
        # should stabilize when the retained inverse-power order is increased.
        q4 = find_critical_q(NumericalSettings(
            outer_x=50.0, static_asymptotic_order=4, static_max_step=1.0
        ))
        q8 = find_critical_q(NumericalSettings(
            outer_x=50.0, static_asymptotic_order=8, static_max_step=1.0
        ))
        self.assertLess(abs(q4 - q8), 1.0e-9)
        self.assertAlmostEqual(q8, 0.72561284926, delta=2.0e-10)

    def test_unstable_mode_has_positive_growth_above_threshold(self):
        sigma, _ = unstable_growth_rate(0.8, self.qcrit, self.settings)
        self.assertGreater(sigma, 0)
        self.assertAlmostEqual(sigma, 0.0250845, delta=2e-5)

    def test_zero_mode_threshold_is_in_default_grid_and_grid_is_ordered(self):
        grid = default_q_grid(self.qcrit, 0.85)
        self.assertEqual(float(grid[0]), self.qcrit)
        self.assertTrue(np.all(np.diff(grid) > 0))
        self.assertLessEqual(float(grid[-1]), 0.85)

    def test_default_grid_resolves_near_threshold_onset(self):
        grid = default_q_grid(self.qcrit, 0.85)
        # These offsets are directly solved eigenvalue samples rather than a
        # wide PCHIP bridge from qcrit to q=0.73.
        for offset in (0.00025, 0.00050, 0.00075, 0.00100, 0.00150, 0.00200):
            self.assertTrue(np.any(np.isclose(grid, self.qcrit + offset, rtol=0.0, atol=2e-15)))
        settings = NumericalSettings()
        self.assertGreaterEqual(settings.max_matching_domain, 100000.0)
        self.assertLessEqual(settings.growth_atol, 2e-14)
        self.assertLessEqual(settings.growth_rtol, 2e-10)

    def test_near_threshold_growth_rate_stable_under_max_step_refinement(self):
        # Close to onset sigma~1e-4, so loose absolute/root tolerances can mask
        # percent-level relative uncertainty even when the ODE integration reports success.
        coarse = replace(NumericalSettings(), growth_max_step=12.0)
        fine = replace(NumericalSettings(), growth_max_step=6.0)
        sigma_coarse, _ = unstable_growth_rate(self.qcrit + 2.5e-4, self.qcrit, coarse)
        sigma_fine, _ = unstable_growth_rate(self.qcrit + 2.5e-4, self.qcrit, fine)
        relative_difference = abs(sigma_coarse - sigma_fine) / abs(sigma_fine)
        self.assertLess(relative_difference, 5e-8)

    def test_potential_tends_to_zero_at_both_ends(self):
        # y -> -infinity approaches the horizon; y -> +infinity is asymptotic infinity.
        self.assertAlmostEqual(dimensionless_potential(-100.0, self.qcrit), 0.0, delta=1e-14)
        self.assertAlmostEqual(dimensionless_potential(100.0, self.qcrit), 0.0, delta=1e-5)

    def test_growth_integral_rejects_extrapolation(self):
        grid = np.array([0.72, 0.75, 0.80])
        sigma = np.array([0.0, 0.01, 0.025])
        _, integral = integrate_growth(grid, sigma)
        self.assertGreater(integral(0.80), 0.0)
        with self.assertRaises(ValueError):
            integral(0.81)

    def test_saved_growth_tables_round_trip_float64_precision(self):
        # Result CSVs are public numerical artifacts; 12 significant digits can
        # shift an independently reconstructed near-threshold interpolation.
        qgrid = np.array([0.7256128492586498, 0.7261032564717468, 0.73])
        sigma = np.array([0.0, 0.0001781058973721044, 0.0007])
        domains = np.array([0.0, 45324.92711696645, 30000.0])
        interp, integral = integrate_growth(qgrid, sigma)
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            write_outputs(out, qgrid, sigma, domains, interp, integral)
            with (out / "growth_rates.csv").open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), len(qgrid))
            for i, row in enumerate(rows):
                self.assertEqual(float(row["q"]), float(qgrid[i]))
                self.assertEqual(float(row["sigma_Gamma_times_rH"]), float(sigma[i]))
                self.assertEqual(float(row["matching_half_domain_Y"]), float(domains[i]))
            with (out / "growth_integral.csv").open(newline="", encoding="utf-8") as handle:
                integral_rows = list(csv.DictReader(handle))
            # The first and last coordinates are included in the dense output.
            self.assertEqual(float(integral_rows[0]["q"]), float(qgrid[0]))
            self.assertEqual(float(integral_rows[-1]["q"]), float(qgrid[-1]))


if __name__ == "__main__":
    unittest.main(verbosity=2)
