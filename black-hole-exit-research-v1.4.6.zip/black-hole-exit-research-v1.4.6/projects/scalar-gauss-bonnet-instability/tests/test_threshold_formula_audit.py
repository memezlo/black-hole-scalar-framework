from __future__ import annotations

import math
import unittest
from pathlib import Path

from audit_growth_threshold import (
    integrated_growth_mass,
    integrated_growth_q,
    load_growth_curve,
    solve_endpoint,
)


PROJECT_DIR = Path(__file__).resolve().parents[1]


class ThresholdFormulaAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.curve = load_growth_curve(PROJECT_DIR / "results" / "growth_rates.csv")
        cls.ell = 100.0
        cls.kappa = 1.0 / (15360.0 * math.pi)

    def test_q_and_mass_integrals_agree_at_interior_point(self):
        q_end = 0.7261032564717468
        from_q = integrated_growth_q(q_end, self.ell, self.kappa, self.curve)
        from_mass = integrated_growth_mass(q_end, self.ell, self.kappa, self.curve)
        self.assertGreater(from_q, 0.0)
        self.assertAlmostEqual(from_q, from_mass, delta=1e-8 * from_q)

    def test_baseline_endpoint_reaches_input_threshold_in_both_variables(self):
        result = solve_endpoint(self.ell, self.kappa, 10.0, self.curve)
        self.assertEqual(result["status"], "conditional_threshold_found")
        self.assertIsNotNone(result["q_end"])
        self.assertAlmostEqual(float(result["delta_log_q_integral"]), 10.0, delta=1e-7)
        self.assertAlmostEqual(float(result["delta_log_mass_integral"]), 10.0, delta=1e-7)
        self.assertLess(float(result["relative_integral_disagreement"]), 1e-8)
        self.assertGreater(float(result["q_end"]), self.curve.q_crit)
        self.assertLess(float(result["q_end"]), self.curve.q_max)

    def test_threshold_outside_tabulated_domain_is_not_extrapolated(self):
        result = solve_endpoint(self.ell, self.kappa, 1e9, self.curve)
        self.assertEqual(result["status"], "no_root_inside_tabulated_q_domain")
        self.assertIsNone(result["q_end"])
        self.assertIsNone(result["M_end"])

    def test_rejects_nonpositive_or_nonfinite_parameters(self):
        for ell, kappa, delta in ((0.0, self.kappa, 10.0), (self.ell, -1.0, 10.0), (self.ell, self.kappa, 0.0), (math.inf, self.kappa, 10.0)):
            with self.subTest(ell=ell, kappa=kappa, delta=delta):
                with self.assertRaises(ValueError):
                    solve_endpoint(ell, kappa, delta, self.curve)


if __name__ == "__main__":
    unittest.main()
