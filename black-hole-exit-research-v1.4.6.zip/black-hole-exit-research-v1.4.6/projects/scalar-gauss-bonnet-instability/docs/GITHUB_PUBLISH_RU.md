# Публикация репозитория на GitHub (Windows)

## Перед публикацией

1. Распакуй архив в постоянную папку, например `C:\\Projects\\scalar-gauss-bonnet-instability`.
2. Прочитай `README_RU.md`, `docs/PHYSICS_RU.md` и `docs/BOUNCE_LOGIC_AUDIT_RU.md` — эти файлы описывают именно тот результат, который действительно рассчитан.
3. Убедись, что в `CITATION.cff` и метаданных GitHub указаны только те имя/авторы, которые ты действительно хочешь публиковать. Не добавляй соавторов, не согласовав это с ними.
4. Создай на GitHub **пустой** репозиторий с именем `scalar-gauss-bonnet-instability`. Не добавляй при создании второй README или лицензию, потому что они уже находятся в проекте.

## Загрузка с Git

Установи Git for Windows, открой PowerShell в папке проекта и выполни:

```powershell
git init
git add .
git commit -m "Add numerical convergence audit for scalar instability solver"
git branch -M main
git remote add origin https://github.com/ТВОЙ-ЛОГИН/scalar-gauss-bonnet-instability.git
git push -u origin main
```

Замени `ТВОЙ-ЛОГИН` на свой GitHub username. При первом `push` GitHub может запросить вход через браузер или токен в соответствии с настройкой Git.

## Рекомендуемое описание GitHub-репозитория

> Reproducible numerical study of a linear scalar–Gauss–Bonnet instability on a fixed Schwarzschild background, with a conditional integral estimate under a prescribed mass-loss law.

## Как корректно представлять результат

Говори, что это открытый численный исследовательский проект, который воспроизводит известный порог линейной скалярной неустойчивости и изучает условную оценку накопленного усиления. Не называй его доказательством отскока, решением из LQG/теории струн или новым законом физики. Для признания фундаментального открытия нужны научная новизна, независимая проверка и публикационная экспертиза; один репозиторий этого не обеспечивает.

## Если нужен именно RAR

Архив, приложенный к ответу, имеет формат ZIP, который корректно поддерживает текущая среда сборки. Если тебе нужен именно `.rar`, открой ZIP в WinRAR, выбери папку проекта и нажми **Добавить в архив… → Формат архива: RAR**. Не меняй расширение `.zip` на `.rar` вручную: это не преобразует формат.
