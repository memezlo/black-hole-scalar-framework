# Research status / статус результатов

## Reproduced or directly computed here

- A numerical static zero-mode threshold for a specified linear scalar equation on a Schwarzschild background.
- A linear bound-state growth rate above that threshold from a matching calculation.
- A quadrature along an externally prescribed mass-loss law, conditional on input `kappa` and `Delta`.
- Finite outer-boundary convergence checks and regression tests.
- In version 1.1.0, an explicit logic audit showing why the fixed-background calculation cannot, by construction, predict a black-hole-to-white-hole transition.

## Known background from literature

Scalar–Gauss–Bonnet couplings and tachyonic scalar instabilities/spontaneous scalarization have an established literature. The reference threshold is consistent with Fernandes, Mulryne & Delgado (2022), https://doi.org/10.1088/1361-6382/aca010.

Nonlinear scalar–Gauss–Bonnet simulations exist. Some formulations encounter loss of hyperbolicity as the scalar field/gradients become large; one study found this occurred after the effective field theory was outside its regime of validity (Doneva et al., 2023, https://doi.org/10.1103/PhysRevD.108.084017). A 2026 study analyzes nonlinear scalarization and descalarization channels in an extended theory, not a universal black-hole-to-white-hole conversion mechanism (Ye, Liu & Zhang, https://doi.org/10.1140/epjc/s10052-025-15272-w).

Black-hole-to-white-hole transitions also appear in separate phenomenological models, for example Hergott, Husain & Rastgoo (Physical Review D, published 22 January 2026), https://doi.org/10.1103/8m7g-zz3k. Such model-specific papers do not establish an observed transition or validate the present scalar-instability code as a derivation from LQG or string theory.

## Not established by this repository

- a new fundamental law;
- a novel critical threshold absent from prior work;
- a derivation from LQG, string theory, or a complete UV theory;
- Hawking radiation calculated self-consistently;
- nonlinear saturation or metric backreaction;
- singularity resolution;
- a black-hole-to-white-hole bounce;
- an observationally confirmed phenomenon.

## Next research stage

First select one concrete theory rather than mixing a classical scalar–Gauss–Bonnet perturbation model with a separate quantum-gravity-inspired bounce ansatz. If continuing the present theory, derive and evolve the fully coupled metric-scalar equations, monitor hyperbolicity and effective-theory validity, and test convergence of horizons and curvature invariants. If the central goal is a black-to-white transition, select a specific published effective LQG-inspired model and reproduce its equations and diagnostics separately. A literature review must identify exactly which proposed step would be new.

Until such work exists, all mass-threshold outputs must be presented as conditional results of the stated linear-plus-prescribed-evaporation model.
