#!/usr/bin/env python3
"""Reproducible exploratory calculation: scalar-Gauss-Bonnet instability.

Purpose
-------
1. Find the static, nodeless scalar zero-mode threshold on a fixed Schwarzschild
   background for a massless s-wave in a quadratic scalar-Gauss-Bonnet model.
2. Calculate the linear unstable-mode growth rate by matching logarithmic
   derivatives at large negative/positive tortoise coordinate.
3. Combine that rate with a toy Hawking mass-loss law dM/dt = -kappa/M**2 to
   estimate when a chosen log-amplitude threshold is reached.

This is NOT a self-consistent evaporation or quantum-gravity calculation.
It does not evolve the metric, calculate the Hawking flux from greybody factors,
compute nonlinear saturation, remove a singularity, or produce a black-to-white
hole bounce. The nonlinear threshold Delta=ln(A_nl/|A_seed|) is an input.

Units and definitions
---------------------
Use G=c=hbar=1, so masses and lengths are measured in Planck units. The action
normalization is chosen so that the linearized scalar equation is
    Box(phi) + ell_GB**2 * G_B * phi = 0,
where G_B is the Gauss-Bonnet invariant. Define
    q = ell_GB**2 / M**2,
    r_H = 2 M,
    y = r_*/r_H = x + log(x-1), x=r/r_H.
For the massless l=0 mode, the dimensionless Schrödinger potential is
    V(y) = (1 - 1/x) * (x**(-3) - 3*q*x**(-6)).
An unstable mode has omega = i*Gamma and sigma=Gamma*r_H > 0.

For the illustrative evaporation law dM/dt=-kappa/M**2,
    I(q) = ell_GB**2/(4*kappa) * integral[qcrit -> q] sigma(u)/u**2 du.
The chosen threshold is reached when I(q_end)=Delta. A root means only that the
linear amplitude model reaches the input threshold, not that a bounce occurs.

Dependencies: numpy, scipy; matplotlib optional for --plot.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import platform
import sys
import warnings
from datetime import datetime, timezone
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.integrate import quad, solve_ivp, cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from scipy.special import lambertw


@dataclass(frozen=True)
class NumericalSettings:
    outer_x: float = 1500.0
    horizon_eps: float = 1e-5
    static_rtol: float = 3e-10
    static_atol: float = 3e-12
    static_max_step: float = 1.0
    static_asymptotic_order: int = 8
    # Near threshold, w= u'/u is O(1e-4); the old 2e-10 absolute tolerance
    # and 1e-10 root xtol dominated the requested relative accuracy. Use tighter
    # tolerances, while keeping a larger max step for practical runtime.
    growth_rtol: float = 2e-10
    growth_atol: float = 2e-14
    growth_max_step: float = 12.0
    matching_domain_factor: float = 8.0
    max_matching_domain: float = 120000.0


def asymptotic_decay_coefficients(q: float, order: int = 8) -> np.ndarray:
    r"""Coefficients of the decaying zero-mode tail, phi ~ sum a_n/x**n.

    For the dimensionless ODE
        d/dx [x(x-1) phi'] + 3 q x**(-4) phi = 0,
    the nodeless decaying branch has a_1=1 and, for n>=2,
        a_n = ((n-1)**2 a_(n-1) - 3 q a_(n-4)) / (n(n-1)),
    taking a_j=0 for j<=0. The normalization a_1=1 is arbitrary; only
    the logarithmic derivative of the tail is used in the boundary condition.
    """
    if not np.isfinite(q) or q < 0:
        raise ValueError("q must be finite and non-negative")
    if not isinstance(order, int) or order < 3:
        raise ValueError("asymptotic order must be an integer >= 3")
    coeff = np.zeros(order + 1, dtype=float)
    coeff[1] = 1.0
    for n in range(2, order + 1):
        gb_source = 3.0 * q * coeff[n - 4] if n >= 4 else 0.0
        coeff[n] = ((n - 1)**2 * coeff[n - 1] - gb_source) / (n * (n - 1))
    return coeff


def asymptotic_decay_log_derivative(q: float, x: float, order: int = 8) -> float:
    r"""Return S'_N(x)/S_N(x) for the decaying asymptotic series.

    Matching logarithmic derivatives avoids the O(x**-2) contamination in
    the older finite-boundary estimator phi + x*phi'.
    """
    if not np.isfinite(x) or x <= 1.0:
        raise ValueError("the outer boundary x must be finite and > 1")
    coeff = asymptotic_decay_coefficients(q, order)
    n = np.arange(1, order + 1, dtype=float)
    powers = np.power(x, -n)
    tail = float(np.dot(coeff[1:], powers))
    tail_prime = float(np.dot(-n * coeff[1:], powers / x))
    if not np.isfinite(tail) or abs(tail) <= np.finfo(float).tiny:
        raise ArithmeticError("asymptotic tail is numerically singular at the selected boundary")
    return tail_prime / tail


def _integrate_static_profile(q: float, settings: NumericalSettings) -> tuple[float, float]:
    """Integrate the horizon-regular zero-mode profile to the finite boundary."""
    if not np.isfinite(q) or q < 0:
        raise ValueError("q must be finite and non-negative")
    eps = settings.horizon_eps
    if not (0.0 < eps < 1.0) or not np.isfinite(settings.outer_x) or settings.outer_x <= 1.0 + eps:
        raise ValueError("require 0 < horizon_eps < 1 and outer_x > 1 + horizon_eps")
    x0 = 1.0 + eps
    a = -3.0 * q
    b = 4.5 * q + 2.25 * q * q
    y0 = [1.0 + a * eps + b * eps * eps, a + 2.0 * b * eps]

    def rhs(x: float, y: np.ndarray) -> list[float]:
        phi, dphi = y
        p = x * (x - 1.0)
        dp = 2.0 * x - 1.0
        return [dphi, -(dp * dphi + 3.0 * q * x**(-4) * phi) / p]

    sol = solve_ivp(
        rhs, (x0, settings.outer_x), y0,
        rtol=settings.static_rtol, atol=settings.static_atol,
        max_step=settings.static_max_step, method="DOP853",
    )
    if not sol.success:
        raise RuntimeError(f"Static ODE integration failed: {sol.message}")
    phi, dphi = sol.y[:, -1]
    if not (np.isfinite(phi) and np.isfinite(dphi)):
        raise ArithmeticError("Static ODE integration returned non-finite boundary data")
    return float(phi), float(dphi)


def static_shooting_residual(q: float, settings: NumericalSettings) -> float:
    r"""Match the regular horizon solution to the decaying asymptotic branch.

    At a finite outer boundary X, impose phi'(X)-L_decay(X,q)*phi(X)=0,
    where L_decay is the logarithmic derivative of the ODE-derived asymptotic
    1/x series. This is an asymptotic Robin condition, not a claim that the tail
    vanishes at finite radius.
    """
    if settings.static_asymptotic_order < 3:
        raise ValueError("static_asymptotic_order must be >= 3")
    phi, dphi = _integrate_static_profile(q, settings)
    log_derivative = asymptotic_decay_log_derivative(
        q, settings.outer_x, settings.static_asymptotic_order
    )
    # Avoid division by phi: this mismatch remains continuous at roots of phi.
    return float(dphi - log_derivative * phi)


def static_shooting_residual_legacy(q: float, settings: NumericalSettings) -> float:
    r"""Return the old finite-boundary estimator phi(X)+X*phi'(X).

    Retained only to quantify the finite-domain bias of the estimator that was
    replaced by asymptotic Robin matching. Do not use this as the production
    boundary condition.
    """
    phi, dphi = _integrate_static_profile(q, settings)
    return float(phi + settings.outer_x * dphi)


def find_critical_q_legacy(settings: NumericalSettings) -> float:
    """Find the old finite-boundary estimate for audit/comparison only."""
    return float(brentq(
        lambda q: static_shooting_residual_legacy(q, settings),
        0.70, 0.80, xtol=2e-12, rtol=1e-13,
    ))

def find_critical_q(settings: NumericalSettings) -> float:
    """Find the first nodeless static zero-mode threshold near q~0.73."""
    return float(brentq(
        lambda q: static_shooting_residual(q, settings),
        0.70, 0.80, xtol=2e-12, rtol=1e-13,
    ))


def _x_from_tortoise_y(y: float) -> float:
    """Invert y=x+ln(x-1) robustly without exp overflow at large positive y."""
    if y < -10.0:
        return 1.0 + math.exp(y - 1.0)
    if y < 40.0:
        return 1.0 + float(np.real(lambertw(math.exp(y - 1.0))))
    # For large y solve x + log(x-1) = y by Newton iteration.
    x = y - math.log(y - 1.0)
    for _ in range(10):
        fx = x + math.log(x - 1.0) - y
        dfx = 1.0 + 1.0 / (x - 1.0)
        x -= fx / dfx
    return x


def dimensionless_potential(y: float, q: float) -> float:
    """V(y)=r_H**2 V_phys for massless scalar l=0 on Schwarzschild."""
    x = _x_from_tortoise_y(y)
    f = 1.0 - 1.0 / x
    return f * (x**(-3) - 3.0 * q * x**(-6))


def _log_derivative_mismatch(sigma: float, q: float, Y: float,
                              settings: NumericalSettings) -> float:
    """Match u'/u at y=0 for a bound state u~exp(+sigma*y) left,
    u~exp(-sigma*y) right. For a growing mode omega=i*Gamma and sigma=Gamma*r_H.
    """
    if sigma <= 0:
        return math.nan

    def riccati(y: float, w: np.ndarray) -> list[float]:
        V = dimensionless_potential(y, q)
        return [sigma * sigma + V - w[0] * w[0]]

    left = solve_ivp(
        riccati, (-Y, 0.0), [sigma],
        rtol=settings.growth_rtol, atol=settings.growth_atol,
        max_step=settings.growth_max_step,
    )
    right = solve_ivp(
        riccati, (Y, 0.0), [-sigma],
        rtol=settings.growth_rtol, atol=settings.growth_atol,
        max_step=settings.growth_max_step,
    )
    if not left.success or not right.success:
        return math.nan
    wl = float(left.y[0, -1])
    wr = float(right.y[0, -1])
    if not (math.isfinite(wl) and math.isfinite(wr)):
        return math.nan
    return wl - wr


def unstable_growth_rate(q: float, qcrit: float,
                         settings: NumericalSettings) -> tuple[float, float]:
    """Calculate sigma=Gamma*r_H by matched logarithmic derivatives.

    Returns (sigma, matching half-domain Y). The linear slope estimate is used
    only to choose a numerical bracket and domain; the root itself is solved
    from the ODE boundary matching. Very close to qcrit the necessary domain is
    large. The default project grid therefore explicitly samples several
    points close to qcrit; those points require a large matching domain.
    """
    if q <= qcrit:
        return 0.0, 0.0
    delta = q - qcrit
    estimate = max(1e-7, 0.36 * delta / (1.0 + 0.5 * delta))
    Y = max(80.0, settings.matching_domain_factor / estimate)
    if Y > settings.max_matching_domain:
        raise ValueError(
            f"q={q:.9g} is too close to qcrit for the configured domain (Y={Y:.1f}). "
            "Increase max_matching_domain / matching_domain_factor or choose a q farther above qcrit."
        )

    lo, hi = 0.4 * estimate, 1.8 * estimate
    flo = _log_derivative_mismatch(lo, q, Y, settings)
    fhi = _log_derivative_mismatch(hi, q, Y, settings)
    # Expand the bracket if the first numerical estimate does not straddle a root.
    for _ in range(8):
        if math.isfinite(flo) and math.isfinite(fhi) and flo * fhi < 0:
            break
        lo = max(estimate * 1e-3, lo * 0.5)
        hi *= 1.6
        flo = _log_derivative_mismatch(lo, q, Y, settings)
        fhi = _log_derivative_mismatch(hi, q, Y, settings)
    else:
        raise RuntimeError(
            f"Could not bracket unstable-mode root for q={q:.8f}; "
            f"mismatch values were {flo!r}, {fhi!r}."
        )

    # The absolute root tolerance must be much smaller than sigma near onset;
    # xtol=1e-10 used to dominate the target when sigma is O(1e-4), limiting
    # the relative accuracy of close-to-threshold modes to only a few ppm.
    root = brentq(
        lambda s: _log_derivative_mismatch(s, q, Y, settings),
        lo, hi, xtol=1e-13, rtol=1e-10, maxiter=100,
    )
    return float(root), float(Y)


def default_q_grid(qcrit: float, qmax: float) -> np.ndarray:
    """A resolution-conscious sample grid; do not extrapolate beyond qmax."""
    # Resolve the near-threshold onset explicitly. The unstable eigenvalue
    # tends to zero as q -> qcrit, so a coarse first interval biases the PCHIP
    # interpolation and any threshold q_end inferred from the integrated rate.
    # These offsets require a larger matching domain, reflected in the default
    # NumericalSettings.max_matching_domain=120000. They are samples, not an
    # extrapolation: each sigma is solved directly by the ODE matcher.
    near_threshold = qcrit + np.array([
        0.00025, 0.00050, 0.00075, 0.00100, 0.00150, 0.00200,
    ])
    candidates = np.concatenate((np.array([
        qcrit, 0.730, 0.732, 0.735, 0.740, 0.745, 0.750, 0.760,
        0.770, 0.780, 0.800, 0.850, 0.900, 1.000, 1.200,
    ]), near_threshold))
    # Keep the threshold and only samples inside requested range.
    grid = candidates[(candidates >= qcrit) & (candidates <= qmax)]
    if len(grid) < 3 or grid[-1] <= qcrit:
        raise ValueError("qmax must be sufficiently above qcrit (recommended qmax >= 0.8).")
    return np.unique(grid)


def integrate_growth(qgrid: np.ndarray, sigma: np.ndarray) -> tuple[PchipInterpolator, callable]:
    """Monotone interpolation of sigma(q) and J(q)=integral sigma/q**2 dq."""
    interp = PchipInterpolator(qgrid, sigma, extrapolate=False)

    def J(q: float) -> float:
        if q < qgrid[0] or q > qgrid[-1]:
            raise ValueError("Requested q outside computed grid; refusing to extrapolate.")
        val, _ = quad(
            lambda u: max(0.0, float(interp(u))) / (u * u),
            float(qgrid[0]), float(q), epsabs=1e-13, epsrel=2e-8, limit=200,
        )
        return float(val)

    return interp, J


def write_outputs(outdir: Path, qgrid: np.ndarray, sigma: np.ndarray,
                  half_domains: np.ndarray, interp: PchipInterpolator, J) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    with (outdir / "growth_rates.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["q", "sigma_Gamma_times_rH", "matching_half_domain_Y", "status"])
        for q, s, Y in zip(qgrid, sigma, half_domains):
            status = "static zero-mode threshold" if Y == 0 else "linear unstable mode; asymptotic matching"
            w.writerow([f"{q:.17g}", f"{s:.17g}", f"{Y:.17g}", status])

    with (outdir / "growth_integral.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["q", "sigma_interpolated", "J_integral_int_sigma_over_q2"])
        q_dense = np.linspace(float(qgrid[0]), float(qgrid[-1]), 1001)
        sigma_dense = np.maximum(0.0, interp(q_dense))
        J_dense = cumulative_trapezoid(sigma_dense / q_dense**2, q_dense, initial=0.0)
        for q, s, jval in zip(q_dense, sigma_dense, J_dense):
            w.writerow([f"{q:.17g}", f"{float(s):.17g}", f"{float(jval):.17g}"])



def write_sensitivity(outdir: Path, qcrit: float, qmax: float, J, kappa: float) -> None:
    """Write parameter sensitivity using the already computed linear spectrum.

    This varies illustrative coupling lengths and threshold gaps. It is not a
    parameter fit: all values remain conditional on the selected toy model.
    """
    outdir.mkdir(parents=True, exist_ok=True)
    with (outdir / "sensitivity.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([
            "ell_GB_in_Planck_lengths", "Delta_log_amplification", "rho_required_J",
            "q_end", "M_crit_in_Planck_masses", "M_end_in_Planck_masses",
            "M_end_over_M_crit", "fractional_mass_loss_after_onset", "status",
        ])
        qmax_computed = qmax
        jmax = J(qmax_computed)
        for ell in (1.0, 3.0, 10.0, 30.0, 100.0, 300.0, 1000.0):
            for delta in (1.0, 10.0, 50.0):
                rho_sens = 4.0 * kappa * delta / (ell * ell)
                mcrit_sens = ell / math.sqrt(qcrit)
                if rho_sens <= jmax:
                    qe = float(brentq(lambda z: J(z) - rho_sens, qcrit, qmax_computed, xtol=1e-12))
                    mend_sens = ell / math.sqrt(qe)
                    ratio = mend_sens / mcrit_sens
                    status = "root within computed q-range"
                    vals = [ell, delta, rho_sens, qe, mcrit_sens, mend_sens, ratio, 1.0-ratio, status]
                else:
                    vals = [ell, delta, rho_sens, "NA", mcrit_sens, "NA", "NA", "NA",
                            f"no root within computed q<={qmax_computed:.3g}"]
                w.writerow([f"{v:.17g}" if isinstance(v, (int, float, np.floating)) else v for v in vals])

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ell-gb", type=float, default=100.0,
                        help="coupling length ell_GB in Planck lengths; default 100 (illustrative)")
    parser.add_argument("--kappa", type=float, default=1.0 / (15360.0 * math.pi),
                        help="toy dM/dt=-kappa/M^2 coefficient; default blackbody-scale benchmark")
    parser.add_argument("--delta-log", type=float, default=10.0,
                        help="Delta=ln(A_nl/|A_seed|); input, not predicted (default 10)")
    parser.add_argument("--qmax", type=float, default=0.85,
                        help="maximum q to sample (default 0.85; no extrapolation beyond this)")
    parser.add_argument("--outdir", type=Path, default=Path("black_hole_scalar_results"),
                        help="directory for CSV outputs")
    parser.add_argument("--plot", action="store_true", help="write a PNG summary plot (requires matplotlib)")
    parser.add_argument("--static-convergence", action="store_true",
                        help="print qcrit for several outer boundaries")
    args = parser.parse_args()

    if args.ell_gb <= 0 or args.kappa <= 0 or args.delta_log <= 0:
        parser.error("ell-gb, kappa and delta-log must be positive")
    if args.qmax <= 0.8:
        parser.error("qmax must be > 0.8 for the recommended sample grid")

    settings = NumericalSettings()
    qcrit = find_critical_q(settings)
    alpha = 8.0 * args.ell_gb**2  # convention matching Fernandes et al. Eq. (2) with xi(phi)=phi^2/2
    ratio = 1.0 / math.sqrt(2.0 * qcrit)  # r_H/sqrt(alpha)
    mcrit = args.ell_gb / math.sqrt(qcrit)  # G=1; M in Planck masses

    if args.static_convergence:
        print("Static threshold convergence (asymptotic Robin vs legacy finite-boundary estimator):")
        args.outdir.mkdir(parents=True, exist_ok=True)
        convergence_rows = []
        for outer in (50.0, 100.0, 200.0, 500.0, 1000.0, 1500.0, 2000.0):
            local = NumericalSettings(outer_x=outer)
            qc = find_critical_q(local)
            try:
                q_legacy: float | None = find_critical_q_legacy(local)
            except ValueError:
                # At some small outer boundaries the old estimator does not
                # bracket a root in the reference interval; record this rather
                # than fabricating an estimate or changing the bracket silently.
                q_legacy = None
            ratio_c = 1.0 / math.sqrt(2.0 * qc)
            delta = None if q_legacy is None else qc - q_legacy
            convergence_rows.append((outer, qc, ratio_c, q_legacy, delta))
            if q_legacy is None:
                print(f"  outer_x={outer:7.1f}  qcrit_Robin={qc:.12f}  qcrit_legacy=UNBRACKETED")
            else:
                print(
                    f"  outer_x={outer:7.1f}  qcrit_Robin={qc:.12f}  "
                    f"qcrit_legacy={q_legacy:.12f}  delta={delta:.6e}"
                )
        conv_path = args.outdir / "static_threshold_convergence.csv"
        with conv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow([
                "outer_x_r_over_rH", "q_crit_asymptotic_Robin_order8",
                "rH_over_sqrt_alpha_if_alpha_equals_8ell2",
                "q_crit_legacy_phi_plus_x_dphi", "matched_minus_legacy",
            ])
            for outer, qc, ratio_c, q_legacy, delta in convergence_rows:
                writer.writerow([
                    f"{outer:.0f}", f"{qc:.12f}", f"{ratio_c:.12f}",
                    "" if q_legacy is None else f"{q_legacy:.12f}",
                    "" if delta is None else f"{delta:.12e}",
                ])
        print(f"  wrote {conv_path.resolve()}")

    qgrid = default_q_grid(qcrit, args.qmax)
    sigma, Ys = [], []
    print("Solving growth-rate spectrum by logarithmic-derivative matching...")
    for q in qgrid:
        if abs(q - qcrit) < 1e-10:
            s, Y = 0.0, 0.0
        else:
            s, Y = unstable_growth_rate(float(q), qcrit, settings)
        sigma.append(s); Ys.append(Y)
        print(f"  q={q:.9f}  sigma=Gamma*rH={s:.10g}  Y={Y:.1f}", flush=True)
    sigma_arr = np.array(sigma)
    Y_arr = np.array(Ys)
    interp, J = integrate_growth(qgrid, sigma_arr)

    # Since q=ell_GB^2/M^2 and Gamma=sigma/(2M), the threshold equation is
    # ell_GB^2/(4 kappa) * J(q_end) = Delta.
    rho = 4.0 * args.kappa * args.delta_log / (args.ell_gb**2)
    jmax = J(float(qgrid[-1]))
    qend = None
    if rho <= jmax:
        qend = float(brentq(lambda q: J(q) - rho, float(qgrid[0]), float(qgrid[-1]), xtol=1e-12))
        mend = args.ell_gb / math.sqrt(qend)
        mass_ratio = mend / mcrit
    else:
        mend = None
        mass_ratio = None

    write_outputs(args.outdir, qgrid, sigma_arr, Y_arr, interp, J)
    write_sensitivity(args.outdir, qcrit, float(qgrid[-1]), J, args.kappa)

    # Save the exact inputs and derived quantities alongside the CSV files.
    # This makes it harder to detach conditional numbers from their assumptions.
    metadata = {
        "project": "scalar-gauss-bonnet-instability",
        "run_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "linear scalar perturbation on fixed Schwarzschild background plus prescribed mass-loss law",
        "units": {"G": 1, "c": 1, "hbar": 1, "mass": "Planck units when ell_GB is supplied in Planck lengths"},
        "inputs": {
            "ell_GB_in_Planck_lengths": args.ell_gb,
            "kappa_toy_mass_loss": args.kappa,
            "Delta_log_amplification_input": args.delta_log,
            "qmax_requested": args.qmax,
            "qmax_computed": float(qgrid[-1]),
            "alpha_convention": "alpha = 8 * ell_GB**2",
        },
        "numerics": {key: getattr(settings, key) for key in settings.__dataclass_fields__},
        "results": {
            "q_crit": qcrit,
            "rH_over_sqrt_alpha_at_onset": ratio,
            "M_crit_over_M_Pl": mcrit,
            "rho_required_integral": rho,
            "J_at_qmax": jmax,
            "q_end_conditional": qend,
            "M_end_over_M_Pl_conditional": mend,
            "M_end_over_M_crit_conditional": mass_ratio,
            "fractional_mass_decrease_conditional": None if mass_ratio is None else 1.0 - mass_ratio,
        },
        "software": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "numpy": np.__version__,
        },
        "interpretation": [
            "Delta is an input and is not predicted by the model.",
            "The mass-loss law is prescribed and is not a self-consistent Hawking-flux calculation.",
            "The scalar growth rate is computed on a fixed Schwarzschild metric.",
            "Reaching the input threshold does not imply a bounce, white hole, or singularity resolution.",
        ],
    }
    try:
        import scipy
        metadata["software"]["scipy"] = scipy.__version__
    except ImportError:
        pass
    (args.outdir / "run_metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )

    print("\nMODEL RESULT (exploratory, not a bounce prediction)")
    print(f"qcrit = {qcrit:.10f}")
    print(f"r_H/sqrt(alpha) at onset = {ratio:.8f}")
    print(f"Mcrit = {mcrit:.8g} M_Pl (assuming ell_GB is in Planck lengths and G=1)")
    print(f"ell_GB = {args.ell_gb:g} l_Pl; kappa = {args.kappa:.10g}; Delta = {args.delta_log:g}")
    print(f"rho = 4*kappa*Delta/ell_GB^2 = {rho:.12g}")
    print(f"J(qmax={qgrid[-1]:g}) = {jmax:.12g}")
    if qend is None:
        print("No threshold root within the computed q-range; do not extrapolate the model.")
    else:
        print(f"q_end = {qend:.10g}")
        print(f"M_end = {mend:.10g} M_Pl")
        print(f"M_end/Mcrit = {mass_ratio:.10g}")
        print(f"fractional mass decrease after onset = {1.0-mass_ratio:.6%}")
    if mcrit < 10.0:
        warnings.warn("Mcrit is only a few Planck masses: the semiclassical Hawking law is not reliable here.")
    if args.ell_gb > 0 and args.delta_log > 0:
        print("\nInterpretation limits:")
        print("  * The threshold Delta is an input, not a result of quantum field theory.")
        print("  * L_H=kappa/M^2 is a toy blackbody-scale law, not a full greybody/Page calculation.")
        print("  * Gamma is a linear instability rate on fixed Schwarzschild geometry.")
        print("  * Reaching Delta marks breakdown of the linear amplitude model; it does not imply a bounce.")
        print("  * No nonlinear metric backreaction or curvature-regularity test is solved.")
    print(f"CSV results saved in: {args.outdir.resolve()}")

    if args.plot:
        try:
            import matplotlib
            matplotlib.use("Agg")  # headless-safe backend for reproducible CLI runs
            import matplotlib.pyplot as plt
        except ImportError as exc:
            raise SystemExit("--plot requires matplotlib; install it with: pip install matplotlib") from exc
        dense = np.linspace(float(qgrid[0]), float(qgrid[-1]), 2000)
        sig_dense = np.maximum(0.0, interp(dense))
        j_dense = cumulative_trapezoid(sig_dense / dense**2, dense, initial=0.0)
        fig, ax = plt.subplots(figsize=(8.3, 5.0))
        ax.plot(dense, sig_dense, label=r"$\sigma=\Gamma r_H$")
        ax.set_xlabel(r"$q=\ell_{GB}^2/M^2$")
        ax.set_ylabel(r"Dimensionless growth rate $\sigma$")
        ax.grid(True, alpha=0.3)
        ax.legend()
        fig.tight_layout()
        fig.savefig(args.outdir / "growth_rate.png", dpi=180)
        plt.close(fig)
        fig, ax = plt.subplots(figsize=(8.3, 5.0))
        ax.plot(dense, j_dense, label=r"$J(q)=\int_{q_{crit}}^q \sigma(u)/u^2\,du$")
        ax.axhline(rho, linestyle="--", label=r"required $4\kappa\Delta/\ell_{GB}^2$")
        if qend is not None:
            ax.axvline(qend, linestyle=":", label=r"$q_{end}$")
        ax.set_xlabel(r"$q=\ell_{GB}^2/M^2$")
        ax.set_ylabel("Accumulated dimensionless growth integral")
        ax.grid(True, alpha=0.3)
        ax.legend(loc="lower right")
        # The required threshold rho can be many orders of magnitude smaller
        # than J(q) over the full q range. Add a local zoom so the crossing is
        # visible rather than appearing to lie on the x-axis.
        if qend is not None and rho > 0:
            axins = ax.inset_axes([0.50, 0.44, 0.43, 0.42])
            dx = max(qend - float(qgrid[0]), (float(qgrid[-1]) - float(qgrid[0])) * 1e-5)
            zhi = min(float(qgrid[-1]), float(qgrid[0]) + max(1.5 * dx, 1e-8))
            zmask = (dense >= float(qgrid[0])) & (dense <= zhi)
            axins.plot(dense[zmask], j_dense[zmask])
            axins.axhline(rho, linestyle="--")
            axins.axvline(qend, linestyle=":")
            axins.set_xlim(float(qgrid[0]), zhi)
            axins.set_ylim(0, max(1.5 * rho, 1e-14))
            axins.set_title("Zoom at threshold", fontsize=8)
            axins.tick_params(axis="both", labelsize=7)
            axins.grid(True, alpha=0.25)
        fig.tight_layout()
        fig.savefig(args.outdir / "growth_integral.png", dpi=180)
        plt.close(fig)
        print("Plots saved: growth_rate.png, growth_integral.png")


if __name__ == "__main__":
    main()
