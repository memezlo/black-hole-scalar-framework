#!/usr/bin/env python3
"""Independent audit of the conditional scalar-amplitude threshold integral.

This script re-integrates the same tabulated linear growth spectrum in two
independent variables:

  q = ell_GB**2 / M**2:
      Delta_log = ell_GB**2/(4*kappa) * integral sigma(q)/q**2 dq

  M:
      Delta_log = integral_[M_end]^[M_crit] Gamma(M)/L_H(M) dM,
      Gamma(M) = sigma(ell_GB**2/M**2)/(2*M),
      L_H(M) = kappa/M**2.

The equality only checks a change of variables for a fixed-background linear
mode plus an imposed mass-loss law. It is not a nonlinear evolution, a black-
to-white-hole transition calculation, or a solution of the information paradox.

Example:
  python audit_growth_threshold.py
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
from scipy.integrate import quad
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq


@dataclass(frozen=True)
class GrowthCurve:
    q: np.ndarray
    sigma: np.ndarray
    interpolate_sigma: Callable[[float | np.ndarray], float | np.ndarray]

    @property
    def q_crit(self) -> float:
        return float(self.q[0])

    @property
    def q_max(self) -> float:
        return float(self.q[-1])


def load_growth_curve(path: Path) -> GrowthCurve:
    """Load and validate the tabulated dimensionless growth spectrum."""
    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        required = {"q", "sigma_Gamma_times_rH"}
        if not required.issubset(reader.fieldnames or []):
            raise ValueError(f"{path} must contain columns {sorted(required)}")
        rows = list(reader)
    if len(rows) < 3:
        raise ValueError("growth curve must contain at least three rows")
    q = np.asarray([float(row["q"]) for row in rows], dtype=float)
    sigma = np.asarray([float(row["sigma_Gamma_times_rH"]) for row in rows], dtype=float)
    if not np.all(np.isfinite(q)) or not np.all(np.isfinite(sigma)):
        raise ValueError("q and sigma values must all be finite")
    if not np.all(np.diff(q) > 0):
        raise ValueError("q grid must be strictly increasing")
    if np.any(sigma < 0):
        raise ValueError("growth-rate table must not contain negative sigma values")
    if abs(float(sigma[0])) > 1e-14:
        raise ValueError("first growth-rate row must define the zero-mode threshold sigma(q_crit)=0")
    curve = PchipInterpolator(q, sigma, extrapolate=False)
    return GrowthCurve(q=q, sigma=sigma, interpolate_sigma=curve)


def integrated_growth_q(q_end: float, ell_gb: float, kappa: float, curve: GrowthCurve) -> float:
    """Integrate d ln|A| using q; all parameters are in the model's Planck units."""
    _validate_positive(ell_gb=ell_gb, kappa=kappa)
    if not (curve.q_crit <= q_end <= curve.q_max):
        raise ValueError("q_end lies outside the tabulated growth-rate domain")
    integral, _ = quad(
        lambda q: float(curve.interpolate_sigma(q)) / (q * q),
        curve.q_crit, q_end, epsabs=1e-14, epsrel=2e-11, limit=500,
    )
    return ell_gb * ell_gb / (4.0 * kappa) * integral


def integrated_growth_mass(q_end: float, ell_gb: float, kappa: float, curve: GrowthCurve) -> float:
    """Re-integrate the threshold directly in M, independently checking dq mapping."""
    _validate_positive(ell_gb=ell_gb, kappa=kappa)
    if not (curve.q_crit <= q_end <= curve.q_max):
        raise ValueError("q_end lies outside the tabulated growth-rate domain")
    m_initial = ell_gb / math.sqrt(curve.q_crit)
    m_final = ell_gb / math.sqrt(q_end)

    def integrand(mass: float) -> float:
        q = ell_gb * ell_gb / (mass * mass)
        sigma = float(curve.interpolate_sigma(q))
        gamma = sigma / (2.0 * mass)  # r_H = 2 M and sigma = Gamma*r_H
        luminosity = kappa / (mass * mass)
        return gamma / luminosity

    value, _ = quad(integrand, m_final, m_initial, epsabs=1e-12, epsrel=2e-11, limit=500)
    return value


def solve_endpoint(ell_gb: float, kappa: float, delta_log: float, curve: GrowthCurve) -> dict[str, float | None | str]:
    """Find the threshold point inside the tabulated q-domain, or report no bracket."""
    _validate_positive(ell_gb=ell_gb, kappa=kappa, delta_log=delta_log)
    qcrit = curve.q_crit
    required_j = 4.0 * kappa * delta_log / (ell_gb * ell_gb)
    j_max, _ = quad(
        lambda q: float(curve.interpolate_sigma(q)) / (q * q),
        qcrit, curve.q_max, epsabs=1e-14, epsrel=2e-11, limit=500,
    )
    if required_j > j_max:
        return {
            "status": "no_root_inside_tabulated_q_domain",
            "q_crit": qcrit,
            "q_end": None,
            "required_J": required_j,
            "available_J_at_q_max": j_max,
            "M_crit": ell_gb / math.sqrt(qcrit),
            "M_end": None,
            "fractional_mass_decrease": None,
            "delta_log_q_integral": None,
            "delta_log_mass_integral": None,
            "relative_integral_disagreement": None,
        }
    if delta_log == 0:
        qend = qcrit
    else:
        qend = brentq(
            lambda q: integrated_growth_q(q, ell_gb, kappa, curve) - delta_log,
            qcrit, curve.q_max, xtol=1e-14, rtol=1e-13,
        )
    mcrit = ell_gb / math.sqrt(qcrit)
    mend = ell_gb / math.sqrt(qend)
    delta_q = integrated_growth_q(qend, ell_gb, kappa, curve)
    delta_m = integrated_growth_mass(qend, ell_gb, kappa, curve)
    disagreement = abs(delta_q - delta_m) / max(abs(delta_q), abs(delta_m), 1e-300)
    return {
        "status": "conditional_threshold_found",
        "q_crit": qcrit,
        "q_end": qend,
        "required_J": required_j,
        "available_J_at_q_max": j_max,
        "M_crit": mcrit,
        "M_end": mend,
        "fractional_mass_decrease": 1.0 - mend / mcrit,
        "delta_log_q_integral": delta_q,
        "delta_log_mass_integral": delta_m,
        "relative_integral_disagreement": disagreement,
    }


def _validate_positive(**values: float) -> None:
    for name, value in values.items():
        if not math.isfinite(value) or value <= 0:
            raise ValueError(f"{name} must be finite and > 0")


def build_sensitivity(curve: GrowthCurve, ell_gb: float, kappa: float, delta_log: float) -> list[dict[str, object]]:
    """One-at-a-time parameter sweep around the illustrative baseline."""
    cases: list[tuple[str, float, float, float]] = []
    for value in (1.0, 5.0, 10.0, 20.0, 30.0):
        cases.append(("log_amplification_threshold", ell_gb, kappa, value))
    for factor in (0.1, 0.5, 1.0, 2.0, 10.0):
        cases.append(("kappa_multiplier", ell_gb, kappa * factor, delta_log))
    for value in (25.0, 50.0, 100.0, 200.0, 400.0):
        cases.append(("ell_GB_Planck_lengths", value, kappa, delta_log))
    records: list[dict[str, object]] = []
    for family, ell_case, kappa_case, delta_case in cases:
        result = solve_endpoint(ell_case, kappa_case, delta_case, curve)
        if family == "log_amplification_threshold":
            parameter_value = delta_case
        elif family == "kappa_multiplier":
            parameter_value = kappa_case / kappa
        else:
            parameter_value = ell_case
        records.append({
            "sweep": family,
            "parameter_value": parameter_value,
            "ell_GB_Planck_lengths": ell_case,
            "kappa_toy": kappa_case,
            "Delta_log_input": delta_case,
            "status": result["status"],
            "q_end": result["q_end"],
            "M_crit_Planck_masses": result["M_crit"],
            "M_end_Planck_masses": result["M_end"],
            "fractional_mass_decrease": result["fractional_mass_decrease"],
            "relative_integral_disagreement": result["relative_integral_disagreement"],
        })
    return records


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    project_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--growth-csv", type=Path, default=project_dir / "results" / "growth_rates.csv")
    parser.add_argument("--outdir", type=Path, default=project_dir / "results")
    parser.add_argument("--ell-gb", type=float, default=100.0, help="coupling length in Planck lengths")
    parser.add_argument("--kappa", type=float, default=1.0 / (15360.0 * math.pi), help="prescribed toy mass-loss coefficient")
    parser.add_argument("--delta-log", type=float, default=10.0, help="input ln(A_nl/|A_seed|); not predicted")
    args = parser.parse_args()

    _validate_positive(ell_gb=args.ell_gb, kappa=args.kappa, delta_log=args.delta_log)
    curve = load_growth_curve(args.growth_csv)
    baseline = solve_endpoint(args.ell_gb, args.kappa, args.delta_log, curve)
    args.outdir.mkdir(parents=True, exist_ok=True)
    sensitivity = build_sensitivity(curve, args.ell_gb, args.kappa, args.delta_log)
    sensitivity_path = args.outdir / "threshold_formula_sensitivity.csv"
    write_csv(sensitivity_path, sensitivity)

    metadata = {
        "audit": "independent change-of-variables check of the conditional linear-amplitude threshold",
        "inputs": {
            "ell_GB_in_Planck_lengths": args.ell_gb,
            "kappa_toy_mass_loss": args.kappa,
            "Delta_log_input": args.delta_log,
            "q_domain": [curve.q_crit, curve.q_max],
            "growth_csv": str(args.growth_csv),
        },
        "formulae": {
            "q_space": "Delta_log = ell_GB^2/(4*kappa) * integral[q_crit,q_end] sigma(q)/q^2 dq",
            "mass_space": "Delta_log = integral[M_end,M_crit] Gamma(M)/L_H(M) dM; Gamma=sigma/(2M), L_H=kappa/M^2",
            "mapping": "q=ell_GB^2/M^2; r_H=2M; sigma=Gamma*r_H",
        },
        "baseline": baseline,
        "sensitivity_csv": str(sensitivity_path),
        "limitations": [
            "sigma is interpolated from a numerical linear-mode spectrum on a fixed Schwarzschild background",
            "the mass-loss law L_H=kappa/M^2 is prescribed, not derived from greybody-resolved quantum field theory in this project",
            "Delta_log is an external threshold input, not predicted by the model",
            "the calculation does not evolve nonlinear fields or the metric and does not imply a bounce or white-hole formation",
            "no quantum state, radiation density matrix, entropy, or Page curve is computed; the information paradox is not solved",
        ],
    }
    out_json = args.outdir / "threshold_formula_audit.json"
    out_json.write_text(json.dumps(metadata, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"baseline": baseline, "audit_json": str(out_json), "sensitivity_csv": str(sensitivity_path)}, indent=2, ensure_ascii=False))
    if baseline["status"] == "conditional_threshold_found":
        if float(baseline["relative_integral_disagreement"] or math.inf) > 1e-7:
            raise SystemExit("Independent mass-space and q-space integrals disagree beyond 1e-7 relative tolerance")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
