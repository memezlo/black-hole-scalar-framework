#!/usr/bin/env sh
set -eu
python black_hole_scalar_model.py --ell-gb 100 --delta-log 10 --qmax 0.85 --outdir results --plot
