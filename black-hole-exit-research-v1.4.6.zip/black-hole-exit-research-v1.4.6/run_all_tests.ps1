$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
python -c "import importlib.util,sys; missing=[m for m in ('numpy','scipy','matplotlib','mpmath') if importlib.util.find_spec(m) is None]; print('Missing dependencies: '+', '.join(missing), file=sys.stderr) if missing else None; sys.exit(2 if missing else 0)"
if ($LASTEXITCODE -ne 0) { Write-Host "Install dependencies: python -m pip install -r requirements.txt"; exit 2 }
$OldMplConfig = $env:MPLCONFIGDIR
$OldMplBackend = $env:MPLBACKEND
$CreatedMplConfig = $false
if ([string]::IsNullOrWhiteSpace($env:MPLCONFIGDIR)) {
  $MplBase = Join-Path ([System.IO.Path]::GetTempPath()) ("bhe-test-mpl-" + [guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $MplBase | Out-Null
  $CreatedMplConfig = $true
} else {
  $MplBase = $env:MPLCONFIGDIR
  New-Item -ItemType Directory -Force -Path $MplBase | Out-Null
}
try {
  $env:MPLBACKEND = "Agg"
  $Projects = @("scalar-gauss-bonnet-instability", "black-white-transition-metric-study", "lqg-effective-transition-benchmark", "lqg-hawking-flux-reproduction", "information-paradox-diagnostic", "coupled-quasistatic-evolution", "nonlinear-closure-sensitivity", "unitary-page-benchmark")
  foreach ($Project in $Projects) {
    Write-Host "== $Project =="
    $env:MPLCONFIGDIR = Join-Path $MplBase $Project
    New-Item -ItemType Directory -Force -Path $env:MPLCONFIGDIR | Out-Null
    Push-Location (Join-Path (Join-Path $Root "projects") $Project)
    try { python -m unittest discover -s tests -v; if ($LASTEXITCODE -ne 0) { throw "Tests failed for $Project (exit $LASTEXITCODE)" } } finally { Pop-Location }
  }
  Write-Host "== repository-integrity =="
  $env:MPLCONFIGDIR = Join-Path $MplBase "repository-integrity"
  New-Item -ItemType Directory -Force -Path $env:MPLCONFIGDIR | Out-Null
  Push-Location (Join-Path $Root "tools")
  try { python -m unittest discover -s . -p 'test_*.py' -v; if ($LASTEXITCODE -ne 0) { throw "Repository integrity tests failed (exit $LASTEXITCODE)" } } finally { Pop-Location }
  python (Join-Path $Root "tools/update_checksums.py") --check
  if ($LASTEXITCODE -ne 0) { throw "Checksum manifest is stale (exit $LASTEXITCODE)" }
  Write-Host "All 108 regression tests passed. Tests verify code/math in the stated models, not the existence of white holes or resolution of the information paradox."
} finally {
  if ($CreatedMplConfig) {
    Remove-Item -Recurse -Force $MplBase -ErrorAction SilentlyContinue
  }
  if ([string]::IsNullOrWhiteSpace($OldMplConfig)) { Remove-Item Env:MPLCONFIGDIR -ErrorAction SilentlyContinue } else { $env:MPLCONFIGDIR = $OldMplConfig }
  if ([string]::IsNullOrWhiteSpace($OldMplBackend)) { Remove-Item Env:MPLBACKEND -ErrorAction SilentlyContinue } else { $env:MPLBACKEND = $OldMplBackend }
}
