#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python - <<'PYCODE'
import importlib.util, sys
missing = [name for name in ("numpy", "scipy", "matplotlib", "mpmath") if importlib.util.find_spec(name) is None]
if missing:
    print("Missing dependencies: " + ", ".join(missing), file=sys.stderr)
    print("Install them with: python -m pip install -r requirements.txt", file=sys.stderr)
    raise SystemExit(2)
PYCODE

# Use distinct Matplotlib caches and log files per suite. The test suites are
# read-only against checked-in result tables, so they can run concurrently.
MPL_TMP=""
if [[ -z "${MPLCONFIGDIR:-}" ]]; then
  MPL_TMP="$(mktemp -d "${TMPDIR:-/tmp}/bhe-test-mpl.XXXXXX")"
  MPL_BASE="$MPL_TMP"
else
  MPL_BASE="$MPLCONFIGDIR"
  mkdir -p "$MPL_BASE"
fi
LOG_TMP="$(mktemp -d "${TMPDIR:-/tmp}/bhe-test-logs.XXXXXX")"
cleanup() {
  rm -rf "$LOG_TMP"
  if [[ -n "$MPL_TMP" ]]; then rm -rf "$MPL_TMP"; fi
}
trap cleanup EXIT

run_project() {
  local name="$1" log="$2"
  mkdir -p "$MPL_BASE/$name"
  (cd "$ROOT/projects/$name" && MPLCONFIGDIR="$MPL_BASE/$name" MPLBACKEND=Agg python -m unittest discover -s tests -v) >"$log" 2>&1
}
run_integrity() {
  mkdir -p "$MPL_BASE/repository-integrity"
  (cd "$ROOT/tools" && python -m unittest discover -s . -p 'test_*.py' -v) >"$LOG_TMP/repository-integrity.log" 2>&1
}

run_project scalar-gauss-bonnet-instability "$LOG_TMP/project-a.log" & PID_A=$!
run_project black-white-transition-metric-study "$LOG_TMP/project-b.log" & PID_B=$!
run_project lqg-effective-transition-benchmark "$LOG_TMP/project-c.log" & PID_C=$!
run_project lqg-hawking-flux-reproduction "$LOG_TMP/project-d.log" & PID_D=$!
run_project information-paradox-diagnostic "$LOG_TMP/project-e.log" & PID_E=$!
run_project coupled-quasistatic-evolution "$LOG_TMP/project-f.log" & PID_F=$!
run_project nonlinear-closure-sensitivity "$LOG_TMP/project-g.log" & PID_G=$!
run_project unitary-page-benchmark "$LOG_TMP/project-h.log" & PID_H=$!
run_integrity & PID_I=$!

set +e
wait "$PID_A"; STATUS_A=$?
wait "$PID_B"; STATUS_B=$?
wait "$PID_C"; STATUS_C=$?
wait "$PID_D"; STATUS_D=$?
wait "$PID_E"; STATUS_E=$?
wait "$PID_F"; STATUS_F=$?
wait "$PID_G"; STATUS_G=$?
wait "$PID_H"; STATUS_H=$?
wait "$PID_I"; STATUS_I=$?
set -e

for entry in \
  "Project A:$LOG_TMP/project-a.log" \
  "Project B:$LOG_TMP/project-b.log" \
  "Project C:$LOG_TMP/project-c.log" \
  "Project D - published LQG Hawking flux:$LOG_TMP/project-d.log" \
  "Project E - information entropy diagnostic:$LOG_TMP/project-e.log" \
  "Project F - coupled quasi-static evolution:$LOG_TMP/project-f.log" \
  "Project G - nonlinear closure sensitivity:$LOG_TMP/project-g.log" \
  "Project H - unitary Page benchmark:$LOG_TMP/project-h.log" \
  "Repository integrity:$LOG_TMP/repository-integrity.log"; do
  label="${entry%%:*}"
  log="${entry#*:}"
  printf '\n== %s ==\n' "$label"
  cat "$log"
done

if [[ "$STATUS_A$STATUS_B$STATUS_C$STATUS_D$STATUS_E$STATUS_F$STATUS_G$STATUS_H$STATUS_I" != "000000000" ]]; then
  echo "One or more regression suites failed (A=$STATUS_A, B=$STATUS_B, C=$STATUS_C, D=$STATUS_D, E=$STATUS_E, F=$STATUS_F, G=$STATUS_G, H=$STATUS_H, integrity=$STATUS_I)." >&2
  exit 1
fi
python "$ROOT/tools/update_checksums.py" --check
echo "All 113 regression tests passed across nine suites. Tests verify code/math in the stated models, not the existence of white holes or resolution of the information paradox."
