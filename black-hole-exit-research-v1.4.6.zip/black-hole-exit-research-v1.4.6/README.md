# Research package: can a causal signal leave a black hole?

**Version:** 1.4.6 · **Build date:** 20 October 2026

This reproducible research package contains several separate computational tracks plus one coupled pre-threshold evolution model. It does **not** claim that escape from a genuine global event horizon has been proved or that astrophysical white holes have been detected.

## v1.4.6: equation-level derivation audit

Project C now has an explicit mapping to Eqs. (1), (5), and (6) of Belfaqih et al., *Physical Review Letters* 135, 161501 (2025), for the source-chosen effective holonomy function `lambda(x)=sqrt(Delta)/x`. A SymPy audit proves the transition-surface cubic and the scalar radial-potential identity algebraically; five regression tests compare the metric and simplified potential numerically. The current release has 113 tests total (A=17, B=22, C=26, D=15, E=8, F=8, G=6, H=6, repository integrity=5). This is a derivation inside a published **effective covariant LQG model**, not a derivation from the full fundamental LQG Hilbert-space dynamics, and it does not prove a physical black-to-white transition. See [`docs/EQUATION_LEVEL_DERIVATION_AUDIT_V1_4_6_RU.md`](docs/EQUATION_LEVEL_DERIVATION_AUDIT_V1_4_6_RU.md).

## v1.4.5: nonlinear underdetermination and a quantum-information benchmark

Two diagnostic projects were added without merging them into the black-hole metric tracks:

- `projects/nonlinear-closure-sensitivity/` compares two nonlinear normal forms with the same linearization. It demonstrates that a linear growth rate alone cannot determine the late-time endpoint. Its energy ledger closes by construction and is not derived from Einstein's equations.
- `projects/unitary-page-benchmark/` computes reduced-state von Neumann entropies of Haar-random pure states in a finite qubit Hilbert space and compares the Monte Carlo averages with Page's exact Haar-average formula. It is not a Hawking-emission circuit, QES/island calculation, or proof of unitarity for black-hole evaporation.
- The v1.4.5 baseline had 108 tests across eight project suites plus repository integrity.
- Current theoretical context includes the 2026 preprint on quasi-stationary backreacted evaporation in semiclassical 3+1D gravity ([arXiv:2607.11737](https://arxiv.org/abs/2607.11737)) and the Page/island calculation by Almheiri et al. ([arXiv:1908.10996](https://arxiv.org/abs/1908.10996)). These works remain distinct from the project's fixed-background scalar and effective-LQG ansätze.

See [`docs/NONLINEAR_AND_INFORMATION_NEXT_STEP_V1_4_5_RU.md`](docs/NONLINEAR_AND_INFORMATION_NEXT_STEP_V1_4_5_RU.md) for mathematical derivations, measured diagnostics, and remaining blockers.

## v1.4.4: coupled quasi-static evolution up to the linear threshold

Project F adds a single mathematically coupled ODE system on the quasi-static Schwarzschild background. It evolves the mass and linear scalar amplitude with a prescribed mass-loss law, independently checks the integral and time solutions, and stops at the specified amplitude threshold where linear theory is no longer adequate. It deliberately does **not** combine Project A's Schwarzschild scalar spectrum with the separate LQG effective metric/flux until the scalar perturbation equation has been derived on that same background.

- `projects/coupled-quasistatic-evolution/README_RU.md` describes the equations and run command.
- `docs/UNIFIED_PRETHRESHOLD_MODEL_RU.md` gives the derivation, checks, and open physics work.
- `docs/RESEARCH_ADVANCE_V1_4_4_RU.md` records the measured results and explains why this still does not solve the nonlinear transition or information paradox.
- `docs/EXPLAIN_TO_PHYSICIST_V1_4_4_RU.md` is a concise physicist-facing summary and independent-review checklist.
- `bash run_all_tests.sh` now runs 108 tests across eight project suites and repository integrity. These tests verify the specified numerical models, not nonlinear bounce dynamics or unitarity.
- `bash run_all_reproductions.sh coupled` regenerates the Project F table and summary under `validation_runs/`.


## v1.4.2: threshold-formula audit

Added an independent q-space/mass-space integration check for Project A, parameter sensitivity outputs, and regression tests. See [`docs/FORMULA_TO_PHYSICS_BRIDGE_AUDIT_RU.md`](docs/FORMULA_TO_PHYSICS_BRIDGE_AUDIT_RU.md) for the full scope and derivation. The two integrations agree to about `5.31e-10` relative for the illustrative input set. This verifies a conditional change of variables and numerical calculation, not a black-to-white transition or a solution to Hawking’s information paradox.

## Corrections retained from v1.3.2

- Replaced Project A's finite-boundary residual `phi(X) + X phi'(X)` with an eighth-order, ODE-derived asymptotic Robin condition for the decaying zero-mode tail.
- Regenerated the critical threshold, growth-rate spectrum, conditional integral and sensitivity tables under the updated boundary condition.
- Added tests for convergence in outer radius, asymptotic-series order, and integration max step.
- Removed Project B's silent lower-radius clipping; the integrator now fails explicitly if the state reaches `r <= 0`.
- Added a local proper-time Kantowski–Sachs-chart null-ray integration for Project C across the assumed reflection surface. It stops before the outer horizon and does not claim a global escape proof.
- Regenerated the Project B horizon convergence audit across 13 representative times and three domain/grid configurations.

## Review fixes in v1.3.5

- Added an automatic 80-decimal-digit `mpmath` fallback for Project B horizon roots near extremality.
- Removed fixed `1e-6` root deduplication and added regressions covering tangent roots, close pairs, false tangent classifications, grid-aligned rounded-zero false roots, and duplicate roots from overlapping detection paths.
- The code does not use Newton's method; ordinary roots use `brentq`, and the near-critical fallback uses high-precision derivative refinement and bisection. See `docs/NEAR_EXTREMAL_HORIZON_AUDIT_RU.md`.

- Project B's ray equation is integrated in its stated Painlevé–Gullstrand-like chart, without a `g_tt + epsilon` denominator. The local h=0 transit belongs to the separate Project C Kantowski–Sachs chart.
- Project A's tail boundary condition is an ODE-derived asymptotic Robin condition; the old `phi + X phi'` estimator is retained only for a reproducible bias comparison.
- Project C supports max-step refinement for its local null-ray integration. The code implements a restricted LQG-inspired ansatz with `lambda(x)=sqrt(Delta)/x`, not every scale-function/gauge choice in the cited papers. This remains a local chart calculation and is not a global escape proof.
- `bash run_all_tests.sh` runs 96 tests (17 + 22 + 21 + 15 + 8 + 8 + 5 repository-integrity tests) as parallel isolated suites with separate Matplotlib caches; canonical runs and optional symbolic checks are described in `docs/TEST_REPORT_RU.md`.

## Release verification and formula audit (v1.4.2)

- The release audit now checks relative Markdown links and deterministic archive exclusions, and the test runner uses an isolated Matplotlib cache to avoid stale font-cache locks after interrupted jobs.
- The PowerShell runner now includes repository-integrity tests and the checksum-manifest check, matching the Bash runner. `tools/build_release.py` creates deterministic ZIP/TAR.GZ release archives and a SHA-256 sidecar.
- Interpreter caches and generated `validation_runs/` files are omitted from the archive; the released report states the actual measured test and reproduction results.

- Project A's default grid now directly solves six additional points near the scalar-instability threshold, instead of relying on a wide interpolation interval immediately above `q_crit`.
- The matching-domain cap is increased to `Y=120000` for the nearest added point. The canonical run recalculates the conditional endpoint as `q_end = 0.7261032564717468` for the stated illustrative settings.
- One regression test protects the grid refinement. These results remain conditional on the fixed Schwarzschild background, linear scalar equation, toy mass-loss law, and user-set amplitude threshold.

## Release/reproducibility hardening in v1.3.8

- The benchmark writes timestamps and roots at the requested output precision, rejects `dps < 80`, and uses 30 additional guard digits so near-tangent root positions converge between 80- and 100-digit output modes.
- The canonical reproduction script writes generated benchmark copies only under `validation_runs/` and checks they are byte-identical; it no longer overwrites curated source results.
- `tools/update_checksums.py --check` validates the stable-content manifest; `validation_runs/` holds regeneratable outputs and is excluded from that manifest.
- Three repository-integrity tests were added; the v1.3.8 suite had 53 tests (10 + 20 + 20 + 3). The v1.3.6 numerical algorithm and its 36-case API comparison remain documented separately.

## Projects

1. `projects/scalar-gauss-bonnet-instability/` — linear scalar instability on a fixed Schwarzschild background.
2. `projects/black-white-transition-metric-study/` — a phenomenological black-to-white transition metric and an outgoing-null-ray diagnostic.
3. `projects/lqg-effective-transition-benchmark/` — root checks for `h(x_delta)=0` in a restricted effective-LQG-inspired metric ansatz, plus local geometry and null-ray checks.
4. `projects/lqg-hawking-flux-reproduction/` — published low-frequency s-wave flux reproduction and independent static-metric scattering checks.
5. `projects/information-paradox-diagnostic/` — toy entropy bookkeeping; not an information-paradox solution.
6. `projects/coupled-quasistatic-evolution/` — one coupled pre-threshold ODE system on a quasi-static Schwarzschild background; this intentionally does not merge incompatible LQG and scalar-instability models.
7. `projects/nonlinear-closure-sensitivity/` — demonstrates that nonlinear outcomes are not determined by a shared linear instability alone; not a gravitational field solution.
8. `projects/unitary-page-benchmark/` — finite-dimensional Haar-state Page entropy benchmark; not a physical black-hole evaporation model.

- `docs/MODEL_SCOPE_MATRIX_RU.md` maps the three independent tracks to their equations, inputs, validated outputs and open physical questions.

## Research notes

- `docs/CRITICAL_REVIEW_OF_NUMERICAL_CLAIMS_RU.md`, `docs/USER_REVIEW_RESPONSE_RU.md`, and `docs/NEAR_EXTREMAL_HORIZON_AUDIT_RU.md` — numerical review, including near-extremal horizon roots.
- `docs/PROPOSED_MECHANISM_RU.md` — working mechanism and criteria.
- `docs/MATHEMATICAL_FRAMEWORK_RU.md` — causal definitions and equations.
- `docs/MASTER_RESEARCH_PLAN_RU.md` — staged plan with acceptance and stop criteria.
- `docs/BOUNDARY_MATH_VS_PHYSICS_RU.md` — what code verifies versus what physical assumptions remain.
- `docs/PROJECT_AUDIT_RU.md`, `docs/EXECUTION_CHECKLIST_RU.md`, `docs/CLAIM_LEDGER.csv`, and `docs/ISSUE_REGISTER.csv` — audit, checklist, claim ledger and open-item register.
- `projects/scalar-gauss-bonnet-instability/results/static_threshold_convergence.csv` — comparison of the old finite-boundary estimator with the ODE-derived asymptotic Robin boundary condition.
- `projects/lqg-effective-transition-benchmark/trace_null_ray_ks.py` — local null-ray propagation in the assumed reflected KS chart.
- `tools/verify_local_curvature_symbolic.py` — independent symbolic tensor check.
- `REFERENCES.md` — cited literature, including effective-LQG and scalar–Gauss–Bonnet studies.
- `projects/black-white-transition-metric-study/results/horizon_convergence.csv` — finite root-count/location audit for 13 representative times. `results/near_extremal_horizon_benchmark.csv` audits tangent and close-pair cases with mpmath.
- `docs/TEST_REPORT_RU.md` and `docs/CANONICAL_REPRODUCTION_REPORT_RU.md` — local tests and demonstration outputs.
- `docs/INDEPENDENT_RECHECK_V1_4_2_RU.md` — current release verification; v1.4.1 and v1.3.x reports are historical.
- `docs/FORMULA_TO_PHYSICS_BRIDGE_AUDIT_RU.md` — derivation and independent numerical cross-check of the conditional growth-threshold formula; explains why it does not solve the information paradox.
- `docs/NONLINEAR_AND_INFORMATION_NEXT_STEP_V1_4_5_RU.md` — nonlinear-closure underdetermination, exact Page Haar-average check, and next physics blockers.

## Run tests

Requires Python 3.10+. Dependencies are project-specific; the unified script runs each suite in its own project directory.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
bash run_all_tests.sh
python -m pip install -r requirements-symbolic.txt
python tools/verify_local_curvature_symbolic.py
python tools/verify_static_horizon_invariants_symbolic.py
```

To regenerate the numerical examples and graphics, run the full pipeline:

```bash
bash run_all_reproductions.sh
python tools/build_release.py
```

The second command builds deterministic archives in the parent directory and writes a checksum sidecar. For environments with a per-command runtime limit, the stages can be run in independently checked phases:

```bash
bash run_all_reproductions.sh core         # stages 1–3
bash run_all_reproductions.sh trajectories # stages 4–8
bash run_all_reproductions.sh flux         # stages 9–11: greybody ODE and entropy diagnostic
bash run_all_reproductions.sh coupled      # stage 12: coupled pre-threshold ODE
```

`all` is the default. Generated outputs are written to `validation_runs/`; the canonical runner does not overwrite curated files in `projects/*/results/`.

## Scope and limitations

The null ray in Project B escapes a temporary trapped region of a prescribed ansatz; the shift reversal is built into the model. Project C's new null-ray routine crosses `tau=0` only in a local, assumed reflection-symmetric Kantowski–Sachs chart. It stops before the outer horizon; matching to the exterior and tracing to the same future null infinity remain open. By definition, no future-directed causal path from the global black-hole region reaches the same future null infinity.

The scalar–Gauss–Bonnet threshold is a linear zero-mode result on a fixed Schwarzschild background. It is not a self-consistent nonlinear evolution and does not predict a bounce. The updated numerical threshold is `q_crit ≈ 0.725612849259` for the action/coupling convention documented in Project A. This reproduces a known class of scalar-instability results; it is not claimed as a new physical discovery.

The v1.4.2 historical baseline contains **65 tests** (17 + 22 + 21 + 5 repository-integrity tests). The release includes a checksum-manifest checker and excludes regeneratable `validation_runs/` output from the immutable source checksum manifest. In the release audit, stages 1–3 and 4–8 of the reproduction runner were completed and checked in separate `core` and `trajectories` invocations; a single all-in-one invocation hit this environment's execution limit, so it is not claimed as a successful one-process run. The 108-row horizon-convergence audit had zero root-count mismatches. Project B has an arbitrary-precision `mpmath` fallback and regressions for zero, one (tangent), and two roots near pair birth; the canonical benchmark scans 1501 radii and is checked against a 601-point scan, while the separate convergence study spans grids up to 6001. Project B is a phenomenological metric, not the scalar–Gauss–Bonnet model in Project A. The GitHub Actions workflow is configured, but remote CI has not been verified because this package has not yet been pushed to a GitHub repository. Tests check the stated equations and numerical implementation, not the existence of white holes.


## v1.4.3 research additions (historical, 2026-10-20)

- `projects/lqg-hawking-flux-reproduction/` numerically reproduces the low-frequency s-wave mass-loss integral used in Belfaqih et al., *Physical Review Letters* 135, 161501 (2025), DOI [10.1103/t6q4-4l77](https://doi.org/10.1103/t6q4-4l77). It is an approximation-level reproduction, not a complete all-species Hawking flux.
- `projects/information-paradox-diagnostic/` offers a parameterized toy entropy/Page-envelope comparison. It is not a quantum-extremal-surface/island calculation and does not establish unitarity.
- `docs/RESEARCH_ADVANCE_V1_4_3_RU.md` records results and open blockers. The v1.4.3 suite had 88 tests across five project suites plus repository-integrity tests. A direct static-metric scalar s-wave scattering solver now checks `T+R≈1` and shows why extrapolating the low-frequency transmission formula to all frequencies must be treated cautiously; this still does not resolve the information paradox. Successful tests verify the stated calculations, not the existence of white holes or a resolution of the information paradox.
